# VEXACOLLECTION: connect Firebase to go live

**Why you need this:** right now the shop and the admin panel run in **DEMO MODE**.
In demo mode, an order is saved only on the phone that placed it, so customers' orders
**do not reach your admin panel**. Firebase is Google's free online database. When it is
connected, every order from every phone shows up in your admin panel straight away.

You need: a Gmail account and about 15 minutes. The free **Spark** plan is enough.
You do **not** add a payment card.

---

## Step 1: Create a Firebase project

1. Open **https://console.firebase.google.com** and sign in with your Gmail.
2. Click **Create a project** (or **Add project**).
3. Name: `vexacollection`, then click **Continue**.
4. Google Analytics: turn it **off**, then click **Create project**. Wait for it to finish, then click **Continue**.

## Step 2: Add the website and copy its config

1. On the project home page, click the **Web** icon `</>`.
2. App nickname: `VEXACOLLECTION website`. Do **not** tick "Firebase Hosting". Click **Register app**.
3. Firebase shows code with `const firebaseConfig = { ... }`. Copy these 6 values:
   `apiKey`, `authDomain`, `projectId`, `storageBucket`, `messagingSenderId`, `appId`.
4. Open the file **`js/firebase-config.js`** in the website folder. Replace each `PASTE_...`
   value with your value. Keep the quotes. Example:

   ```js
   window.VX_FIREBASE_CONFIG = {
     apiKey: "AIzaSyA1b2C3d4E5f6G7h8I9j0",
     authDomain: "vexacollection.firebaseapp.com",
     projectId: "vexacollection",
     storageBucket: "vexacollection.appspot.com",
     messagingSenderId: "123456789012",
     appId: "1:123456789012:web:abc123def456"
   };
   ```

   These values are **public**: every Firebase website shows them, so it is fine to put them
   here. What keeps your data safe is the **rules** (Step 5) and the **admin login** (Step 3).
   Never paste a "service account", "private_key" or any password into the website.

   (You can also send these 6 values to Tab on WhatsApp, and Tab will put them in and publish the site for you.)

## Step 3: Turn on admin login (Email/Password)

1. In the left menu, open **Build → Authentication** and click **Get started**.
2. Open the **Sign-in method** tab, click **Email/Password**, turn on **Enable**, then click **Save**.
3. Open the **Users** tab and click **Add user**. Enter your email and a **strong password**
   (at least 10 characters). This is your admin login.
4. In the users list, copy that user's **User UID** (a long code like `Xy12AbC...`).
5. Open the **Settings** tab, then **Authorized domains**, then **Add domain**, and add:
   `vexacollection.sites.tab.bot`

## Step 4: Create the database and make yourself admin

1. In the left menu, open **Build → Firestore Database** and click **Create database**.
2. Location: **asia-south1 (Mumbai)**, then **Next**. Choose **Start in production mode**, then **Create**.
3. Click **+ Start collection**. Collection ID: `admins`, then **Next**.
4. Document ID: **paste your User UID** from Step 3.
   Add one field: name `role`, type `string`, value `owner`. Click **Save**.

   Only users listed in `admins` can open the admin panel. To add a second admin later,
   create their login in Step 3 and add their UID here the same way.

## Step 5: Paste the security rules

1. In Firestore Database, open the **Rules** tab.
2. Delete everything in the box. Open the file **`firestore.rules`** from the website folder,
   copy all of it, and paste it in.
3. Click **Publish**.

These rules mean:
- Customers can see products and place orders, but can never mark an order "PAID".
- Only you (admins) can see orders, customers, payments and coupons, or change anything.

## Step 6: Publish and fill your shop

1. Publish the website again with the new `js/firebase-config.js`. (Send it to Tab and Tab will do this.)
2. Open **https://vexacollection.sites.tab.bot/admin/** and log in with the email and password from Step 3.
   The top of the panel now says **Live · Firebase**, and the yellow demo banner is gone.
3. Go to **Products** and click **Import sample products** to copy the 8 current products into the database.
   Then edit them, or add your real products with photos.
4. Go to **Settings**. Check that your UPI ID is **marseries@ybl**, then check phone, shipping, and so on.
   Click **Save settings**.

## Step 7: Test it

1. On your phone (or a friend's), open the shop, add a product, and place a **Cash on Delivery** order.
2. In the admin panel you should hear a sound and see **"New order"**.
3. Open the order and change its status. Then cancel it: the stock goes back up.
4. Scan the test QR in **Settings** and pay ₹1, to check the UPI money reaches your account.

---

## Good to know

- **UPI payments are not checked automatically.** A UPI order stays **PAYMENT VERIFICATION PENDING**
  until you open it and press **Mark as Paid (manually verified)**. Do that only after you see the
  money in your UPI app. Automatic checking needs a payment gateway such as Razorpay or Cashfree,
  plus a small server. That can be added later.
- **Product photos:** on the free plan, photos are made smaller and saved with the product.
  Use clear photos. Firebase **Storage** (for bigger photo uploads) needs the paid Blaze plan.
  If you ever turn it on, also publish `storage.rules` and set `VX_FIREBASE_USE_STORAGE = true`
  in `js/firebase-config.js`.
- **Free plan limits:** the Spark plan allows about 50,000 reads and 20,000 writes per day.
  That is plenty for a small shop.
- **Session timeout:** you are logged out after 30 minutes without activity, or after 7 days if
  you tick "Remember me".
- **Forgot the admin password?** Go to Firebase → Authentication → Users, click the ⋮ menu next to
  your user, and choose **Reset password**.

## If something does not work

| Problem | Fix |
|---|---|
| Admin says "This account is not an admin yet" | The `admins` document ID must be exactly your User UID (Step 4). |
| Login error "auth/unauthorized-domain" | Add `vexacollection.sites.tab.bot` in Authentication → Settings → Authorized domains. |
| Shop still shows "demo" / orders not arriving | `js/firebase-config.js` still has a `PASTE_...` value, or the site was not published again. |
| "Missing or insufficient permissions" | The rules from `firestore.rules` were not published (Step 5). |
| Products page in admin is empty | Click **Import sample products** (Step 6). |
