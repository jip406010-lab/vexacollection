VEXACOLLECTION WEBSITE - HOW TO EDIT (simple guide)
====================================================

WHAT IS IN THE FOLDER
  index.html      -> the whole website (all text, products, contact details)
  checkout.html   -> checkout page, order confirmation, order details / invoice
  css/style.css   -> colours, fonts, layout (cart + checkout styles at the end)
  js/config.js    -> STORE SETTINGS: UPI ID, shipping charge, phone, address
  js/main.js      -> menu, product filter, animations
  js/cart.js      -> Add to Cart, cart drawer, cart counter, "Added to Cart" message
  js/checkout.js  -> checkout form + checks, UPI QR, orders, WhatsApp invoice
  js/vendor/qrcode.js -> small QR code library (MIT licence, see qrcode-LICENSE.txt)
  images/         -> all photos and the logo
  fonts/          -> the fonts (works without internet)
  og.png          -> the picture shown when the link is shared on WhatsApp etc.
  CREDITS.txt     -> where the sample photos come from

To see the site, just double-click index.html (it opens in your browser).
Edit files with any text editor (Notepad, VS Code, or "Acode" on Android).


1) CHANGE A PRODUCT NAME OR PRICE
---------------------------------
Open index.html and search for "PRODUCT 1" (there are PRODUCT 1 to PRODUCT 8).
Each product looks like this:

    <h3 class="product-name">Classic Oxford Shirt – White</h3>
    <p class="product-price">₹1,499</p>

Change only the words between > and <. Example:

    <h3 class="product-name">Cotton Check Shirt – Blue</h3>
    <p class="product-price">₹1,299</p>

The "Add to Cart" button reads the name, price and photo from the card
automatically - you do not need to change anything else. Write the price as
digits with ₹ (like ₹1,299). Each product also has an ID, e.g.
    <article class="product reveal" data-id="vx-001" ...>
Keep every ID different (vx-001, vx-002 ...). The cart uses it.

Optional: the small label on the photo ("New", "Bestseller") is the line
    <span class="badge">New</span>
Change the word, or delete that line to remove the label.


2) CHANGE A PRODUCT PHOTO
-------------------------
Easiest way: put your new photo in the images folder with the SAME name,
for example images/product-1.jpg (replace the old file).
Best size: portrait (taller than wide), around 800 x 1000 pixels, JPG.

Or use a new file name and change this line in that product:
    <img src="images/product-1.jpg" alt="...">
    -> <img src="images/my-new-shirt.jpg" alt="Blue check shirt">


3) PRODUCT CATEGORIES (FILTER BUTTONS)
--------------------------------------
Each product has a category, e.g.  data-category="shirts"
Use one of:  shirts   tshirts   bottoms   jackets
(bottoms = Jeans & Trousers). The filter buttons and the category cards
use these words.


4) ADD OR REMOVE A PRODUCT
--------------------------
To add: copy one whole block from "<!-- PRODUCT 1 -->" down to its
"</article>", paste it below the last product, then change the name,
price, photo AND the data-id (give it a new one, e.g. vx-009). To remove: delete the whole block.


5) CHANGE PHONE / WHATSAPP NUMBER
---------------------------------
Phone links look like:  href="tel:+916394692521"
WhatsApp links look like: href="https://wa.me/916394692521?text=..."
Use "Find and Replace" in your editor:
  916394692521   -> your new number (with 91, no + and no spaces)
  +91 63946 92521 -> the new number as you want it shown
Also change phone and whatsapp in js/config.js.


6) CHANGE OTHER TEXT
--------------------
All text (top announcement bar, big heading, About us, address) is in
index.html - search for the words you see on the website and edit them.
The address is GHOSI, MAU, UTTAR PRADESH, 275301. To change it, search for
"GHOSI" and "Ghosi" in index.html, and change address in js/config.js.


7) CHANGE THE HERO (BIG TOP) PHOTOS
-----------------------------------
Replace images/hero-1.jpg (shown on phones and desktop) and
images/hero-2.jpg (second photo on desktop). Portrait photos work best.


8) PUTTING IT ONLINE
--------------------
This is a simple static website (no server code needed). Upload the whole
folder as it is to any hosting (Netlify, GitHub Pages, Hostinger, etc.).
If you use your own domain, open index.html and change the address
"https://vexacollection.sites.tab.bot/" (in the meta tags at the top)
to your own website address.


9) ONLINE SHOP: UPI ID, SHIPPING, ORDERS
---------------------------------------
Open js/config.js. Everything is in one block:

    upiId: "marseries@ybl",   <- your UPI ID (QR code + "Pay now with UPI")
    shipping: 0,              <- delivery charge in rupees (0 = free)

- To change the UPI ID, replace marseries@ybl with the new one.
  If you set it back to "YOUR_UPI_ID_HERE", the checkout shows
  "UPI payment is not available yet", makes NO QR code, and only
  Cash on Delivery can be used.
- The QR code / Pay Now link is:
  upi://pay?pa=<UPI ID>&pn=VEXACOLLECTION&am=<total>&cu=INR&tn=Order <ID>
  (tn = the order ID as the payment note, so you can match payments.
   Set upiNoteWithOrderId: false to remove it.)
- Delivery address works like Meesho: the customer types name, mobile,
  house, road/area, landmark and PIN. City and State fill in by themselves
  from the PIN (free India Post lookup; if it doesn't answer, the customer
  types them). After the first order the address is saved on that phone
  ("vx_addresses") and next time they just tap "Deliver here", Edit, or
  "+ Add new address".

HOW ORDERS WORK (please read)
- Customer: Add to Cart -> Cart -> Proceed to Checkout -> details + address
  -> UPI or Cash on Delivery -> Order placed (Order ID like VX-20261027-AB12).
- UPI payments are NOT checked automatically. Every UPI order says
  "PAYMENT VERIFICATION PENDING". Check your UPI app for the amount and
  the order ID in the note before you ship.
- On the confirmation page the customer taps "SEND ORDER INVOICE ON
  WHATSAPP". WhatsApp opens with the full invoice written; they tap Send and
  it arrives on 916394692521. THIS IS HOW YOU RECEIVE ORDERS today.
- "Download / Print invoice" opens a clean invoice they can save as PDF.

IMPORTANT - NO BACKEND YET
- Orders are saved only in the customer's own browser (localStorage,
  keys "vx_cart" and "vx_orders"). This is NOT a secure database: you
  cannot see it, and it is lost if the customer clears their browser.
- Fully automatic invoices on WhatsApp (to you AND the customer without
  pressing Send) need a server with the official WhatsApp Business API.
- Automatic payment confirmation needs a payment gateway (Razorpay,
  Cashfree, PhonePe PG...) connected through a server.
- A developer can plug these in at the "BACKEND HOOKS" at the top of
  js/checkout.js: submitOrder(), sendOrderToBackend(), notifyStoreOnWhatsApp().
- Never put secret keys or passwords in any file of this website.


=====================================================================
 VERSION 3: ADMIN PANEL + SHARED DATA (Firebase)
=====================================================================

ADMIN PANEL
  Open:  https://vexacollection.sites.tab.bot/admin/
  First visit (demo mode): create your admin username + password.
  Sections: Dashboard, Orders, Products, Inventory, Customers, Payments,
  Coupons, Analytics, Settings, Logout.

DEMO MODE vs LIVE MODE  (IMPORTANT)
  - DEMO MODE (now): js/firebase-config.js still says "PASTE_...".
    Everything is saved only in the browser you use, so orders from
    customers' phones DO NOT reach your admin panel. The admin shows a
    yellow "DEMO MODE" banner.
  - LIVE MODE: follow SETUP-FIREBASE.md (free Firebase, about 15 minutes).
    After that, every order from every phone appears in the admin
    instantly, with a sound and a pop-up.

WHERE TO CHANGE THINGS (after v3)
  - Products, prices, photos, stock, hide/show: Admin -> Products / Inventory
  - UPI ID, merchant name, shipping charge, free-shipping amount,
    delivery time, phone, WhatsApp, address: Admin -> Settings
  - Coupons: Admin -> Coupons
  js/config.js now holds only the STARTING values (used before Settings
  is saved for the first time).

PAYMENTS
  UPI payments are never marked paid automatically. A UPI order stays
  "PAYMENT VERIFICATION PENDING" until you open it and press
  "Mark as Paid (manually verified)". Do that only after you see the money
  in your UPI app.

FILES ADDED IN V3
  admin/index.html, admin/admin.css, admin/admin.js : the admin panel
  js/store-api.js        : the data layer used by the shop AND the admin
  js/firebase-adapter.js : Firebase (Firestore + login) connection
  js/firebase-config.js  : paste your Firebase web config here
  js/seed-products.js    : the 8 starting products
  js/shop.js             : draws the product grid from the data layer
  firestore.rules        : database security rules (paste into Firebase)
  storage.rules          : only if you turn on Firebase Storage (paid plan)
  firebase.json          : for the Firebase command-line tool (optional)
  SETUP-FIREBASE.md      : step-by-step guide to go live

SECURITY
  No secret keys are anywhere in the website. The Firebase web config is
  a public identifier. Security comes from firestore.rules: customers can
  only see products/settings and place orders (never as "paid"), and only
  admin accounts can read orders, customers, payments and coupons.
