/* =========================================================
   VEXACOLLECTION — STORE SETTINGS (edit this file only)
   ---------------------------------------------------------
   upiId    : your UPI ID, e.g. "yourname@okaxis".
              While it says "YOUR_UPI_ID_HERE", the checkout shows a
              notice and no UPI QR code is made (Cash on Delivery
              still works). NEVER put passwords or secret keys here —
              this file is public.
   shipping : delivery charge in rupees (0 = free delivery).

   NOTE (v3): once the store is running, change the UPI ID, shipping,
   phone etc. in the ADMIN PANEL → Settings (/admin/#settings). The
   values below are only the starting defaults used before the admin
   saves Settings for the first time.
   ========================================================= */
const STORE_CONFIG = {
  brandName: "VEXACOLLECTION",
  phone: "+916394692521",
  address: "GHOSI, MAU, UTTAR PRADESH, 275301",
  upiId: "marseries@ybl",      // <-- MERCHANT UPI ID (placeholder was "YOUR_UPI_ID_HERE")
  shipping: 0,                 // <-- delivery charge in ₹ (0 = free)
  currency: "INR",

  // Extra settings (optional)
  whatsapp: "916394692521",    // support chat number (country code, no + or spaces)
  upiNoteWithOrderId: true     // adds "Order VX-..." as the UPI payment note, so you can match payments to orders
};
