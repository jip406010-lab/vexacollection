/* =========================================================
   VEXACOLLECTION — cart (Add to Cart, cart drawer, header badge, toast)
   Plain JavaScript, no libraries. Cart is saved in this browser's
   localStorage under "vx_cart".
   NOTE: localStorage is NOT a secure database. It lives only in the
   customer's own browser. A real backend is needed to store orders safely.
   ========================================================= */
(function () {
  'use strict';

  var CART_KEY = 'vx_cart';
  var MAX_QTY = 20;   // per product per order (also enforced by firestore.rules)
  var Store = window.VXStore;
  var BAG = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" d="M5 8h14l-1 12.5H6L5 8Z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M9 10V7a3 3 0 0 1 6 0v3"/></svg>';

  // ---------- helpers ----------
  var inrFmt = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });
  function money(n) { return '\u20B9' + inrFmt.format(Math.round(Number(n || 0) * 100) / 100); }
  function parsePrice(text) { var n = parseFloat(String(text || '').replace(/[^\d.]/g, '')); return isFinite(n) ? n : 0; }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function settings() { return Store ? Store.cache.settings : { shippingCharge: 0, freeShippingAbove: 0 }; }
  function shippingCost(subtotal) { return Store ? Store.util.shippingFor(subtotal, settings()) : 0; }
  // Live product from the store (price / stock / status), or null if not known yet
  function liveProduct(id) { return Store && Store.cache.productsLoaded ? Store.getProduct(id) : undefined; }
  function maxFor(id) {
    var p = liveProduct(id);
    if (p === undefined) return MAX_QTY;          // store still loading
    if (!p || Store.util.availability(p) !== 'in') return 0;
    return Math.min(MAX_QTY, Math.max(0, Math.floor(Number(p.stock) || 0)));
  }
  // Problems that must be fixed before checkout: [{id, name, msg, max}]
  function issues(items) {
    var out = [];
    (items || read()).forEach(function (i) {
      var p = liveProduct(i.id);
      if (p === undefined) return;
      var max = maxFor(i.id);
      if (max === 0) out.push({ id: i.id, name: i.name, max: 0, msg: p ? 'Out of stock — please remove' : 'No longer available — please remove' });
      else if (i.quantity > max) out.push({ id: i.id, name: i.name, max: max, msg: 'Only ' + max + ' available — please reduce quantity' });
    });
    return out;
  }
  // Keep cart names/prices/images in step with the store
  function syncWithStore() {
    if (!Store || !Store.cache.productsLoaded) return;
    var items = read(), changed = false;
    items.forEach(function (i) {
      var p = Store.getProduct(i.id);
      if (p && (p.price !== i.price || p.name !== i.name || p.image !== i.image)) { i.price = p.price; i.name = p.name; i.image = p.image; changed = true; }
    });
    if (changed) { try { localStorage.setItem(CART_KEY, JSON.stringify(items)); } catch (e) {} }
  }

  // ---------- storage ----------
  function read() {
    try {
      var items = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
      if (!Array.isArray(items)) return [];
      return items.filter(function (i) { return i && i.id && i.quantity > 0; });
    } catch (e) { return []; }
  }
  function write(items) {
    try { localStorage.setItem(CART_KEY, JSON.stringify(items)); } catch (e) { /* storage full or blocked */ }
    render();
    document.dispatchEvent(new CustomEvent('vx:cartchange', { detail: totals(items) }));
  }
  function totals(items) {
    items = items || read();
    var count = 0, subtotal = 0;
    items.forEach(function (i) { count += i.quantity; subtotal += i.price * i.quantity; });
    var shipping = shippingCost(subtotal);
    return { items: items, count: count, subtotal: subtotal, shipping: shipping, total: subtotal + shipping };
  }

  // returns { ok, quantity, max }
  function add(product, qty) {
    var items = read(), max = maxFor(product.id);
    var found = items.filter(function (i) { return i.id === product.id; })[0];
    var have = found ? found.quantity : 0;
    if (max <= 0) return { ok: false, quantity: have, max: 0 };
    var want = Math.min(max, have + (qty || 1));
    if (want <= have) return { ok: false, quantity: have, max: max };
    if (found) {
      found.quantity = want;
      found.price = product.price; found.name = product.name; found.image = product.image;
    } else {
      items.push({ id: product.id, name: product.name, image: product.image, price: product.price, quantity: want });
    }
    write(items);
    return { ok: true, quantity: want, max: max };
  }
  function setQty(id, qty) {
    var items = read(), max = maxFor(id);
    items.forEach(function (i) { if (i.id === id) i.quantity = Math.max(0, qty < i.quantity ? qty : Math.min(qty, max)); });
    write(items.filter(function (i) { return i.quantity > 0; }));
  }
  function remove(id) { write(read().filter(function (i) { return i.id !== id; })); }
  function clear() { write([]); }

  // ---------- toast ----------
  var toast, toastTimer;
  function showToast(msg, warn) {
    if (!toast) {
      toast = document.createElement('div');
      toast.className = 'vx-toast';
      toast.setAttribute('role', 'status');
      toast.setAttribute('aria-live', 'polite');
      document.body.appendChild(toast);
    }
    toast.innerHTML = '<span class="vx-toast-icon' + (warn ? ' is-warn' : '') + '" aria-hidden="true">' + (warn ? '!' : '&#10003;') + '</span><span>' + esc(msg) + '</span><button type="button" class="vx-toast-link" data-cart-open>View cart</button>';
    toast.classList.add('is-visible');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toast.classList.remove('is-visible'); }, 2600);
  }

  // ---------- drawer ----------
  var drawer, overlay, listEl, footEl, lastFocus;
  function buildDrawer() {
    overlay = document.createElement('div');
    overlay.className = 'cart-overlay';
    overlay.setAttribute('data-cart-close', '');
    drawer = document.createElement('aside');
    drawer.className = 'cart-drawer';
    drawer.id = 'cart-drawer';
    drawer.setAttribute('role', 'dialog');
    drawer.setAttribute('aria-modal', 'true');
    drawer.setAttribute('aria-labelledby', 'cart-title');
    drawer.setAttribute('aria-hidden', 'true');
    drawer.innerHTML =
      '<div class="cart-head">' +
        '<h2 id="cart-title">Your cart <span class="cart-head-count" data-cart-count-text></span></h2>' +
        '<button type="button" class="cart-close" data-cart-close aria-label="Close cart"><span></span><span></span></button>' +
      '</div>' +
      '<div class="cart-body"><ul class="cart-list"></ul></div>' +
      '<div class="cart-foot"></div>';
    document.body.appendChild(overlay);
    document.body.appendChild(drawer);
    listEl = drawer.querySelector('.cart-list');
    footEl = drawer.querySelector('.cart-foot');
  }

  function openDrawer() {
    lastFocus = document.activeElement;
    render();
    document.body.classList.add('cart-open');
    drawer.setAttribute('aria-hidden', 'false');
    document.querySelectorAll('.cart-btn').forEach(function (b) { b.setAttribute('aria-expanded', 'true'); });
    setTimeout(function () { var c = drawer.querySelector('.cart-close'); if (c) c.focus(); }, 60);
  }
  function closeDrawer() {
    if (!document.body.classList.contains('cart-open')) return;
    document.body.classList.remove('cart-open');
    drawer.setAttribute('aria-hidden', 'true');
    document.querySelectorAll('.cart-btn').forEach(function (b) { b.setAttribute('aria-expanded', 'false'); });
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }

  function render() {
    var t = totals();
    // header badges
    document.querySelectorAll('[data-cart-count]').forEach(function (el) {
      el.textContent = t.count > 99 ? '99+' : String(t.count);
      el.hidden = t.count === 0;
    });
    document.querySelectorAll('.cart-btn').forEach(function (b) {
      b.setAttribute('aria-label', 'Open cart, ' + t.count + (t.count === 1 ? ' item' : ' items'));
    });
    if (!drawer) return;
    drawer.querySelector('[data-cart-count-text]').textContent = t.count ? '(' + t.count + ')' : '';

    if (!t.items.length) {
      listEl.innerHTML = '<li class="cart-empty">' + BAG + '<p>Your cart is empty.</p><span>Browse the collection and tap <strong>Add to Cart</strong>.</span></li>';
      footEl.innerHTML = '<a class="btn btn-cart btn-block" href="' + shopHref() + '" data-continue>Continue shopping</a>';
      return;
    }
    var probs = {}; issues(t.items).forEach(function (x) { probs[x.id] = x; });
    var blocked = Object.keys(probs).length > 0;
    listEl.innerHTML = t.items.map(function (i) {
      var pr = probs[i.id], max = maxFor(i.id);
      return '<li class="cart-item' + (pr ? ' has-issue' : '') + '" data-id="' + esc(i.id) + '">' +
        '<img class="cart-item-img" src="' + esc(i.image) + '" alt="" width="80" height="100">' +
        '<div class="cart-item-info">' +
          '<p class="cart-item-name">' + esc(i.name) + '</p>' +
          '<p class="cart-item-price">' + money(i.price) + '</p>' +
          '<div class="cart-item-row">' +
            '<div class="qty" role="group" aria-label="Quantity for ' + esc(i.name) + '">' +
              '<button type="button" class="qty-btn" data-qty="-1" aria-label="Decrease quantity">&minus;</button>' +
              '<span class="qty-val" aria-live="polite">' + i.quantity + '</span>' +
              '<button type="button" class="qty-btn" data-qty="1" aria-label="Increase quantity"' + (i.quantity >= max ? ' disabled' : '') + '>+</button>' +
            '</div>' +
            '<p class="cart-item-sub"><span class="sr-only">Item subtotal </span>' + money(i.price * i.quantity) + '</p>' +
          '</div>' +
          (pr ? '<p class="cart-item-issue" role="alert">' + esc(pr.msg) + '</p>' : '') +
          '<button type="button" class="cart-remove" data-remove>Remove</button>' +
        '</div>' +
      '</li>';
    }).join('');
    footEl.innerHTML =
      '<dl class="totals">' +
        '<div><dt>Subtotal</dt><dd>' + money(t.subtotal) + '</dd></div>' +
        '<div><dt>Delivery / Shipping</dt><dd>' + (t.shipping ? money(t.shipping) : money(0) + ' <small>(Free)</small>') + '</dd></div>' +
        '<div class="totals-grand"><dt>Grand Total</dt><dd>' + money(t.total) + '</dd></div>' +
      '</dl>' +
      freeShipHint(t) +
      '<div class="cart-actions">' +
        (blocked ? '<p class="cart-block-note" role="alert">Please fix the item' + (Object.keys(probs).length > 1 ? 's' : '') + ' marked above to continue.</p><span class="btn btn-cart btn-block" aria-disabled="true">Proceed to checkout</span>'
                 : '<a class="btn btn-cart btn-block" href="checkout.html">Proceed to checkout</a>') +
        '<a class="btn btn-ghost btn-block" href="' + shopHref() + '" data-continue>Continue shopping</a>' +
      '</div>';
  }

  function freeShipHint(t) {
    var s = settings();
    if (!s.freeShippingAbove || !t.shipping) return '';
    var left = s.freeShippingAbove - t.subtotal;
    return left > 0 ? '<p class="cart-ship-hint">Add ' + money(left) + ' more for free delivery.</p>' : '';
  }
  function onIndexPage() { return !!document.querySelector('#shop .products'); }
  function shopHref() { return onIndexPage() ? '#shop' : 'index.html#shop'; }

  // ---------- read a product card ----------
  function productFromCard(card) {
    var img = card.querySelector('.product-media img');
    var nameEl = card.querySelector('.product-name');
    var priceEl = card.querySelector('.product-price');
    var name = nameEl ? nameEl.textContent.trim() : 'Product';
    var live = liveProduct(card.getAttribute('data-id'));
    if (live) return { id: live.id, name: live.name, image: live.image, price: live.price };
    return {
      id: card.getAttribute('data-id') || name.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      name: name,
      image: img ? img.getAttribute('src') : '',
      price: parsePrice(priceEl ? priceEl.textContent : 0)
    };
  }

  // ---------- events ----------
  function init() {
    buildDrawer();
    render();

    document.addEventListener('click', function (e) {
      var addBtn = e.target.closest('[data-add-to-cart]');
      if (addBtn) {
        e.preventDefault();
        var card = addBtn.closest('.product');
        if (!card) return;
        if (addBtn.disabled) return;
        var p = productFromCard(card);
        var res = add(p, 1);
        if (!res.ok) {
          showToast(res.max === 0 ? 'Sorry, ' + p.name + ' is out of stock' : 'Only ' + res.max + ' available \u2014 all are in your cart', true);
          return;
        }
        addBtn.classList.add('is-added');
        setTimeout(function () { addBtn.classList.remove('is-added'); }, 900);
        showToast('Added to Cart \u2014 ' + p.name);
        return;
      }
      if (e.target.closest('[data-cart-open]')) { e.preventDefault(); if (toast) toast.classList.remove('is-visible'); openDrawer(); return; }
      if (e.target.closest('[data-cart-close]')) { e.preventDefault(); closeDrawer(); return; }
      var cont = e.target.closest('[data-continue]');
      if (cont) { closeDrawer(); return; }   // follows the link to the products

      var item = e.target.closest('.cart-item');
      if (item) {
        var id = item.getAttribute('data-id');
        var q = e.target.closest('[data-qty]');
        if (q) {
          var cur = read().filter(function (i) { return i.id === id; })[0];
          if (cur) setQty(id, cur.quantity + Number(q.getAttribute('data-qty')));
          var again = listEl.querySelector('.cart-item[data-id="' + id + '"] [data-qty="' + q.getAttribute('data-qty') + '"]');
          if (again) again.focus();
          return;
        }
        if (e.target.closest('[data-remove]')) { remove(id); var c = drawer.querySelector('.cart-close'); if (c) c.focus(); }
      }
    });

    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeDrawer(); });

    // keep several open tabs in sync
    window.addEventListener('storage', function (e) {
      if (e.key === CART_KEY) { render(); document.dispatchEvent(new CustomEvent('vx:cartchange', { detail: totals() })); }
    });
    // pages restored from the back/forward cache
    window.addEventListener('pageshow', function () { render(); });
    // live price / stock / shipping changes from the store (admin edits)
    function storeChanged() { syncWithStore(); render(); document.dispatchEvent(new CustomEvent('vx:cartchange', { detail: totals() })); }
    document.addEventListener('vx:products', storeChanged);
    document.addEventListener('vx:settings', storeChanged);
    if (Store && Store.cache.productsLoaded) storeChanged();
  }

  // Shared with checkout.js
  window.VXCart = {
    read: read, totals: totals, add: add, setQty: setQty, remove: remove, clear: clear, issues: issues, maxFor: maxFor,
    money: money, esc: esc, open: function () { openDrawer(); }, close: closeDrawer, render: render
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
