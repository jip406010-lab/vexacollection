/* =========================================================
   VEXACOLLECTION — product grid, drawn live from the data layer
   (js/store-api.js). Products, prices, stock and "hidden" are managed
   in the ADMIN PANEL (/admin/); changes appear here without a refresh.
   The 8 products written in index.html are only a fallback shown until
   the store answers (and for search engines).
   ========================================================= */
(function () {
  'use strict';
  var grid = document.querySelector('#shop .products');
  if (!grid || !window.VXStore) return;
  var U = VXStore.util, esc = U.esc, money = U.money;
  var BAG = '<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round" d="M5 8h14l-1 12.5H6L5 8Z"/><path fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" d="M9 10V7a3 3 0 0 1 6 0v3"/></svg>';
  var lastSig = '';

  function card(p) {
    var av = U.availability(p);
    var out = av !== 'in';
    var badge = out ? '<span class="badge badge-out">Sold out</span>'
      : p.bestSeller ? '<span class="badge">Bestseller</span>'
      : p.newArrival ? '<span class="badge">New</span>'
      : p.discount > 0 ? '<span class="badge">' + Math.round(p.discount) + '% off</span>' : '';
    var low = !out && p.stock > 0 && p.stock <= 3 ? '<p class="product-stock">Only ' + p.stock + ' left</p>' : '';
    return '<article class="product reveal' + (out ? ' is-soldout' : '') + '" data-id="' + esc(p.id) + '" data-category="' + esc(p.category) + '">' +
      '<div class="product-media">' +
        '<img src="' + esc(p.image || 'images/favicon.svg') + '" alt="' + esc(p.imageAlt || p.name) + '" width="800" height="1000" loading="lazy">' +
        badge +
      '</div>' +
      '<div class="product-info">' +
        '<h3 class="product-name">' + esc(p.name) + '</h3>' +
        '<p class="product-price">' + money(p.price) + (p.oldPrice > p.price ? ' <s class="product-old">' + money(p.oldPrice) + '</s>' : '') + '</p>' +
        low +
      '</div>' +
      (out
        ? '<button type="button" class="btn btn-cart btn-block add-to-cart" data-add-to-cart disabled aria-disabled="true"><span>Out of stock</span></button>'
        : '<button type="button" class="btn btn-cart btn-block add-to-cart" data-add-to-cart>' + BAG + '<span>Add to Cart</span></button>') +
    '</article>';
  }

  function render(list) {
    if (!list.length && VXStore.mode === 'firebase') return;   // store not filled yet: keep the built-in cards
    var sig = JSON.stringify(list.map(function (p) { return [p.id, p.name, p.price, p.oldPrice, p.image, p.stock, p.status, p.category, p.bestSeller, p.newArrival, p.discount]; }));
    if (sig === lastSig) return;
    lastSig = sig;
    var seen = {};
    grid.querySelectorAll('.product').forEach(function (c) { if (c.classList.contains('is-visible')) seen[c.getAttribute('data-id')] = true; });
    if (!list.length) {
      grid.innerHTML = '<p class="products-empty">New stock is arriving soon. Message us on WhatsApp for the latest styles.</p>';
      return;
    }
    grid.innerHTML = list.map(card).join('');
    grid.querySelectorAll('.product').forEach(function (c, i) {
      if (seen[c.getAttribute('data-id')]) { c.classList.add('is-visible'); c.style.transitionDelay = '0ms'; }
      else if (window.VXReveal) window.VXReveal(c, i); else c.classList.add('is-visible');
    });
    if (window.VXFilter) window.VXFilter.apply(window.VXFilter.current());
  }

  document.addEventListener('vx:products', function (e) { render(e.detail || []); });
  if (VXStore.cache.productsLoaded) render(VXStore.cache.products);
})();
