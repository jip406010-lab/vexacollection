/* =========================================================
   VEXACOLLECTION — DATA LAYER (shared by the shop AND the admin panel)
   ---------------------------------------------------------
   Both the customer website and /admin/ talk ONLY to window.VXStore.
   VXStore picks one of two "adapters":

   1) FirebaseAdapter  (js/firebase-adapter.js) — the REAL shared database.
      Used automatically when js/firebase-config.js has your real Firebase
      values. Customer phones and your admin phone see the same data, live.

   2) LocalDemoAdapter (below) — DEMO MODE. Used while firebase-config.js
      still has the "PASTE_..." placeholders. Data is kept in THIS browser's
      localStorage only. Good for trying everything on one device; it can
      NOT carry a customer's order to your phone. localStorage is not a
      secure database.

   Money is in rupees (numbers). Statuses are UPPERCASE codes:
     orderStatus   NEW | CONFIRMED | PROCESSING | SHIPPED | OUT_FOR_DELIVERY | DELIVERED | CANCELLED
     paymentStatus PENDING | PAID | FAILED | REFUNDED | COD
   UPI payments are NEVER marked PAID automatically — only by the admin,
   by hand, after checking the money arrived in the UPI app.
   ========================================================= */
(function () {
  'use strict';

  var CFG = (typeof STORE_CONFIG !== 'undefined') ? STORE_CONFIG : {};
  var SCRIPT_SRC = (document.currentScript && document.currentScript.src) || '';

  /* ---------------- shared helpers ---------------- */
  var ORDER_STATUSES = ['NEW', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'];
  var PAYMENT_STATUSES = ['PENDING', 'PAID', 'FAILED', 'REFUNDED', 'COD'];
  var CATEGORIES = [
    { id: 'shirts', label: 'Shirts' }, { id: 'tshirts', label: 'T-Shirts' },
    { id: 'bottoms', label: 'Jeans & Trousers' }, { id: 'jackets', label: 'Jackets' }, { id: 'other', label: 'Other' }
  ];
  function label(code) {
    var map = { OUT_FOR_DELIVERY: 'Out for delivery', OUT_OF_STOCK: 'Out of stock', COD: 'COD' };
    if (map[code]) return map[code];
    code = String(code || '');
    return code.charAt(0) + code.slice(1).toLowerCase().replace(/_/g, ' ');
  }
  function round2(n) { return Math.round(Number(n || 0) * 100) / 100; }
  function num(v, d) { var n = Number(v); return isFinite(n) ? n : (d || 0); }
  var inrFmt = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });
  function money(n) { return '\u20B9' + inrFmt.format(round2(n)); }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function clone(o) { return o == null ? o : JSON.parse(JSON.stringify(o)); }
  function nowIso() { return new Date().toISOString(); }

  var DEFAULT_SETTINGS = {
    brandName: CFG.brandName || 'VEXACOLLECTION',
    phone: CFG.phone || '+916394692521',
    whatsapp: CFG.whatsapp || '916394692521',
    address: CFG.address || 'GHOSI, MAU, UTTAR PRADESH, 275301',
    email: CFG.email || '',
    upiId: CFG.upiId || 'YOUR_UPI_ID_HERE',
    merchantName: CFG.merchantName || CFG.brandName || 'VEXACOLLECTION',
    paymentInstructions: 'Scan the QR or tap Pay Now, pay the exact amount, then submit your order. We check every UPI payment by hand.',
    shippingCharge: num(CFG.shipping, 0),
    freeShippingAbove: 0,
    estimatedDelivery: '3\u20137 working days',
    currency: CFG.currency || 'INR'
  };
  function normSettings(s) {
    var out = {};
    Object.keys(DEFAULT_SETTINGS).forEach(function (k) {
      out[k] = (s && s[k] != null && s[k] !== '') ? s[k] : DEFAULT_SETTINGS[k];
    });
    out.shippingCharge = Math.max(0, num(out.shippingCharge));
    out.freeShippingAbove = Math.max(0, num(out.freeShippingAbove));
    return out;
  }

  // Product availability seen by customers: 'in' | 'out' | 'hidden'
  function availability(p) {
    if (!p || p.status === 'HIDDEN') return 'hidden';
    if (p.status === 'OUT_OF_STOCK' || num(p.stock) <= 0) return 'out';
    return 'in';
  }
  function shippingFor(subtotal, s) {
    s = s || DEFAULT_SETTINGS;
    if (subtotal <= 0) return 0;
    if (s.freeShippingAbove > 0 && subtotal >= s.freeShippingAbove) return 0;
    return round2(s.shippingCharge);
  }
  function couponExpired(c, now) {
    if (!c.expiry) return false;
    var end = new Date(String(c.expiry).slice(0, 10) + 'T23:59:59+05:30');
    return isFinite(end) && (now || new Date()) > end;
  }
  // -> { ok, discount, message }
  function evalCoupon(c, subtotal) {
    if (!c) return { ok: false, discount: 0, message: 'This coupon code is not valid.' };
    if (c.enabled === false) return { ok: false, discount: 0, message: 'This coupon is not active right now.' };
    if (couponExpired(c)) return { ok: false, discount: 0, message: 'This coupon has expired.' };
    if (num(c.usageLimit) > 0 && num(c.usedCount) >= num(c.usageLimit)) return { ok: false, discount: 0, message: 'This coupon has reached its usage limit.' };
    if (num(c.minOrder) > 0 && subtotal < num(c.minOrder)) return { ok: false, discount: 0, message: 'Add items worth ' + money(c.minOrder - subtotal) + ' more to use this coupon (minimum order ' + money(c.minOrder) + ').' };
    var d = c.type === 'percent' ? subtotal * num(c.value) / 100 : num(c.value);
    if (c.type === 'percent' && num(c.maxDiscount) > 0) d = Math.min(d, num(c.maxDiscount));
    d = round2(Math.max(0, Math.min(d, subtotal)));
    if (d <= 0) return { ok: false, discount: 0, message: 'This coupon gives no discount on this order.' };
    return { ok: true, discount: d, message: (c.type === 'percent' ? num(c.value) + '% off' : money(c.value) + ' off') + ' applied' };
  }
  // items: [{price, quantity}]  -> { subtotal, shipping, discount, total }
  function calc(items, settings, coupon) {
    var subtotal = 0;
    (items || []).forEach(function (i) { subtotal += num(i.price) * num(i.quantity != null ? i.quantity : i.qty); });
    subtotal = round2(subtotal);
    var shipping = shippingFor(subtotal, settings);
    var cr = coupon ? evalCoupon(coupon, subtotal) : null;
    var discount = cr && cr.ok ? cr.discount : 0;
    return { subtotal: subtotal, shipping: shipping, discount: discount, total: round2(subtotal - discount + shipping), coupon: cr };
  }
  function productFromInput(p) {
    var price = round2(num(p.price)), old = round2(num(p.oldPrice));
    var out = {
      id: p.id, sku: String(p.sku || p.id || '').trim().toUpperCase(),
      name: String(p.name || '').trim(), category: p.category || 'other',
      description: String(p.description || '').trim(),
      price: price, oldPrice: old > price ? old : 0,
      discount: num(p.discount) > 0 ? Math.round(num(p.discount)) : (old > price ? Math.round((old - price) / old * 100) : 0),
      stock: Math.max(0, Math.floor(num(p.stock))),
      image: p.image || '', imageAlt: p.imageAlt || p.name || '',
      images: Array.isArray(p.images) ? p.images.filter(Boolean).slice(0, 4) : [],
      featured: !!p.featured, bestSeller: !!p.bestSeller, newArrival: !!p.newArrival,
      status: ['ACTIVE', 'OUT_OF_STOCK', 'HIDDEN'].indexOf(p.status) >= 0 ? p.status : 'ACTIVE',
      sort: num(p.sort, 999)
    };
    out.visible = out.status !== 'HIDDEN';   // Firestore rules/queries use this flag
    return out;
  }
  function newProductId() { return 'vx-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); }
  function sortProducts(list) { return list.slice().sort(function (a, b) { return num(a.sort, 999) - num(b.sort, 999) || String(a.name).localeCompare(String(b.name)); }); }
  function normPhone(v) {
    var d = String(v || '').replace(/\D/g, '');
    if (d.length === 12 && d.indexOf('91') === 0) d = d.slice(2);
    else if (d.length === 11 && d.charAt(0) === '0') d = d.slice(1);
    return d;
  }

  function firebaseConfigured() {
    var c = window.VX_FIREBASE_CONFIG;
    if (!c || !c.apiKey || !c.projectId || !c.appId) return false;
    return !/PASTE|YOUR_|XXXX/i.test(c.apiKey + c.projectId + c.appId);
  }

  /* =========================================================
     LocalDemoAdapter — localStorage, one browser only
     ========================================================= */
  function LocalDemoAdapter() {
    var K = { products: 'vx_db_products', orders: 'vx_db_orders', settings: 'vx_db_settings', coupons: 'vx_db_coupons',
      customers: 'vx_db_customers', payments: 'vx_db_payments', tracking: 'vx_db_tracking', seeded: 'vx_db_seeded' };
    var subs = {};
    function read(key, dflt) { try { var v = JSON.parse(localStorage.getItem(key)); return v == null ? dflt : v; } catch (e) { return dflt; } }
    function write(key, val) {
      try { localStorage.setItem(key, JSON.stringify(val)); }
      catch (e) { throw new Error('This browser\u2019s storage is full. Use smaller photos (or connect Firebase).'); }
      emit(key);
    }
    function emit(key) { (subs[key] || []).slice().forEach(function (fn) { try { fn(); } catch (e) { console.error(e); } }); }
    function on(key, fn) { (subs[key] = subs[key] || []).push(fn); return function () { subs[key] = (subs[key] || []).filter(function (f) { return f !== fn; }); }; }
    window.addEventListener('storage', function (e) { if (e.key && subs[e.key]) emit(e.key); });

    function seedIfNeeded() {
      if (read(K.seeded, false)) return;
      var seed = (window.VX_SEED_PRODUCTS || []).map(function (p) { var x = productFromInput(p); x.createdAt = nowIso(); x.updatedAt = x.createdAt; return x; });
      if (!read(K.products, null)) localStorage.setItem(K.products, JSON.stringify(seed));
      if (!read(K.settings, null)) localStorage.setItem(K.settings, JSON.stringify(normSettings({})));
      if (!read(K.coupons, null)) localStorage.setItem(K.coupons, '[]');
      localStorage.setItem(K.seeded, 'true');
    }

    var products = function () { return read(K.products, []); };
    var orders = function () { return read(K.orders, []); };
    function watch(key, getter, cb) { cb(getter()); return on(key, function () { cb(getter()); }); }

    function err(code, msg, extra) { var e = new Error(msg); e.code = code; if (extra) Object.keys(extra).forEach(function (k) { e[k] = extra[k]; }); return e; }

    var A = {
      mode: 'demo',
      init: function () { seedIfNeeded(); return Promise.resolve(); },

      /* ----- public (customer) ----- */
      watchProducts: function (cb, opts) {
        var all = opts && opts.all;
        return watch(K.products, function () { return sortProducts(products().filter(function (p) { return all || p.status !== 'HIDDEN'; })); }, cb);
      },
      watchSettings: function (cb) { return watch(K.settings, function () { return normSettings(read(K.settings, {})); }, cb); },
      getCoupon: function (code) {
        code = String(code || '').trim().toUpperCase();
        return Promise.resolve(clone(read(K.coupons, []).filter(function (c) { return c.code === code; })[0] || null));
      },
      placeOrder: function (order) {
        return new Promise(function (resolve, reject) {
          var list = products(), byId = {};
          list.forEach(function (p) { byId[p.id] = p; });
          for (var i = 0; i < order.products.length; i++) {
            var it = order.products[i], p = byId[it.id];
            if (!p || availability(p) === 'hidden') return reject(err('unavailable', '\u201C' + it.name + '\u201D is no longer available. Please remove it from your cart.', { productId: it.id }));
            if (availability(p) === 'out') return reject(err('out-of-stock', '\u201C' + it.name + '\u201D is out of stock. Please remove it from your cart.', { productId: it.id, stock: 0 }));
            if (num(p.stock) < it.qty) return reject(err('out-of-stock', 'Only ' + p.stock + ' left of \u201C' + it.name + '\u201D. Please reduce the quantity.', { productId: it.id, stock: num(p.stock) }));
          }
          var coupons = read(K.coupons, []), cp = null;
          if (order.couponCode) {
            cp = coupons.filter(function (c) { return c.code === order.couponCode; })[0];
            var r = evalCoupon(cp, order.subtotal);
            if (!r.ok) return reject(err('coupon', r.message));
          }
          var all = orders();
          if (all.some(function (o) { return o.orderId === order.orderId; })) return reject(err('duplicate-id', 'Order ID already used'));
          order = clone(order);
          order.createdAt = nowIso();
          order.stockDeducted = true; order.stockRestored = false;
          order.statusHistory = [{ status: 'NEW', at: order.createdAt }];
          order.products.forEach(function (it) { byId[it.id].stock = num(byId[it.id].stock) - it.qty; byId[it.id].updatedAt = order.createdAt; });
          if (cp) { cp.usedCount = num(cp.usedCount) + 1; write(K.coupons, coupons); }
          write(K.products, list);
          var pays = read(K.payments, []);
          pays.push({ orderId: order.orderId, amount: order.total, method: order.paymentMethod, status: order.paymentStatus, createdAt: order.createdAt });
          localStorage.setItem(K.payments, JSON.stringify(pays));
          var tr = read(K.tracking, {});
          tr[order.orderId] = { orderStatus: 'NEW', paymentStatus: order.paymentStatus, updatedAt: order.createdAt };
          write(K.tracking, tr);
          all.push(order);
          write(K.orders, all);
          resolve(order);
        });
      },
      watchTracking: function (orderId, cb) { return watch(K.tracking, function () { return read(K.tracking, {})[orderId] || null; }, cb); },

      /* ----- admin ----- */
      watchOrders: function (cb) {
        var known = null;
        return watch(K.orders, function () { return orders(); }, function (list) {
          var ids = list.map(function (o) { return o.orderId; });
          var added = known ? list.filter(function (o) { return known.indexOf(o.orderId) === -1; }) : [];
          known = ids;
          cb(list.slice().sort(function (a, b) { return String(b.createdAt).localeCompare(String(a.createdAt)); }), { added: added });
        });
      },
      updateOrder: function (orderId, patch) {
        return new Promise(function (resolve, reject) {
          var all = orders(), o = all.filter(function (x) { return x.orderId === orderId; })[0];
          if (!o) return reject(err('not-found', 'Order not found'));
          var list = products(), byId = {};
          list.forEach(function (p) { byId[p.id] = p; });
          var now = nowIso(), touchedStock = false;
          var next = patch.orderStatus || o.orderStatus;
          if (next === 'CANCELLED' && o.orderStatus !== 'CANCELLED' && o.stockDeducted && !o.stockRestored) {
            o.products.forEach(function (it) { if (byId[it.id]) { byId[it.id].stock = num(byId[it.id].stock) + it.qty; byId[it.id].updatedAt = now; } });
            o.stockRestored = true; touchedStock = true;
          } else if (next !== 'CANCELLED' && o.orderStatus === 'CANCELLED' && o.stockRestored) {
            o.products.forEach(function (it) { if (byId[it.id]) { byId[it.id].stock = Math.max(0, num(byId[it.id].stock) - it.qty); byId[it.id].updatedAt = now; } });
            o.stockRestored = false; touchedStock = true;
          }
          if (patch.orderStatus && patch.orderStatus !== o.orderStatus) {
            o.statusHistory = (o.statusHistory || []).concat([{ status: patch.orderStatus, at: now }]);
            o.orderStatus = patch.orderStatus;
          }
          if (patch.paymentStatus && patch.paymentStatus !== o.paymentStatus) {
            o.paymentHistory = (o.paymentHistory || []).concat([{ status: patch.paymentStatus, at: now, by: 'admin (manual)' }]);
            o.paymentStatus = patch.paymentStatus;
            if (patch.paymentStatus === 'PAID') { o.paidAt = now; o.paymentVerifiedBy = 'admin (manual check)'; }
          }
          if (patch.adminNote != null) o.adminNote = String(patch.adminNote);
          o.updatedAt = now;
          if (touchedStock) write(K.products, list);
          var pays = read(K.payments, []);
          pays.forEach(function (p) { if (p.orderId === orderId) { p.status = o.paymentStatus; p.updatedAt = now; } });
          localStorage.setItem(K.payments, JSON.stringify(pays));
          var tr = read(K.tracking, {});
          tr[orderId] = { orderStatus: o.orderStatus, paymentStatus: o.paymentStatus, updatedAt: now };
          write(K.tracking, tr);
          write(K.orders, all);
          resolve(clone(o));
        });
      },
      saveProduct: function (p) {
        return new Promise(function (resolve) {
          var list = products(), now = nowIso();
          var x = productFromInput(p);
          if (!x.id) { x.id = newProductId(); if (!x.sku) x.sku = x.id.toUpperCase(); x.createdAt = now; x.sort = list.length + 1; }
          var i = list.map(function (q) { return q.id; }).indexOf(x.id);
          if (i >= 0) { x.createdAt = list[i].createdAt; if (p.sort == null) x.sort = list[i].sort; list[i] = x; } else { x.createdAt = x.createdAt || now; list.push(x); }
          x.updatedAt = now;
          write(K.products, list);
          resolve(clone(x));
        });
      },
      updateProduct: function (id, patch) {
        var list = products(), p = list.filter(function (q) { return q.id === id; })[0];
        if (!p) return Promise.reject(err('not-found', 'Product not found'));
        Object.keys(patch).forEach(function (k) { p[k] = patch[k]; });
        if (patch.status) p.visible = patch.status !== 'HIDDEN';
        if (patch.stock != null) p.stock = Math.max(0, Math.floor(num(patch.stock)));
        p.updatedAt = nowIso();
        write(K.products, list);
        return Promise.resolve(clone(p));
      },
      deleteProduct: function (id) { write(K.products, products().filter(function (p) { return p.id !== id; })); return Promise.resolve(); },
      importSampleProducts: function (overwrite) {
        var list = products(), ids = list.map(function (p) { return p.id; }), n = 0;
        (window.VX_SEED_PRODUCTS || []).forEach(function (s) {
          var x = productFromInput(s); x.createdAt = x.updatedAt = nowIso();
          var i = ids.indexOf(x.id);
          if (i === -1) { list.push(x); n++; } else if (overwrite) { list[i] = x; n++; }
        });
        write(K.products, list);
        return Promise.resolve(n);
      },
      watchCoupons: function (cb) { return watch(K.coupons, function () { return read(K.coupons, []); }, cb); },
      saveCoupon: function (c, oldCode) {
        var list = read(K.coupons, []);
        c = clone(c); c.code = String(c.code).trim().toUpperCase();
        if (oldCode && oldCode !== c.code) list = list.filter(function (x) { return x.code !== oldCode; });
        var i = list.map(function (x) { return x.code; }).indexOf(c.code);
        if (i >= 0) { c.usedCount = num(list[i].usedCount); c.createdAt = list[i].createdAt; list[i] = c; }
        else { c.usedCount = num(c.usedCount); c.createdAt = nowIso(); list.push(c); }
        write(K.coupons, list);
        return Promise.resolve(c);
      },
      deleteCoupon: function (code) { write(K.coupons, read(K.coupons, []).filter(function (c) { return c.code !== code; })); return Promise.resolve(); },
      saveSettings: function (s) { var x = normSettings(Object.assign({}, read(K.settings, {}), s)); write(K.settings, x); return Promise.resolve(x); },
      syncCustomers: function () { return Promise.resolve(); },   // demo: customers are worked out from orders
      uploadImage: null,                                          // demo: photos stay as compressed data-URLs
      clearDemoData: function () {
        Object.keys(K).forEach(function (k) { localStorage.removeItem(K[k]); });
        ['vx_orders', 'vx_cart'].forEach(function (k) { localStorage.removeItem(k); });
      },

      /* ----- DEMO admin login -----
         Demo only: password is chosen on first visit and stored in this
         browser as a salted PBKDF2-SHA-256 hash. It protects nothing on the
         server (there is no server). REAL login = Firebase Auth (see
         firebase-adapter.js), used automatically once Firebase is set up. */
      auth: (function () {
        var CRED = 'vx_admin_cred', SESS = 'vx_admin_session', listeners = [];
        function hex(buf) { return Array.prototype.map.call(new Uint8Array(buf), function (b) { return ('0' + b.toString(16)).slice(-2); }).join(''); }
        function hash(pw, saltHex, iters) {
          var enc = new TextEncoder();
          var salt = new Uint8Array(saltHex.match(/../g).map(function (h) { return parseInt(h, 16); }));
          return crypto.subtle.importKey('raw', enc.encode(pw), 'PBKDF2', false, ['deriveBits']).then(function (key) {
            return crypto.subtle.deriveBits({ name: 'PBKDF2', salt: salt, iterations: iters, hash: 'SHA-256' }, key, 256);
          }).then(hex);
        }
        function session() {
          var s = null;
          try { s = JSON.parse(sessionStorage.getItem(SESS) || localStorage.getItem(SESS) || 'null'); } catch (e) {}
          return s;
        }
        function fire() { var u = cur(); listeners.forEach(function (f) { f(u); }); }
        function cur() { var s = session(); return s && s.username ? { id: s.username, name: s.username, email: '', demo: true } : null; }
        return {
          kind: 'demo',
          needsSetup: function () { return !read(CRED, null); },
          setup: function (username, pw) {
            if (read(CRED, null)) return Promise.reject(err('exists', 'An admin password already exists on this device.'));
            var salt = new Uint8Array(16); crypto.getRandomValues(salt);
            var sh = hex(salt), it = 150000;
            return hash(pw, sh, it).then(function (h) {
              localStorage.setItem(CRED, JSON.stringify({ username: String(username).trim().toLowerCase(), salt: sh, hash: h, iterations: it, algo: 'PBKDF2-SHA-256', createdAt: nowIso() }));
            });
          },
          login: function (username, pw, remember) {
            var c = read(CRED, null);
            if (!c) return Promise.reject(err('no-admin', 'Create the admin password first.'));
            return hash(pw, c.salt, c.iterations).then(function (h) {
              if (h !== c.hash || String(username).trim().toLowerCase() !== c.username) throw err('bad-login', 'Wrong username or password.');
              var s = JSON.stringify({ username: c.username, at: nowIso() });
              sessionStorage.removeItem(SESS); localStorage.removeItem(SESS);
              (remember ? localStorage : sessionStorage).setItem(SESS, s);
              fire();
              return cur();
            });
          },
          logout: function () { sessionStorage.removeItem(SESS); localStorage.removeItem(SESS); fire(); return Promise.resolve(); },
          current: cur,
          onChange: function (fn) { listeners.push(fn); fn(cur()); return function () { listeners = listeners.filter(function (f) { return f !== fn; }); }; },
          resetDemoPassword: function () { localStorage.removeItem(CRED); sessionStorage.removeItem(SESS); localStorage.removeItem(SESS); fire(); }
        };
      })()
    };
    return A;
  }

  /* =========================================================
     VXStore facade
     ========================================================= */
  var adapter = null;
  var cache = { products: [], settings: normSettings({}), productsLoaded: false };
  var readyResolve, readyReject;
  var ready = new Promise(function (res, rej) { readyResolve = res; readyReject = rej; });

  function useAdapter(a) {
    adapter = a;
    VXStore.mode = a.mode;
    VXStore.adapter = a;
    return a.init();
  }

  var VXStore = {
    mode: firebaseConfigured() ? 'firebase' : 'demo',
    ready: ready,
    cache: cache,
    adapter: null,
    error: null,
    util: {
      ORDER_STATUSES: ORDER_STATUSES, PAYMENT_STATUSES: PAYMENT_STATUSES, CATEGORIES: CATEGORIES,
      label: label, money: money, esc: esc, round2: round2, num: num, calc: calc, evalCoupon: evalCoupon,
      shippingFor: shippingFor, availability: availability, normSettings: normSettings, normPhone: normPhone,
      productFromInput: productFromInput, couponExpired: couponExpired, DEFAULT_SETTINGS: DEFAULT_SETTINGS
    },
    // Live product list for the shop (hidden products excluded). cb(list)
    watchProducts: function (cb, opts) { var un = null, stop = false; ready.then(function () { if (!stop) un = adapter.watchProducts(cb, opts); }); return function () { stop = true; if (un) un(); }; },
    watchSettings: function (cb) { var un = null, stop = false; ready.then(function () { if (!stop) un = adapter.watchSettings(cb); }); return function () { stop = true; if (un) un(); }; },
    getProduct: function (id) { return cache.products.filter(function (p) { return p.id === id; })[0] || null; },
    getCoupon: function (code) { return ready.then(function () { return adapter.getCoupon(code); }); },
    placeOrder: function (order) { return ready.then(function () { return adapter.placeOrder(order); }); },
    watchTracking: function (id, cb) { var un = null, stop = false; ready.then(function () { if (!stop) un = adapter.watchTracking(id, cb); }); return function () { stop = true; if (un) un(); }; }
  };
  window.VXStore = VXStore;

  function startCaches() {
    adapter.watchSettings(function (s) { cache.settings = s; document.dispatchEvent(new CustomEvent('vx:settings', { detail: s })); });
    adapter.watchProducts(function (list) { cache.products = list; cache.productsLoaded = true; document.dispatchEvent(new CustomEvent('vx:products', { detail: list })); });
  }

  if (VXStore.mode === 'firebase') {
    var url = new URL('firebase-adapter.js', SCRIPT_SRC || location.href).href;
    import(url).then(function (m) {
      return useAdapter(m.createFirebaseAdapter(window.VX_FIREBASE_CONFIG, { helpers: VXStore.util, useStorage: !!window.VX_FIREBASE_USE_STORAGE }));
    }).then(function () { startCaches(); readyResolve(VXStore); })
      .catch(function (e) {
        console.error('[VXStore] Firebase could not start:', e);
        VXStore.error = e;
        readyReject(e);
        document.dispatchEvent(new CustomEvent('vx:storeerror', { detail: e }));
      });
  } else {
    useAdapter(LocalDemoAdapter()).then(function () { startCaches(); readyResolve(VXStore); });
  }
  ready.catch(function () {});
})();
