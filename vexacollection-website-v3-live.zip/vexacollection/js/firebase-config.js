/* =========================================================
   VEXACOLLECTION — FIREBASE CONNECTION (fill this in to go live)
   ---------------------------------------------------------
   While these values say "PASTE_...", the website and admin panel run
   in DEMO MODE: everything is saved only in the browser you are using,
   so orders from customers' phones will NOT reach your admin panel.

   To receive real orders, follow SETUP-FIREBASE.md and paste the
   "firebaseConfig" values from Firebase Console → Project settings →
   Your apps → Web app. These are PUBLIC identifiers (every Firebase
   website shows them) — they are safe here. Security comes from
   firestore.rules + the admin login, not from hiding these values.

   NEVER put a service-account JSON, "private_key", Admin SDK key,
   payment-gateway secret or any password in this file.
   ========================================================= */
window.VX_FIREBASE_CONFIG = {
  apiKey: "AIzaSyAiKmbJH2rz_okzTWKBFzMq5ZzS5sjBb9E",
  authDomain: "vexacollection-630ed.firebaseapp.com",
  projectId: "vexacollection-630ed",
  storageBucket: "vexacollection-630ed.firebasestorage.app",
  messagingSenderId: "408647200733",
  appId: "1:408647200733:web:c963bffb02730c065b5034",
  databaseId: "default"
};

/* Optional: upload product photos to Firebase Storage.
   New Firebase projects need the paid "Blaze" plan for Storage, so this is
   OFF by default — photos are then compressed and saved inside the product
   record (works on the free Spark plan). Set to true only after you have
   enabled Storage and deployed storage.rules. */
window.VX_FIREBASE_USE_STORAGE = false;
