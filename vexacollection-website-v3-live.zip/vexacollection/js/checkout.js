/* =========================================================
   VEXACOLLECTION — checkout, UPI QR, order confirmation, invoice
   Plain JavaScript. Uses STORE_CONFIG (js/config.js), VXCart (js/cart.js)
   and the bundled QR library (js/vendor/qrcode.js, MIT licence).

   v3: orders go through the shared DATA LAYER (js/store-api.js):
   - With Firebase connected, the order is saved in the store's database
     (the admin panel sees it instantly) and stock is lowered.
   - In DEMO MODE (no Firebase yet) it is saved only in this browser.
   A copy is always kept in this browser ("vx_orders") for "View order".
   - UPI payments are NOT verified automatically. Every UPI order is saved
     with paymentStatus "pending" (shown as PAYMENT VERIFICATION PENDING)
     until the store checks its UPI app / bank statement.
   - The store learns about an order when the customer taps
     "Send order invoice on WhatsApp" (opens WhatsApp with the invoice text;
     the customer presses Send). See the BACKEND HOOKS below for the
     automatic version.
   ========================================================= */
(function () {
  'use strict';

  var Store = window.VXStore, U = Store.util;
  // Store settings (UPI ID, merchant name, shipping…) come live from the
  // admin panel's Settings; js/config.js only gives the starting values.
  function liveCfg() { return Object.assign({}, STORE_CONFIG, Store.cache.settings, { brandName: Store.cache.settings.brandName || STORE_CONFIG.brandName }); }
  var CFG = liveCfg();
  var ORDERS_KEY = 'vx_orders';
  var PENDING_ID_KEY = 'vx_pending_order_id';
  var UPI_PLACEHOLDER = 'YOUR_UPI_ID_HERE';
  var WA_NUMBER = '';
  function refreshCfg() { CFG = liveCfg(); WA_NUMBER = String(CFG.whatsapp || CFG.phone || '').replace(/\D/g, ''); if (WA_NUMBER.length === 10) WA_NUMBER = '91' + WA_NUMBER; }
  refreshCfg();
  var money = VXCart.money, esc = VXCart.esc;
  var appliedCoupon = null;   // coupon object from the store, once applied

  /* =======================================================
     BACKEND HOOKS — where a real server / payment gateway plugs in
     ======================================================= */

  // Called when the customer places an order. Today it only saves the order
  // in this browser. To connect a backend later, send `order` to your server
  // here (e.g. fetch('https://your-api.example/orders', { method: 'POST',
  // headers: {'Content-Type':'application/json'}, body: JSON.stringify(order) }))
  // and only show the confirmation after the server answers OK.
  // A payment gateway (Razorpay, Cashfree, PhonePe PG, etc.) would create its
  // payment on YOUR SERVER (secret keys live only there, never in this file)
  // and the server would set paymentStatus to "paid" after verifying the
  // gateway's signature/webhook. Until then paymentStatus stays "pending".
  function submitOrder(order) {
    // VXStore.placeOrder: Firebase transaction (order + stock + coupon) or demo storage.
    return Store.placeOrder(order).then(function (saved) {
      saveOrderLocally(saved);          // customer's own copy for "View order"
      notifyStoreOnWhatsApp(saved);
      return saved;
    });
  }

  // STUB — fully AUTOMATIC WhatsApp invoices (sent to the store and to the
  // customer without anyone pressing Send) need a backend using the official
  // WhatsApp Business (Cloud) API with an approved message template. That
  // cannot be done safely from a public website, so it is NOT faked here.
  // Today the customer sends the invoice with the
  // "Send order invoice on WhatsApp" button (wa.me link with the text prefilled).
  function notifyStoreOnWhatsApp(order) {
    return null;
  }

  /* ======================================================= */

  function upiReady() {
    var id = String(CFG.upiId || '').trim();
    return id && id !== UPI_PLACEHOLDER && /^[\w.\-]{2,256}@[a-zA-Z][\w.\-]{1,64}$/.test(id);
  }

  // upi://pay?pa=<UPI_ID>&pn=VEXACOLLECTION&am=<TOTAL>&cu=INR&tn=<order ref>
  function upiUri(total, orderId) {
    function enc(v) { return encodeURIComponent(v).replace(/%40/g, '@'); } // keep "@" readable for UPI apps
    var parts = [
      'pa=' + enc(String(CFG.upiId).trim()),
      'pn=' + enc(CFG.merchantName || CFG.brandName || 'VEXACOLLECTION'),
      'am=' + Number(total).toFixed(2),
      'cu=' + enc(CFG.currency || 'INR')
    ];
    if (orderId && CFG.upiNoteWithOrderId !== false) parts.push('tn=' + enc('Order ' + orderId));
    return 'upi://pay?' + parts.join('&');
  }

  function readOrders() {
    try { var a = JSON.parse(localStorage.getItem(ORDERS_KEY) || '[]'); return Array.isArray(a) ? a : []; }
    catch (e) { return []; }
  }
  function saveOrderLocally(order) {
    var orders = readOrders();
    orders.push(order);
    localStorage.setItem(ORDERS_KEY, JSON.stringify(orders));
  }
  function findOrder(id) { return readOrders().filter(function (o) { return o.orderId === id; })[0]; }

  // Order ID: VX-YYYYMMDD-XXXX (4 random letters/digits), unique on this device
  function newOrderId() {
    var chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    var d = new Date();
    var date = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
    var taken = readOrders().map(function (o) { return o.orderId; });
    for (var tries = 0; tries < 50; tries++) {
      var rnd = '', bytes = new Uint8Array(4);
      (window.crypto || window.msCrypto).getRandomValues(bytes);
      for (var i = 0; i < 4; i++) rnd += chars[bytes[i] % chars.length];
      var id = 'VX-' + date + '-' + rnd;
      if (taken.indexOf(id) === -1) return id;
    }
    return 'VX-' + date + '-' + Date.now().toString(36).slice(-4).toUpperCase();
  }
  function pendingOrderId() {
    var id = null;
    try { id = sessionStorage.getItem(PENDING_ID_KEY); } catch (e) {}
    if (!id || findOrder(id)) {
      id = newOrderId();
      try { sessionStorage.setItem(PENDING_ID_KEY, id); } catch (e) {}
    }
    return id;
  }

  function fmtDate(iso) {
    try {
      return new Date(iso).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true }) + ' IST';
    } catch (e) { return iso; }
  }
  function fmtMobile(m) { m = String(m || ''); return m.length === 10 ? '+91 ' + m.slice(0, 5) + ' ' + m.slice(5) : m; }
  // Works with v3 orders and older v2 copies saved in this browser
  function norm(o) {
    if (!o) return o;
    o = JSON.parse(JSON.stringify(o));
    if (!o.customer) o.customer = { name: o.customerName, mobile: o.phone, email: o.email || '' };
    if (!o.items) o.items = o.products || [];
    if (o.discount == null) o.discount = 0;
    if (o.paymentStatus === 'pending') o.paymentStatus = o.paymentMethod === 'COD' ? 'COD' : 'PENDING';
    if (!o.orderStatus || o.orderStatus === 'placed') o.orderStatus = 'NEW';
    return o;
  }
  function statusText(o) {
    if (o.orderStatus === 'CANCELLED') return 'Cancelled';
    if (o.orderStatus && o.orderStatus !== 'NEW') return U.label(o.orderStatus);
    if (o.paymentMethod === 'COD') return 'Cash on Delivery \u2013 Order Placed';
    return o.paymentStatus === 'PAID' ? 'Order placed \u2013 payment received' : 'Payment Verification Pending';
  }
  function statusClass(o) {
    if (o.orderStatus === 'CANCELLED') return 'status-cancelled';
    if (o.orderStatus === 'DELIVERED' || o.paymentStatus === 'PAID') return 'status-ok';
    return o.paymentMethod === 'COD' ? 'status-cod' : 'status-pending';
  }
  function paymentText(o) {
    return ({ PAID: 'PAID (verified by the store)', PENDING: 'PAYMENT VERIFICATION PENDING', COD: 'Cash on Delivery (pay on delivery)', FAILED: 'FAILED', REFUNDED: 'REFUNDED' })[o.paymentStatus] || 'PAYMENT VERIFICATION PENDING';
  }
  function methodText(o) { return o.paymentMethod === 'COD' ? 'Cash on Delivery' : 'UPI'; }
  function shipText(n) { return n ? money(n) : money(0) + ' (Free)'; }

  /* =======================================================
     CHECKOUT FORM
     ======================================================= */
  var form = document.getElementById('checkout-form');
  var viewCheckout = document.getElementById('view-checkout');
  var viewResult = document.getElementById('view-result');
  var orderId = null;
  var currentTotals = null;

  function el(id) { return document.getElementById(id); }
  function method() { var r = form.querySelector('input[name="paymentMethod"]:checked'); return r ? r.value : 'UPI'; }

  function normMobile(v) {
    var d = String(v || '').replace(/\D/g, '');
    if (d.length === 12 && d.indexOf('91') === 0) d = d.slice(2);
    else if (d.length === 11 && d.charAt(0) === '0') d = d.slice(1);
    return d;
  }

  var rules = {
    fullName: function (v) { v = v.trim(); if (!v) return 'Please enter your full name.'; if (v.length < 2) return 'Name looks too short.'; return ''; },
    mobile: function (v) { if (!v.trim()) return 'Please enter your mobile number.'; return /^[6-9]\d{9}$/.test(normMobile(v)) ? '' : 'Enter a valid 10-digit Indian mobile number (starts with 6, 7, 8 or 9).'; },
    email: function (v) { v = v.trim(); if (!v) return ''; return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v) ? '' : 'Enter a valid email address, or leave it empty.'; },
    house: function (v) { return v.trim() ? '' : 'Please enter your house no. / building name.'; },
    street: function (v) { return v.trim() ? '' : 'Please enter your road name / area / colony.'; },
    city: function (v) { return v.trim() ? '' : 'Please enter your city / district.'; },
    state: function (v) { return v ? '' : 'Please select your state.'; },
    pin: function (v) { v = v.trim(); if (!v) return 'Please enter your PIN code.'; return /^[1-9]\d{5}$/.test(v) ? '' : 'Enter a valid 6-digit PIN code.'; },
    upiRef: function (v) { v = v.trim(); if (!v || method() !== 'UPI') return ''; return /^[A-Za-z0-9]{6,22}$/.test(v) ? '' : 'UTR should be 6\u201322 letters/digits (usually a 12-digit number). Leave empty if you don\u2019t have it.'; }
  };

  function validateField(name) {
    var input = form.elements[name];
    if (!input || !rules[name]) return true;
    var msg = rules[name](input.value || '');
    var wrap = input.closest('.field');
    if (wrap) wrap.classList.toggle('has-error', !!msg);
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    var err = el(name + '-err');
    if (err) err.textContent = msg;
    return !msg;
  }

  function computeTotals() {
    var t = VXCart.totals();
    var c = U.calc(t.items, Store.cache.settings, appliedCoupon);
    t.subtotal = c.subtotal; t.shipping = c.shipping; t.discount = c.discount; t.total = c.total; t.couponResult = c.coupon;
    return t;
  }
  function renderSummary() {
    var t = computeTotals();
    currentTotals = t;
    var empty = !t.items.length;
    el('co-empty').hidden = !empty;
    form.hidden = empty;
    if (empty) return;
    el('sum-list').innerHTML = t.items.map(function (i) {
      return '<li class="sum-item"><img src="' + esc(i.image) + '" alt="" width="56" height="70">' +
        '<span class="sum-name">' + esc(i.name) + ' <span class="sum-qty">&times; ' + i.quantity + '</span><small>' + money(i.price) + ' each</small></span>' +
        '<span class="sum-price">' + money(i.price * i.quantity) + '</span></li>';
    }).join('');
    var probs = VXCart.issues(t.items), pmap = {};
    probs.forEach(function (x) { pmap[x.id] = x; });
    if (probs.length) {
      el('sum-list').querySelectorAll('.sum-item').forEach(function (li, n) {
        var it = t.items[n]; if (it && pmap[it.id]) { li.classList.add('has-issue'); li.insertAdjacentHTML('beforeend', '<span class="sum-issue">' + esc(pmap[it.id].msg) + '</span>'); }
      });
    }
    // coupon: re-check whenever the cart changes
    var cmsg = el('coupon-msg');
    if (appliedCoupon) {
      if (t.couponResult && t.couponResult.ok) { cmsg.textContent = appliedCoupon.code + ': ' + t.couponResult.message + ' \u2014 you save ' + money(t.discount) + '.'; cmsg.className = 'coupon-msg is-ok'; }
      else { cmsg.textContent = appliedCoupon.code + ': ' + (t.couponResult ? t.couponResult.message : 'not valid'); cmsg.className = 'coupon-msg is-err'; }
      el('coupon-apply').textContent = 'Remove';
    } else {
      el('coupon-apply').textContent = 'Apply';
    }
    var s = Store.cache.settings;
    el('sum-totals').innerHTML =
      '<div><dt>Subtotal</dt><dd>' + money(t.subtotal) + '</dd></div>' +
      (t.discount ? '<div class="totals-discount"><dt>Discount' + (appliedCoupon ? ' (' + esc(appliedCoupon.code) + ')' : '') + '</dt><dd>&minus;' + money(t.discount) + '</dd></div>' : '') +
      '<div><dt>Shipping</dt><dd>' + shipText(t.shipping) + '</dd></div>' +
      '<div class="totals-grand"><dt>Total Amount</dt><dd>' + money(t.total) + '</dd></div>';
    var eta = [];
    if (s.estimatedDelivery) eta.push('Estimated delivery: ' + s.estimatedDelivery);
    if (s.freeShippingAbove > 0 && t.shipping > 0) eta.push('Free delivery on orders above ' + money(s.freeShippingAbove));
    el('sum-eta').textContent = eta.join(' \u00B7 ');
    el('sum-eta').hidden = !eta.length;
    renderPayment();
  }

  var lastQrUri = null;
  function renderPayment() {
    var m = method();
    el('panel-upi').hidden = m !== 'UPI';
    el('panel-cod').hidden = m !== 'COD';
    var t = currentTotals || computeTotals();
    var ready = upiReady();
    var pi = el('pay-instructions');
    if (pi) { pi.textContent = CFG.paymentInstructions || ''; pi.hidden = !CFG.paymentInstructions; }
    var btn = el('place-order');
    el('upi-amount').textContent = '\u20B9' + new Intl.NumberFormat('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(t.total);
    el('upi-ref').textContent = orderId;
    el('upi-notice').hidden = ready;
    el('upi-box').classList.toggle('is-disabled', !ready);
    var pay = el('upi-pay');
    var qr = el('upi-qr');
    if (ready) {
      var uri = upiUri(t.total, orderId);
      el('upi-id').textContent = CFG.upiId;
      pay.href = uri;
      pay.removeAttribute('aria-disabled');
      pay.removeAttribute('tabindex');
      qr.setAttribute('data-uri', uri);
      if (uri !== lastQrUri && typeof qrcode === 'function') {
        var q = qrcode(0, 'M');
        q.addData(uri);
        q.make();
        qr.innerHTML = q.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
        lastQrUri = uri;
      }
    } else {
      el('upi-id').textContent = 'Not set yet';
      pay.removeAttribute('href');
      pay.setAttribute('aria-disabled', 'true');
      pay.setAttribute('tabindex', '-1');
      qr.removeAttribute('data-uri');
      qr.innerHTML = '<span class="upi-qr-empty">QR code appears here once the store adds its UPI ID</span>';
      lastQrUri = null;
    }
    el('upi-copy').hidden = !ready;
    btn.textContent = m === 'UPI' ? 'Submit order' : 'Place order';
    var blocked = m === 'UPI' && !ready;
    btn.disabled = blocked;
    btn.setAttribute('aria-disabled', blocked ? 'true' : 'false');
  }

  /* =======================================================
     SAVED ADDRESSES (Meesho-style) — localStorage "vx_addresses"
     ======================================================= */
  var ADDR_KEY = 'vx_addresses';
  var addrMode = 'form';      // 'saved' = choosing a saved card, 'form' = typing a new/edited address
  var editingId = null;       // id of the saved address being edited
  var selectedId = null;      // saved address chosen with "Deliver here"
  var ADDR_FIELDS = ['fullName', 'mobile', 'house', 'street', 'landmark', 'pin', 'city', 'state'];
  var FORM_RULES = ['fullName', 'mobile', 'house', 'street', 'pin', 'city', 'state'];

  function readAddresses() {
    try { var a = JSON.parse(localStorage.getItem(ADDR_KEY) || '[]'); return Array.isArray(a) ? a : []; } catch (e) { return []; }
  }
  function writeAddresses(list) { try { localStorage.setItem(ADDR_KEY, JSON.stringify(list.slice(0, 10))); } catch (e) {} }
  function addrLine(a) {
    return [a.house, a.street, a.landmark ? 'Near ' + a.landmark.replace(/^near\s+/i, '') : '', a.city, a.state].filter(Boolean).join(', ') + ' - ' + a.pin;
  }

  function renderSaved() {
    var list = readAddresses().sort(function (x, y) { return (y.lastUsed || 0) - (x.lastUsed || 0); });
    var has = list.length > 0;
    el('addr-saved').hidden = !has || addrMode !== 'saved';
    el('addr-form').hidden = has && addrMode === 'saved';
    el('addr-form-head').hidden = !has;
    if (!has) return;
    if (!selectedId || !list.some(function (a) { return a.id === selectedId; })) selectedId = list[0].id;
    el('addr-list').innerHTML = list.map(function (a) {
      var on = a.id === selectedId;
      return '<div class="addr-card' + (on ? ' is-selected' : '') + '">' +
        '<label class="addr-pick"><input type="radio" name="savedAddr" value="' + esc(a.id) + '"' + (on ? ' checked' : '') + '>' +
        '<span class="addr-body"><span class="addr-name">' + esc(a.name) + ' <span class="addr-tag">' + esc(a.type || 'Home') + '</span></span>' +
        '<span class="addr-text">' + esc(addrLine(a)) + '</span>' +
        '<span class="addr-phone">' + esc(fmtMobile(a.mobile)) + '</span>' +
        '<span class="addr-deliver">' + (on ? 'Delivering here' : 'Deliver here') + '</span></span></label>' +
        '<button type="button" class="addr-edit" data-edit="' + esc(a.id) + '" aria-label="Edit address of ' + esc(a.name) + '">Edit</button>' +
      '</div>';
    }).join('');
  }

  function clearForm() {
    ADDR_FIELDS.forEach(function (n) {
      var i = form.elements[n]; if (!i) return;
      i.value = ''; i.removeAttribute('aria-invalid');
      var w = i.closest('.field'); if (w) w.classList.remove('has-error');
      var e = el(n + '-err'); if (e) e.textContent = '';
    });
    form.querySelector('input[name="addrType"][value="Home"]').checked = true;
    el('pin-status').textContent = ''; el('pin-suggest').hidden = true; lastPinLooked = '';
  }
  function showForm(addr) {
    addrMode = 'form';
    clearForm();
    editingId = addr ? addr.id : null;
    el('addr-form-title').textContent = addr ? 'Edit address' : 'Add new address';
    if (addr) {
      form.elements.fullName.value = addr.name; form.elements.mobile.value = addr.mobile;
      form.elements.house.value = addr.house; form.elements.street.value = addr.street;
      form.elements.landmark.value = addr.landmark || ''; form.elements.pin.value = addr.pin;
      form.elements.city.value = addr.city; form.elements.state.value = addr.state;
      var t = form.querySelector('input[name="addrType"][value="' + (addr.type === 'Work' ? 'Work' : 'Home') + '"]'); if (t) t.checked = true;
      lastPinLooked = addr.pin;
    }
    renderSaved();
    form.elements.fullName.focus();
  }
  function showSaved() { addrMode = 'saved'; editingId = null; renderSaved(); }

  function initAddresses() {
    if (readAddresses().length) addrMode = 'saved';
    renderSaved();
    el('addr-add').addEventListener('click', function () { showForm(null); });
    el('addr-cancel').addEventListener('click', function () { showSaved(); var r = el('addr-list').querySelector('input:checked'); if (r) r.focus(); });
    el('addr-list').addEventListener('change', function (e) {
      if (e.target.name === 'savedAddr') { selectedId = e.target.value; renderSaved(); var r = el('addr-list').querySelector('input:checked'); if (r) r.focus(); }
    });
    el('addr-list').addEventListener('click', function (e) {
      var b = e.target.closest('[data-edit]');
      if (b) { var a = readAddresses().filter(function (x) { return x.id === b.getAttribute('data-edit'); })[0]; if (a) showForm(a); }
    });
  }

  function addressFromForm() {
    var f = form.elements;
    var typeEl = form.querySelector('input[name="addrType"]:checked');
    return {
      id: editingId || ('a' + Date.now().toString(36)),
      name: f.fullName.value.trim(), mobile: normMobile(f.mobile.value),
      house: f.house.value.trim(), street: f.street.value.trim(), landmark: f.landmark.value.trim(),
      pin: f.pin.value.trim(), city: f.city.value.trim(), state: f.state.value,
      type: typeEl ? typeEl.value : 'Home'
    };
  }
  function chosenAddress() {
    if (addrMode === 'saved') return readAddresses().filter(function (a) { return a.id === selectedId; })[0] || null;
    return addressFromForm();
  }
  function rememberAddress(a) {
    var list = readAddresses().filter(function (x) { return x.id !== a.id; });
    var copy = {}; Object.keys(a).forEach(function (k) { copy[k] = a[k]; });
    copy.lastUsed = Date.now();
    list.unshift(copy);
    writeAddresses(list);
  }

  /* =======================================================
     PIN CODE AUTOFILL — public India Post lookup (no key).
     If it is slow, offline or blocked, nothing happens and the
     customer simply types City and State.
     ======================================================= */
  var PIN_API = 'https://api.postalpincode.in/pincode/';
  var lastPinLooked = '';
  function normState(s) { return String(s || '').toLowerCase().replace(/&/g, 'and').replace(/[^a-z]/g, ''); }
  function matchState(name) {
    var want = normState(name), opts = form.elements.state.options;
    for (var i = 1; i < opts.length; i++) if (normState(opts[i].value || opts[i].text) === want) return opts[i].text;
    for (var j = 1; j < opts.length; j++) { var o = normState(opts[j].text); if (want && (o.indexOf(want) === 0 || want.indexOf(o) === 0)) return opts[j].text; }
    return '';
  }
  function lookupPin(pin) {
    if (!/^[1-9]\d{5}$/.test(pin) || pin === lastPinLooked || !window.fetch) return;
    lastPinLooked = pin;
    var status = el('pin-status');
    status.textContent = 'Finding your area\u2026';
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 7000);
    fetch(PIN_API + pin, ctrl ? { signal: ctrl.signal } : {}).then(function (r) { return r.json(); }).then(function (data) {
      clearTimeout(timer);
      if (form.elements.pin.value.trim() !== pin) return;
      var res = data && data[0];
      var offices = res && res.Status === 'Success' && Array.isArray(res.PostOffice) ? res.PostOffice : [];
      if (!offices.length) { status.textContent = ''; el('pin-suggest').hidden = true; return; }
      var first = offices[0];
      var city = first.District || first.Block || '';
      var state = matchState(first.State);
      if (city) { form.elements.city.value = city; validateField('city'); }
      if (state) { form.elements.state.value = state; validateField('state'); }
      status.textContent = '\u2713 ' + [city, state].filter(Boolean).join(', ');
      var names = [];
      offices.forEach(function (o) { if (o.Name && names.indexOf(o.Name) === -1) names.push(o.Name); });
      el('pin-chips').innerHTML = names.slice(0, 8).map(function (n) { return '<button type="button" class="pin-chip" data-area="' + esc(n) + '">' + esc(n) + '</button>'; }).join('');
      el('pin-suggest').hidden = names.length === 0;
    }).catch(function () {
      clearTimeout(timer);
      status.textContent = '';   // silent: customer types City / State
      el('pin-suggest').hidden = true;
      lastPinLooked = '';
    });
  }

  // Order structure (same in Firebase "orders/{orderId}" and demo mode)
  function buildOrder() {
    var f = form.elements;
    var t = computeTotals();
    var a = chosenAddress();
    var address = { name: a.name, house: a.house, street: a.street, landmark: a.landmark || '', city: a.city, state: a.state, pin: a.pin, type: a.type || 'Home' };
    address.full = addrLine(a);
    var pm = method();
    var order = {
      orderId: orderId,
      customerName: a.name,
      phone: a.mobile,
      email: f.email.value.trim(),
      address: address,
      products: t.items.map(function (i) {
        // big uploaded photos (data: URLs) are not copied into the order — the admin shows the product photo instead
        return { id: i.id, name: i.name, qty: i.quantity, price: i.price, image: /^data:/.test(i.image || '') ? '' : (i.image || '') };
      }),
      subtotal: t.subtotal,
      shipping: t.shipping,
      discount: t.discount,
      total: t.total,
      currency: CFG.currency || 'INR',
      paymentMethod: pm,                              // "UPI" or "COD"
      paymentStatus: pm === 'COD' ? 'COD' : 'PENDING', // NEVER "PAID" here — only the admin marks paid, after checking
      orderStatus: 'NEW',
      source: 'website'
    };
    if (t.discount > 0 && appliedCoupon) order.couponCode = appliedCoupon.code;
    if (pm === 'UPI') {
      order.upiId = CFG.upiId;
      order.upiTransactionRef = f.upiRef.value.trim();
    }
    return { order: order, addr: a };
  }

  function applyCoupon() {
    var input = form.elements.couponCode, msg = el('coupon-msg'), btn = el('coupon-apply');
    if (appliedCoupon) { appliedCoupon = null; input.value = ''; input.disabled = false; msg.textContent = ''; msg.className = 'coupon-msg'; renderSummary(); return; }
    var code = input.value.trim().toUpperCase();
    if (!code) { msg.textContent = 'Please type a coupon code.'; msg.className = 'coupon-msg is-err'; input.focus(); return; }
    btn.disabled = true; msg.textContent = 'Checking\u2026'; msg.className = 'coupon-msg';
    Store.getCoupon(code).then(function (c) {
      btn.disabled = false;
      var r = U.evalCoupon(c, VXCart.totals().subtotal);
      if (!r.ok) { msg.textContent = r.message; msg.className = 'coupon-msg is-err'; return; }
      appliedCoupon = c; input.value = c.code; input.disabled = true;
      renderSummary();
    }, function () { btn.disabled = false; msg.textContent = 'Could not check the coupon. Please try again.'; msg.className = 'coupon-msg is-err'; });
  }

  function initCheckout() {
    orderId = pendingOrderId();
    initAddresses();
    try { if (!form.elements.email.value) form.elements.email.value = localStorage.getItem('vx_email') || ''; } catch (e) {}
    renderSummary();

    Object.keys(rules).forEach(function (name) {
      var input = form.elements[name];
      if (!input) return;
      input.addEventListener('blur', function () { if (input.value || input.getAttribute('aria-invalid') === 'true') validateField(name); });
      input.addEventListener('input', function () {
        if (input.getAttribute('aria-invalid') === 'true') validateField(name);
        if (!form.querySelector('[aria-invalid="true"]')) el('form-error').hidden = true;
      });
      input.addEventListener('change', function () {
        if (input.tagName === 'SELECT') validateField(name);
        if (!form.querySelector('[aria-invalid="true"]')) el('form-error').hidden = true;
      });
    });
    // digits only in mobile & PIN
    form.elements.pin.addEventListener('input', function () {
      this.value = this.value.replace(/\D/g, '').slice(0, 6);
      if (this.value.length === 6) lookupPin(this.value); else { el('pin-status').textContent = ''; el('pin-suggest').hidden = true; }
    });
    el('pin-chips').addEventListener('click', function (e) {
      var b = e.target.closest('[data-area]'); if (!b) return;
      var area = b.getAttribute('data-area'), s = form.elements.street;
      if (s.value.toLowerCase().indexOf(area.toLowerCase()) === -1) s.value = s.value.trim() ? s.value.trim().replace(/,\s*$/, '') + ', ' + area : area;
      validateField('street');
      el('pin-chips').querySelectorAll('.pin-chip').forEach(function (x) { x.classList.toggle('is-active', x === b); });
    });
    form.elements.mobile.addEventListener('input', function () { this.value = this.value.replace(/[^\d+\s]/g, ''); });

    form.querySelectorAll('input[name="paymentMethod"]').forEach(function (r) {
      r.addEventListener('change', function () { el('form-error').hidden = true; renderPayment(); });
    });
    document.querySelectorAll('[data-choose-cod]').forEach(function (b) {
      b.addEventListener('click', function () { form.querySelector('input[value="COD"]').checked = true; renderPayment(); form.querySelector('input[value="COD"]').focus(); });
    });
    el('upi-pay').addEventListener('click', function (e) { if (!upiReady()) e.preventDefault(); });
    el('upi-copy').addEventListener('click', function () {
      var b = this;
      var done = function () { b.textContent = 'Copied'; setTimeout(function () { b.textContent = 'Copy'; }, 1500); };
      if (navigator.clipboard) navigator.clipboard.writeText(CFG.upiId).then(done, function () {}); 
    });

    // totals/QR follow every cart change (also from the cart drawer on this page)
    document.addEventListener('vx:cartchange', renderSummary);
    // …and every change the admin makes in Settings (UPI ID, shipping, merchant name)
    document.addEventListener('vx:settings', function () { refreshCfg(); renderSummary(); });
    el('coupon-apply').addEventListener('click', applyCoupon);
    form.elements.couponCode.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); applyCoupon(); } });
    form.elements.couponCode.addEventListener('input', function () { this.value = this.value.toUpperCase().replace(/\s/g, ''); });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      var formErr = el('form-error');
      formErr.hidden = true;
      var firstBad = null;
      var names = (addrMode === 'form' ? FORM_RULES : []).concat(['email', 'upiRef']);
      names.forEach(function (name) {
        if (!validateField(name) && !firstBad) firstBad = form.elements[name];
      });
      if (addrMode === 'saved' && !chosenAddress()) { showForm(null); return; }
      if (!VXCart.read().length) { renderSummary(); return; }
      if (VXCart.issues().length) {
        formErr.textContent = 'Some items in your cart are out of stock or more than available. Please fix them in the order summary.';
        formErr.hidden = false;
        el('co-summary-title').scrollIntoView({ behavior: 'smooth', block: 'start' });
        return;
      }
      if (appliedCoupon && !(currentTotals.couponResult && currentTotals.couponResult.ok)) {
        formErr.textContent = 'The coupon ' + appliedCoupon.code + ' can\u2019t be used on this order. Remove it to continue.';
        formErr.hidden = false;
        return;
      }
      if (firstBad) {
        formErr.textContent = 'Please fix the highlighted fields above.';
        formErr.hidden = false;
        firstBad.focus();
        return;
      }
      if (method() === 'UPI' && !upiReady()) {
        formErr.textContent = 'UPI payment is not set up yet. Please choose Cash on Delivery.';
        formErr.hidden = false;
        return;
      }
      var btn = el('place-order');
      btn.disabled = true;
      var btnText = btn.textContent;
      btn.textContent = 'Placing order\u2026';
      var built = buildOrder();
      var order = built.order;
      submitOrder(order).then(function (saved) {
        rememberAddress(built.addr);   // saved for next time ("vx_addresses")
        try { if (order.customer.email) localStorage.setItem('vx_email', order.customer.email); } catch (err) {}
        VXCart.clear();
        try { sessionStorage.removeItem(PENDING_ID_KEY); } catch (err) {}
        appliedCoupon = null;
        history.replaceState(null, '', 'checkout.html?order=' + encodeURIComponent(saved.orderId) + '&placed=1');
        showConfirmation(saved);
      }).catch(function (err) {
        btn.disabled = false;
        btn.textContent = btnText;
        if (err && err.code === 'duplicate-id') { orderId = newOrderId(); try { sessionStorage.setItem(PENDING_ID_KEY, orderId); } catch (e2) {} }
        if (err && err.code === 'coupon') { appliedCoupon = null; form.elements.couponCode.disabled = false; }
        formErr.textContent = (err && err.message && err.code !== 'duplicate-id') ? err.message : 'Sorry, the order could not be saved. Please try again.';
        formErr.hidden = false;
        renderSummary();
      });
    });
  }

  /* =======================================================
     INVOICE TEXT (for WhatsApp)
     ======================================================= */
  function invoiceText(o) {
    o = norm(o);
    var lines = [
      '*' + (CFG.brandName || 'VEXACOLLECTION') + ' \u2014 ORDER INVOICE*',
      'Order ID: ' + o.orderId,
      'Date: ' + fmtDate(o.createdAt),
      '',
      'Customer: ' + o.customer.name,
      'Mobile: ' + fmtMobile(o.customer.mobile),
      'Email: ' + (o.customer.email || '-'),
      'Delivery address: ' + o.address.full,
      '',
      'Items:'
    ];
    var itemLines = o.items.map(function (i, n) { return (n + 1) + '. ' + i.name + ' \u00D7 ' + i.qty + ' \u2014 ' + money(i.price * i.qty); });
    var tail = [
      '',
      'Subtotal: ' + money(o.subtotal)
    ].concat(o.discount ? ['Discount' + (o.couponCode ? ' (' + o.couponCode + ')' : '') + ': -' + money(o.discount)] : []).concat([
      'Shipping: ' + shipText(o.shipping),
      '*Total: ' + money(o.total) + '*',
      '',
      'Payment method: ' + methodText(o),
      'Payment status: ' + paymentText(o)
    ]);
    if (o.paymentMethod === 'UPI' && o.upiTransactionRef) tail.push('UPI Txn ID / UTR: ' + o.upiTransactionRef);
    tail.push('Order status: ' + statusText(o));
    // keep the message under ~1500 characters
    var shown = itemLines.slice();
    function build(extra) { return lines.concat(shown, extra ? [extra] : [], tail).join('\n'); }
    var text = build();
    while (text.length > 1500 && shown.length > 1) {
      shown.pop();
      text = build('+ ' + (itemLines.length - shown.length) + ' more item(s)');
    }
    return text.slice(0, 1500);
  }
  function invoiceWaUrl(o) { return 'https://wa.me/' + WA_NUMBER + '?text=' + encodeURIComponent(invoiceText(o)); }
  function supportWaUrl(o) { return 'https://wa.me/' + WA_NUMBER + (o ? '?text=' + encodeURIComponent('Hi ' + (CFG.brandName || 'VEXACOLLECTION') + ', I need help with my order ' + o.orderId + '.') : ''); }

  /* =======================================================
     CONFIRMATION + ORDER DETAILS / INVOICE VIEWS
     ======================================================= */
  var WA_ICON = '<svg viewBox="0 0 32 32" aria-hidden="true" focusable="false"><path fill="currentColor" d="M16.04 3C9.4 3 4 8.33 4 14.9c0 2.3.66 4.46 1.82 6.3L4 29l8.03-2.1a12.2 12.2 0 0 0 4 .67C22.68 27.57 28 22.24 28 15.67 28 9.1 22.68 3 16.04 3Zm0 22.4c-1.27 0-2.5-.24-3.66-.7l-.6-.24-4.77 1.25 1.27-4.6-.35-.6a10.1 10.1 0 0 1-1.62-5.6c0-5.47 4.4-9.7 9.73-9.7 5.33 0 9.75 4.8 9.75 10.36 0 5.46-4.42 9.83-9.75 9.83Zm5.35-7.27c-.29-.15-1.73-.85-2-.94-.27-.1-.47-.15-.66.15-.2.29-.76.94-.93 1.13-.17.2-.34.22-.63.07-.3-.15-1.24-.45-2.36-1.45-.87-.77-1.46-1.73-1.63-2.02-.17-.3-.02-.45.13-.6.13-.13.3-.34.44-.51.15-.17.2-.3.3-.49.1-.2.05-.37-.03-.51-.07-.15-.66-1.58-.9-2.17-.24-.57-.48-.49-.66-.5h-.56c-.2 0-.51.07-.78.37-.27.29-1.02 1-1.02 2.42 0 1.43 1.05 2.82 1.2 3.01.14.2 2.06 3.14 5 4.4.7.3 1.24.48 1.67.62.7.22 1.34.19 1.84.12.56-.08 1.73-.7 1.97-1.39.25-.68.25-1.27.17-1.39-.07-.12-.27-.2-.56-.34Z"/></svg>';

  function showView(which) {
    viewCheckout.hidden = which !== 'checkout';
    viewResult.hidden = which === 'checkout';
    window.scrollTo(0, 0);
  }

  function showConfirmation(o) {
    o = norm(o);
    var upi = o.paymentMethod === 'UPI';
    viewResult.innerHTML =
      '<section class="confirm" aria-labelledby="confirm-title">' +
        '<span class="confirm-check" aria-hidden="true"><svg viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" d="m5 12.5 4.5 4.5L19 7.5"/></svg></span>' +
        '<h1 class="co-title" id="confirm-title" tabindex="-1">Order placed</h1>' +
        '<p class="confirm-thanks">Thank you for shopping with ' + esc(CFG.brandName) + '.</p>' +
        '<dl class="confirm-dl">' +
          '<div><dt>Order ID</dt><dd class="confirm-id">' + esc(o.orderId) + '</dd></div>' +
          '<div><dt>Order Status</dt><dd><span class="status ' + statusClass(o) + '" data-live-status>' + esc(statusText(o)) + '</span></dd></div>' +
          '<div><dt>Payment</dt><dd>' + esc(methodText(o)) + '</dd></div>' +
          '<div><dt>Delivery Address</dt><dd>' + esc(o.customer.name) + '<br>' + esc(o.address.full) + '<br>' + esc(fmtMobile(o.customer.mobile)) + '</dd></div>' +
          '<div class="confirm-total"><dt>Total</dt><dd>' + money(o.total) + '</dd></div>' +
        '</dl>' +
        (upi ? '<p class="confirm-note">We haven&rsquo;t verified your UPI payment yet. The store will check it and confirm your order.</p>' : '<p class="confirm-note">Please keep ' + money(o.total) + ' ready to pay when your order is delivered.</p>') +
        (Store.mode === 'firebase'
          ? '<div class="confirm-send"><p>Your order has reached the store. Want a copy on WhatsApp too? WhatsApp opens with the invoice written &mdash; just tap Send.</p>'
          : '<div class="confirm-send"><p><strong>Important:</strong> send your invoice to the store on WhatsApp so we receive your order. WhatsApp opens with the invoice written &mdash; just tap Send.</p>') +
        '<a class="btn btn-whatsapp btn-block" href="' + esc(invoiceWaUrl(o)) + '" target="_blank" rel="noopener" data-invoice-wa>' + WA_ICON + '<span>Send order invoice on WhatsApp</span></a></div>' +
        '<div class="confirm-actions">' +
          '<a class="btn btn-cart" href="checkout.html?order=' + encodeURIComponent(o.orderId) + '" data-view-order>View order</a>' +
          '<a class="btn btn-ghost" href="checkout.html?order=' + encodeURIComponent(o.orderId) + '&print=1" data-print-invoice>Download / print invoice</a>' +
          '<a class="btn btn-ghost" href="index.html#shop">Continue shopping</a>' +
        '</div>' +
        '<a class="confirm-support" href="' + esc(supportWaUrl(o)) + '" target="_blank" rel="noopener">' + WA_ICON + '<span>Contact support on WhatsApp</span></a>' +
      '</section>';
    showView('result');
    var h = el('confirm-title'); if (h) h.focus({ preventScroll: true });
    followStatus(o);
  }

  // Live order status from the store (admin changes appear without refresh)
  var stopTracking = null;
  function followStatus(o) {
    if (stopTracking) stopTracking();
    stopTracking = Store.watchTracking(o.orderId, function (t) {
      if (!t) return;
      var x = Object.assign({}, o, { orderStatus: t.orderStatus || o.orderStatus, paymentStatus: t.paymentStatus || o.paymentStatus });
      document.querySelectorAll('[data-live-status]').forEach(function (n) { n.textContent = statusText(x); n.className = 'status ' + statusClass(x); });
      document.querySelectorAll('[data-live-payment]').forEach(function (n) { n.textContent = paymentText(x); });
    });
  }

  function showOrder(o, autoPrint) {
    if (!o) {
      viewResult.innerHTML = '<section class="confirm"><h1 class="co-title">Order not found</h1>' +
        '<p class="confirm-thanks">This order isn&rsquo;t saved on this device. Orders are stored only in the browser they were placed from.</p>' +
        '<div class="confirm-actions"><a class="btn btn-cart" href="index.html#shop">Continue shopping</a>' +
        '<a class="btn btn-ghost" href="' + esc(supportWaUrl(null)) + '" target="_blank" rel="noopener">Contact support on WhatsApp</a></div></section>';
      showView('result');
      return;
    }
    o = norm(o);
    var upi = o.paymentMethod === 'UPI';
    var rows = o.items.map(function (i) {
      return '<tr><td class="inv-item">' + (i.image ? '<img src="' + esc(i.image) + '" alt="" width="44" height="55">' : '') + '<span>' + esc(i.name) + '<small class="inv-each">' + money(i.price) + ' each</small></span></td>' +
        '<td class="num">' + i.qty + '</td><td class="num col-price">' + money(i.price) + '</td><td class="num">' + money(i.price * i.qty) + '</td></tr>';
    }).join('');
    viewResult.innerHTML =
      '<div class="inv-toolbar no-print">' +
        '<a class="co-link" href="index.html#shop">&larr; Continue shopping</a>' +
      '</div>' +
      '<article class="invoice" aria-labelledby="inv-title">' +
        '<header class="inv-head">' +
          '<div><img class="inv-logo" src="images/logo.svg" alt="' + esc(CFG.brandName) + '" width="368" height="34">' +
          '<p class="inv-store">' + esc(CFG.address) + '<br>Phone: ' + esc(fmtMobile(String(CFG.phone).replace(/^\+91/, ''))) + '</p></div>' +
          '<div class="inv-meta"><h1 id="inv-title">Order invoice</h1>' +
          '<p><span>Order ID</span> <strong>' + esc(o.orderId) + '</strong></p>' +
          '<p><span>Date</span> ' + esc(fmtDate(o.createdAt)) + '</p></div>' +
        '</header>' +
        '<div class="inv-status-row">' +
          '<p><span>Order status</span> <span class="status ' + statusClass(o) + '" data-live-status>' + esc(statusText(o)) + '</span></p>' +
          '<p><span>Payment method</span> ' + esc(methodText(o)) + '</p>' +
          '<p><span>Payment status</span> <span data-live-payment>' + esc(paymentText(o)) + '</span></p>' +
          (upi && o.upiTransactionRef ? '<p><span>UPI Txn ID / UTR</span> ' + esc(o.upiTransactionRef) + '</p>' : '') +
        '</div>' +
        '<div class="inv-parties">' +
          '<div><h2>Customer</h2><p>' + esc(o.customer.name) + '<br>' + esc(fmtMobile(o.customer.mobile)) + (o.customer.email ? '<br>' + esc(o.customer.email) : '') + '</p></div>' +
          '<div><h2>Delivery address' + (o.address.type ? ' <span class="addr-tag">' + esc(o.address.type) + '</span>' : '') + '</h2><p>' + esc(o.address.house) + '<br>' + esc(o.address.street) + (o.address.landmark ? '<br>Near ' + esc(o.address.landmark.replace(/^near\s+/i, '')) : '') + '<br>' + esc(o.address.city) + ', ' + esc(o.address.state) + ' &ndash; ' + esc(o.address.pin) + '</p></div>' +
        '</div>' +
        '<div class="inv-table-wrap"><table class="inv-table"><thead><tr><th>Item</th><th class="num">Qty</th><th class="num col-price">Price</th><th class="num">Amount</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
        '<dl class="totals inv-totals">' +
          '<div><dt>Subtotal</dt><dd>' + money(o.subtotal) + '</dd></div>' +
          (o.discount ? '<div class="totals-discount"><dt>Discount' + (o.couponCode ? ' (' + esc(o.couponCode) + ')' : '') + '</dt><dd>&minus;' + money(o.discount) + '</dd></div>' : '') +
          '<div><dt>Shipping</dt><dd>' + shipText(o.shipping) + '</dd></div>' +
          '<div class="totals-grand"><dt>Total</dt><dd>' + money(o.total) + '</dd></div>' +
        '</dl>' +
        '<p class="inv-foot">' + (upi ? 'UPI payment is verified manually by the store. This invoice is not a payment receipt.' : 'Amount payable in cash on delivery.') + ' Thank you for shopping with ' + esc(CFG.brandName) + '.</p>' +
      '</article>' +
      '<div class="confirm-actions inv-actions no-print">' +
        '<button type="button" class="btn btn-cart" data-print>Download / print invoice</button>' +
        '<a class="btn btn-whatsapp" href="' + esc(invoiceWaUrl(o)) + '" target="_blank" rel="noopener" data-invoice-wa>' + WA_ICON + '<span>Send invoice on WhatsApp</span></a>' +
        '<a class="btn btn-ghost" href="index.html#shop">Continue shopping</a>' +
        '<a class="btn btn-ghost" href="' + esc(supportWaUrl(o)) + '" target="_blank" rel="noopener">Contact support on WhatsApp</a>' +
      '</div>';
    showView('result');
    followStatus(o);
    if (autoPrint) setTimeout(function () { window.print(); }, 400);
  }

  viewResult.addEventListener('click', function (e) {
    var v = e.target.closest('[data-view-order]');
    var p = e.target.closest('[data-print-invoice]');
    var pr = e.target.closest('[data-print]');
    var id = new URLSearchParams(location.search).get('order');
    if (v || p) {
      e.preventDefault();
      history.pushState(null, '', 'checkout.html?order=' + encodeURIComponent(id));
      showOrder(findOrder(id), !!p);
    } else if (pr) {
      window.print();
    }
  });
  window.addEventListener('popstate', route);

  function route() {
    var params = new URLSearchParams(location.search);
    var id = params.get('order');
    if (id) {
      var o = findOrder(id);
      if (params.get('placed') === '1' && o) showConfirmation(o); else showOrder(o, params.get('print') === '1');
    } else {
      showView('checkout');
      renderSummary();
    }
  }

  // For the store owner / testing in the browser console: VXOrders.list()
  window.VXOrders = { list: readOrders, find: findOrder, invoiceText: function (id) { var o = findOrder(id); return o ? invoiceText(o) : null; }, upiUri: upiUri };

  initCheckout();
  route();
})();
