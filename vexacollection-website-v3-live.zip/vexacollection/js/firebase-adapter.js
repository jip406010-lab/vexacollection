/* =========================================================
   VEXACOLLECTION — FirebaseAdapter (Firestore + Firebase Auth)
   ---------------------------------------------------------
   Loaded automatically by js/store-api.js when js/firebase-config.js
   holds a real Firebase web config. Uses the official Firebase JS SDK
   (modular, v10) from Google's CDN (gstatic.com).

   Collections (see firestore.rules for who may read/write what):
     products/{productId}      public read (not HIDDEN); admin write; customers may
                               only lower "stock" as part of placing an order
     orders/{orderId}          customers may CREATE (validated); admin read/update
     orderTracking/{orderId}   status only, no personal data — public read
     payments/{orderId}        created with the order; admin read/update
     customers/{phone}         admin only (filled by the admin panel)
     coupons/{CODE}            public "get" by exact code (to apply it); admin list/write
     settings/store            public read; admin write
     admins/{uid}              which Firebase Auth users are admins (set by you
                               in the Firebase console — never from the website)

   No secret keys here: the web config is a public identifier.
   ========================================================= */
const V = '10.14.1';
const BASE = `https://www.gstatic.com/firebasejs/${V}/`;

import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-app.js';
import {
  getFirestore, connectFirestoreEmulator, collection, doc, onSnapshot, query, where, orderBy, limit, getDoc, getDocs,
  setDoc, updateDoc, deleteDoc, runTransaction, writeBatch, serverTimestamp, Timestamp
} from 'https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js';

// Firestore Timestamps -> ISO strings so the UI code is identical in both modes
function plain(v) {
  if (v && typeof v.toDate === 'function') return v.toDate().toISOString();
  if (Array.isArray(v)) return v.map(plain);
  if (v && typeof v === 'object') { const o = {}; for (const k of Object.keys(v)) o[k] = plain(v[k]); return o; }
  return v;
}
function err(code, message, extra) { const e = new Error(message); e.code = code; e.vx = true; Object.assign(e, extra || {}); return e; }
function stripUndefined(o) { const out = {}; for (const k of Object.keys(o)) if (o[k] !== undefined) out[k] = o[k]; return out; }

export function createFirebaseAdapter(config, opts) {
  const H = opts.helpers;
  const { databaseId, ...appConfig } = config || {};
  const app = initializeApp(appConfig);
  // Aashish's Firestore database was created with the ID "default" (not "(default)").
  const db = databaseId ? getFirestore(app, databaseId) : getFirestore(app);
  // Developer testing only: window.VX_FIREBASE_EMULATOR = { host, firestorePort, authPort }
  const EMU = window.VX_FIREBASE_EMULATOR || null;
  if (EMU) connectFirestoreEmulator(db, EMU.host, EMU.firestorePort);
  let authMod = null, auth = null, currentUser = null;

  async function loadAuth() {
    if (authMod) return authMod;
    const m = await import(BASE + 'firebase-auth.js');
    auth = m.getAuth(app);
    if (EMU && EMU.authPort) m.connectAuthEmulator(auth, 'http://' + EMU.host + ':' + EMU.authPort, { disableWarnings: true });
    authMod = m;
    return authMod;
  }
  async function isAdmin(uid) {
    try { return (await getDoc(doc(db, 'admins', uid))).exists(); } catch (e) { return false; }
  }

  const A = {
    mode: 'firebase',
    init: async () => {},

    /* ---------------- public (customer website) ---------------- */
    watchProducts(cb, o) {
      const q = (o && o.all)
        ? collection(db, 'products')
        : query(collection(db, 'products'), where('visible', '==', true));   // matches firestore.rules
      return onSnapshot(q, snap => {
        const list = snap.docs.map(d => Object.assign(plain(d.data()), { id: d.id }));
        list.sort((a, b) => (H.num(a.sort, 999) - H.num(b.sort, 999)) || String(a.name).localeCompare(String(b.name)));
        cb(list);
      }, e => { console.error('[products]', e); cb([]); });
    },
    watchSettings(cb) {
      return onSnapshot(doc(db, 'settings', 'store'), s => cb(H.normSettings(s.exists() ? s.data() : {})),
        e => { console.error('[settings]', e); cb(H.normSettings({})); });
    },
    async getCoupon(code) {
      code = String(code || '').trim().toUpperCase();
      if (!/^[A-Z0-9_-]{2,30}$/.test(code)) return null;
      try { const s = await getDoc(doc(db, 'coupons', code)); return s.exists() ? Object.assign(plain(s.data()), { code }) : null; }
      catch (e) { return null; }
    },

    // Creates the order + lowers stock in ONE transaction (all or nothing).
    async placeOrder(order, _retry) {
      const qty = {};
      order.products.forEach(it => { qty[it.id] = (qty[it.id] || 0) + it.qty; });
      try {
        await runTransaction(db, async tx => {
          const refs = Object.keys(qty).map(id => doc(db, 'products', id));
          const snaps = [];
          for (const r of refs) {
            let s;
            try { s = await tx.get(r); } catch (e) { s = null; }
            snaps.push(s);
          }
          let couponRef = null, couponSnap = null;
          if (order.couponCode) { couponRef = doc(db, 'coupons', order.couponCode); couponSnap = await tx.get(couponRef); }
          snaps.forEach((s, i) => {
            const id = refs[i].id, it = order.products.find(p => p.id === id);
            if (!s || !s.exists()) throw err('unavailable', `\u201C${it.name}\u201D is no longer available. Please remove it from your cart.`, { productId: id });
            const p = s.data();
            if (H.availability(p) !== 'in') throw err('out-of-stock', `\u201C${it.name}\u201D is out of stock. Please remove it from your cart.`, { productId: id, stock: 0 });
            if (H.num(p.stock) < qty[id]) throw err('out-of-stock', `Only ${p.stock} left of \u201C${it.name}\u201D. Please reduce the quantity.`, { productId: id, stock: H.num(p.stock) });
          });
          if (couponRef) {
            const c = couponSnap.exists() ? Object.assign(couponSnap.data(), { code: order.couponCode }) : null;
            const r = H.evalCoupon(c, order.subtotal);
            if (!r.ok) throw err('coupon', r.message);
          }
          const orderRef = doc(db, 'orders', order.orderId);
          tx.set(orderRef, stripUndefined(Object.assign({}, order, {
            createdAt: serverTimestamp(),
            stockDeducted: true, stockRestored: false,
            statusHistory: [{ status: 'NEW', at: Timestamp.now() }]
          })));
          snaps.forEach((s, i) => tx.update(refs[i], { stock: H.num(s.data().stock) - qty[refs[i].id], lastOrderId: order.orderId }));
          if (couponRef) tx.update(couponRef, { usedCount: H.num(couponSnap.data().usedCount) + 1, lastOrderId: order.orderId });
          tx.set(doc(db, 'payments', order.orderId), { orderId: order.orderId, amount: order.total, method: order.paymentMethod, status: order.paymentStatus, createdAt: serverTimestamp() });
          tx.set(doc(db, 'orderTracking', order.orderId), { orderStatus: 'NEW', paymentStatus: order.paymentStatus, updatedAt: serverTimestamp() });
        });
      } catch (e) {
        if (e && e.vx) throw e;   // our own clear message (stock / coupon)
        // Most likely an order ID clash (an existing order cannot be overwritten): try once with a new ID.
        if (!_retry && e && e.code === 'permission-denied') {
          const n = Object.assign({}, order, { orderId: order.orderId.replace(/-[A-Z0-9]{4}$/, '-' + Math.random().toString(36).slice(2, 6).toUpperCase()) });
          return A.placeOrder(n, true);
        }
        console.error('[placeOrder]', e);
        throw err('failed', 'Sorry, we could not place your order right now. Please check your internet and try again.');
      }
      return Object.assign({}, order, { createdAt: new Date().toISOString(), statusHistory: [{ status: 'NEW', at: new Date().toISOString() }] });
    },
    watchTracking(orderId, cb) {
      return onSnapshot(doc(db, 'orderTracking', orderId), s => cb(s.exists() ? plain(s.data()) : null), () => cb(null));
    },

    /* ---------------- admin (needs a signed-in admin) ---------------- */
    watchOrders(cb) {
      let first = true;
      const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'), limit(1000));
      return onSnapshot(q, snap => {
        const list = snap.docs.map(d => Object.assign(plain(d.data({ serverTimestamps: 'estimate' })), { orderId: d.id }));
        const added = first ? [] : snap.docChanges().filter(c => c.type === 'added').map(c => Object.assign(plain(c.doc.data({ serverTimestamps: 'estimate' })), { orderId: c.doc.id }));
        first = false;
        cb(list, { added });
      }, e => { console.error('[orders]', e); cb([], { added: [], error: e }); });
    },
    async updateOrder(orderId, patch) {
      return runTransaction(db, async tx => {
        const ref = doc(db, 'orders', orderId);
        const s = await tx.get(ref);
        if (!s.exists()) throw err('not-found', 'Order not found');
        const o = s.data();
        const next = patch.orderStatus || o.orderStatus;
        const upd = { updatedAt: serverTimestamp() };
        let stockDelta = 0;   // +1 restore, -1 deduct again
        if (next === 'CANCELLED' && o.orderStatus !== 'CANCELLED' && o.stockDeducted && !o.stockRestored) { stockDelta = 1; upd.stockRestored = true; }
        else if (next !== 'CANCELLED' && o.orderStatus === 'CANCELLED' && o.stockRestored) { stockDelta = -1; upd.stockRestored = false; }
        const prodSnaps = [];
        if (stockDelta) for (const it of o.products) { const r = doc(db, 'products', it.id); prodSnaps.push([r, await tx.get(r), it.qty]); }
        const now = Timestamp.now();
        if (patch.orderStatus && patch.orderStatus !== o.orderStatus) {
          upd.orderStatus = patch.orderStatus;
          upd.statusHistory = (o.statusHistory || []).concat([{ status: patch.orderStatus, at: now }]);
        }
        if (patch.paymentStatus && patch.paymentStatus !== o.paymentStatus) {
          upd.paymentStatus = patch.paymentStatus;
          upd.paymentHistory = (o.paymentHistory || []).concat([{ status: patch.paymentStatus, at: now, by: (currentUser && currentUser.email) || 'admin' }]);
          if (patch.paymentStatus === 'PAID') { upd.paidAt = now; upd.paymentVerifiedBy = ((currentUser && currentUser.email) || 'admin') + ' (manual check)'; }
        }
        if (patch.adminNote != null) upd.adminNote = String(patch.adminNote);
        prodSnaps.forEach(([r, ps, q]) => {
          if (ps.exists()) tx.update(r, { stock: Math.max(0, H.num(ps.data().stock) + stockDelta * q), updatedAt: serverTimestamp() });
        });
        tx.update(ref, upd);
        const ps = upd.paymentStatus || o.paymentStatus, os = upd.orderStatus || o.orderStatus;
        tx.set(doc(db, 'payments', orderId), { orderId, amount: o.total, method: o.paymentMethod, status: ps, updatedAt: serverTimestamp() }, { merge: true });
        tx.set(doc(db, 'orderTracking', orderId), { orderStatus: os, paymentStatus: ps, updatedAt: serverTimestamp() }, { merge: true });
        return Object.assign(plain(o), plain(upd), { orderId });
      });
    },
    async saveProduct(p) {
      const isNew = !p.id;
      const x = H.productFromInput(p);
      if (isNew) { x.id = 'vx-' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5); if (!x.sku) x.sku = x.id.toUpperCase(); }
      const data = Object.assign({}, x, { updatedAt: serverTimestamp() });
      delete data.id;
      if (isNew) data.createdAt = serverTimestamp();
      if (p.sort == null && !isNew) delete data.sort;
      await setDoc(doc(db, 'products', x.id), data, { merge: true });
      return x;
    },
    async updateProduct(id, patch) {
      const d = Object.assign({}, patch, { updatedAt: serverTimestamp() });
      if (d.status) d.visible = d.status !== 'HIDDEN';
      if (d.stock != null) d.stock = Math.max(0, Math.floor(H.num(d.stock)));
      await updateDoc(doc(db, 'products', id), d);
    },
    async deleteProduct(id) { await deleteDoc(doc(db, 'products', id)); },
    async importSampleProducts(overwrite) {
      const existing = new Set((await getDocs(collection(db, 'products'))).docs.map(d => d.id));
      const batch = writeBatch(db); let n = 0;
      (window.VX_SEED_PRODUCTS || []).forEach(s => {
        if (existing.has(s.id) && !overwrite) return;
        const x = H.productFromInput(s); const id = x.id; delete x.id;
        batch.set(doc(db, 'products', id), Object.assign(x, { createdAt: serverTimestamp(), updatedAt: serverTimestamp() }));
        n++;
      });
      const st = await getDoc(doc(db, 'settings', 'store'));
      if (!st.exists()) batch.set(doc(db, 'settings', 'store'), H.normSettings({}));
      await batch.commit();
      return n;
    },
    watchCoupons(cb) {
      return onSnapshot(collection(db, 'coupons'), snap => cb(snap.docs.map(d => Object.assign(plain(d.data()), { code: d.id }))), e => { console.error('[coupons]', e); cb([]); });
    },
    async saveCoupon(c, oldCode) {
      const code = String(c.code).trim().toUpperCase();
      const data = Object.assign({}, c); delete data.code;
      const ref = doc(db, 'coupons', code);
      if (oldCode && oldCode !== code) {
        const old = await getDoc(doc(db, 'coupons', oldCode));
        const b = writeBatch(db);
        b.set(ref, Object.assign(data, { usedCount: old.exists() ? H.num(old.data().usedCount) : 0, createdAt: old.exists() && old.data().createdAt ? old.data().createdAt : serverTimestamp() }));
        b.delete(doc(db, 'coupons', oldCode));
        await b.commit();
      } else {
        const cur = await getDoc(ref);
        if (!cur.exists()) { data.usedCount = 0; data.createdAt = serverTimestamp(); } else { delete data.usedCount; }
        await setDoc(ref, data, { merge: true });
      }
      return Object.assign({}, c, { code });
    },
    async deleteCoupon(code) { await deleteDoc(doc(db, 'coupons', code)); },
    async saveSettings(s) { const x = H.normSettings(s); await setDoc(doc(db, 'settings', 'store'), x, { merge: true }); return x; },
    // Keeps customers/{phone} up to date from orders the admin has seen.
    async syncCustomers(orders) {
      if (!orders || !orders.length) return;
      const b = writeBatch(db);
      orders.slice(0, 400).forEach(o => {
        const phone = H.normPhone(o.phone); if (!phone) return;
        b.set(doc(db, 'customers', phone), { name: o.customerName || '', phone, email: o.email || '', lastOrderId: o.orderId, lastOrderAt: o.createdAt || null, guest: true, updatedAt: serverTimestamp() }, { merge: true });
      });
      await b.commit();
    },
    // Optional Firebase Storage upload (Blaze plan). Returns a URL, or null when Storage is off.
    uploadImage: opts.useStorage ? async (blob, name) => {
      const st = await import(BASE + 'firebase-storage.js');
      const storage = st.getStorage(app);
      const r = st.ref(storage, 'products/' + Date.now() + '-' + String(name || 'photo').replace(/[^\w.-]/g, '_'));
      await st.uploadBytes(r, blob, { contentType: blob.type || 'image/jpeg', cacheControl: 'public,max-age=31536000' });
      return st.getDownloadURL(r);
    } : null,

    /* ---------------- REAL admin login: Firebase Auth ----------------
       Email + password users are created in Firebase Console →
       Authentication. A user is an admin only if a document
       admins/{their UID} exists (you add it in the console). */
    auth: {
      kind: 'firebase',
      needsSetup: () => false,
      async login(email, pw, remember) {
        const m = await loadAuth();
        await m.setPersistence(auth, remember ? m.browserLocalPersistence : m.browserSessionPersistence);
        let cred;
        try { cred = await m.signInWithEmailAndPassword(auth, String(email).trim(), pw); }
        catch (e) {
          const c = e && e.code || '';
          if (/invalid-credential|wrong-password|user-not-found|invalid-email/.test(c)) throw err('bad-login', 'Wrong email or password.');
          if (/too-many-requests/.test(c)) throw err('locked', 'Too many attempts. Please wait a few minutes and try again.');
          if (/network/.test(c)) throw err('network', 'No internet connection. Please try again.');
          throw err('auth', 'Login failed (' + c + ').');
        }
        if (!(await isAdmin(cred.user.uid))) {
          const uid = cred.user.uid;
          await m.signOut(auth);
          throw err('not-admin', 'This account is not an admin yet. In Firebase → Firestore, add a document in "admins" with ID: ' + uid, { uid });
        }
        currentUser = { id: cred.user.uid, email: cred.user.email, name: cred.user.email };
        return currentUser;
      },
      async logout() { const m = await loadAuth(); currentUser = null; await m.signOut(auth); },
      current: () => currentUser,
      onChange(fn) {
        let un = null, stopped = false;
        loadAuth().then(m => {
          if (stopped) return;
          un = m.onAuthStateChanged(auth, async u => {
            if (u && await isAdmin(u.uid)) currentUser = { id: u.uid, email: u.email, name: u.email };
            else currentUser = null;
            fn(currentUser);
          });
        }).catch(e => { console.error(e); fn(null); });
        return () => { stopped = true; if (un) un(); };
      }
    }
  };
  return A;
}
