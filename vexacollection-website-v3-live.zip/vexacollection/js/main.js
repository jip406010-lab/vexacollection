/* VEXACOLLECTION — site script (plain JavaScript, no libraries) */
(function () {
  'use strict';

  document.documentElement.classList.add('js');

  // 1) Add to Cart buttons are handled in js/cart.js (cart + checkout).
  //    WhatsApp is used only for support links (header, contact, floating button).

  // 2) Announcement bar: rotate messages
  var items = document.querySelectorAll('.announce-item');
  if (items.length > 1) {
    var idx = 0;
    setInterval(function () {
      items[idx].classList.remove('is-active');
      idx = (idx + 1) % items.length;
      items[idx].classList.add('is-active');
    }, 4200);
  }

  // 3) Header: shadow on scroll + mobile menu
  var header = document.querySelector('.header');
  var toggle = document.querySelector('.menu-toggle');
  var nav = document.getElementById('site-nav');
  function onScroll() { header.classList.toggle('is-scrolled', window.scrollY > 10); }
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  function setMenu(open) {
    if (open) {
      var r = header.getBoundingClientRect();
      nav.style.setProperty('--nav-top', Math.max(0, r.bottom) + 'px');
    }
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    toggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    document.body.classList.toggle('menu-open', open);
  }
  if (toggle && nav) {
    toggle.addEventListener('click', function () { setMenu(!nav.classList.contains('is-open')); });
    nav.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', function () { setMenu(false); }); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setMenu(false); });
    window.addEventListener('resize', function () { if (window.innerWidth >= 1024) setMenu(false); });
  }

  // 4) Product filters (also used by the collection cards)
  var chips = document.querySelectorAll('.chip');
  var currentFilter = 'all';
  function applyFilter(filter) {
    currentFilter = filter;
    var products = document.querySelectorAll('.product');   // live: products are re-drawn from the store (js/shop.js)
    chips.forEach(function (c) {
      var on = c.getAttribute('data-filter') === filter;
      c.classList.toggle('is-active', on);
      c.setAttribute('aria-pressed', on ? 'true' : 'false');
    });
    products.forEach(function (p) {
      var show = filter === 'all' || p.getAttribute('data-category') === filter;
      p.classList.toggle('is-hidden', !show);
      if (show) p.classList.add('is-visible');
    });
  }
  chips.forEach(function (c) {
    c.addEventListener('click', function () { applyFilter(c.getAttribute('data-filter')); });
  });
  document.querySelectorAll('.collection[data-filter]').forEach(function (card) {
    card.addEventListener('click', function () { applyFilter(card.getAttribute('data-filter')); });
  });

  window.VXFilter = { apply: applyFilter, current: function () { return currentFilter; } };

  // 5) Reveal-on-scroll animation
  var reveals = document.querySelectorAll('.reveal');
  var io = null;
  if ('IntersectionObserver' in window) {
    io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          io.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });
    reveals.forEach(function (el, i) {
      el.style.transitionDelay = ((i % 4) * 80) + 'ms';
      io.observe(el);
    });
  } else {
    reveals.forEach(function (el) { el.classList.add('is-visible'); });
  }
  // used by js/shop.js for product cards drawn after page load
  window.VXReveal = function (el, i) {
    if (!io) { el.classList.add('is-visible'); return; }
    el.style.transitionDelay = (((i || 0) % 4) * 80) + 'ms';
    io.observe(el);
  };

  // 6) Footer year
  var y = document.querySelector('.year');
  if (y) y.textContent = new Date().getFullYear();
})();
