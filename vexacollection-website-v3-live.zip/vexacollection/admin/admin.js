
/* =========================================================
   VEXACOLLECTION ADMIN — admin panel app (plain JavaScript)
   Talks ONLY to window.VXStore (js/store-api.js) — the same data layer
   the shop uses. Firebase mode = real shared database + Firebase Auth.
   Demo mode = this browser only.
   ========================================================= */
(function () {
  'use strict';

  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var Store = window.VXStore;
  var U = Store.util, esc = U.esc, money = U.money, num = U.num;
  var IDLE_MS = 30 * 60 * 1000;               // 30 min idle → logout
  var IDLE_MS_REMEMBER = 7 * 24 * 60 * 60 * 1000; // "remember me": 7 days idle
  var LAST_ACTIVE = 'vx_admin_last_active', REMEMBER = 'vx_admin_remember';

  /* ---------------- icons (simple line icons) ---------------- */
  var P = {
    dashboard: '<rect x="3" y="3" width="7" height="9" rx="1.5"/><rect x="14" y="3" width="7" height="5" rx="1.5"/><rect x="14" y="12" width="7" height="9" rx="1.5"/><rect x="3" y="16" width="7" height="5" rx="1.5"/>',
    orders: '<path d="M6 3h12l1 4H5l1-4Z"/><path d="M5 7h14v12.5A1.5 1.5 0 0 1 17.5 21h-11A1.5 1.5 0 0 1 5 19.5V7Z"/><path d="M9 11h6"/>',
    products: '<path d="M20.4 7.2 12 3 3.6 7.2 12 11.4l8.4-4.2Z"/><path d="M3.6 7.2v9.6L12 21l8.4-4.2V7.2"/><path d="M12 11.4V21"/>',
    inventory: '<path d="M3 21V9l9-6 9 6v12"/><path d="M7 21v-8h10v8"/><path d="M7 17h10"/>',
    customers: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 4.5a3.5 3.5 0 0 1 0 7"/><path d="M18.5 14.2A6.5 6.5 0 0 1 21.5 20"/>',
    payments: '<rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="M2.5 10h19"/><path d="M6.5 15h4"/>',
    coupons: '<path d="M3 7.5V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2.5a2.5 2.5 0 0 0 0 5V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6.5a2.5 2.5 0 0 0 0-5Z"/><path d="M9 15l6-6"/><circle cx="9.5" cy="9.5" r=".6"/><circle cx="14.5" cy="14.5" r=".6"/>',
    analytics: '<path d="M3 3v18h18"/><path d="M7 15l4-4 3 3 5-6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1Z"/>',
    logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5"/><path d="M21 12H9"/>',
    bell: '<path d="M6 8a6 6 0 1 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.9 1.9 0 0 0 3.4 0"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16v4Z"/><path d="m13.5 6.5 4 4"/>',
    trash: '<path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M6 7l1 13h10l1-13"/><path d="M9 7V4h6v3"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    eyeoff: '<path d="M3 3l18 18"/><path d="M10.6 5.1A10.7 10.7 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3 3.9M6.6 6.6A17 17 0 0 0 2 12s3.5 7 10 7a10 10 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    print: '<path d="M6 9V3h12v6"/><rect x="3" y="9" width="18" height="8" rx="2"/><path d="M6 14h12v7H6z"/>',
    download: '<path d="M12 3v12"/><path d="m7 10 5 5 5-5"/><path d="M4 21h16"/>',
    phone: '<path d="M5 4h3.5l1.6 4.2-2.1 1.4a11 11 0 0 0 6.4 6.4l1.4-2.1L20 15.5V19a1.5 1.5 0 0 1-1.6 1.5A16.5 16.5 0 0 1 3.5 5.6 1.5 1.5 0 0 1 5 4Z"/>',
    wa: '<path d="M3.5 20.5l1.3-4.6A8.5 8.5 0 1 1 8 19.3l-4.5 1.2Z"/><path d="M9 9.5c.5 2 2.5 4 4.5 4.5l1-1.2 2 .9c-.3 1.2-1.3 1.8-2.3 1.6-3-.6-5.4-3-6-6-.2-1 .4-2 1.6-2.3l.9 2-1 .9"/>',
    check: '<path d="m5 12.5 4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    alert: '<path d="M12 3 2 20h20L12 3Z"/><path d="M12 10v4"/><circle cx="12" cy="17" r=".6"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="8" r=".6"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    rupee: '<path d="M6 4h12M6 9h12M9 4c6 0 6 10 0 10H6l8 7"/>',
    box: '<path d="M21 8 12 3 3 8v8l9 5 9-5V8Z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
    truck: '<path d="M2 6h11v10H2z"/><path d="M13 9h4l4 4v3h-8"/><circle cx="6" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    ban: '<circle cx="12" cy="12" r="9"/><path d="m5.6 5.6 12.8 12.8"/>',
    upload: '<path d="M12 16V4"/><path d="m7 9 5-5 5 5"/><path d="M4 20h16"/>',
    store: '<path d="M3 9l1.5-5h15L21 9"/><path d="M4 9v11h16V9"/><path d="M3 9h18a3 3 0 0 1-6 0 3 3 0 0 1-6 0 3 3 0 0 1-6 0"/>',
    arrowl: '<path d="M15 6l-6 6 6 6"/>'
  };
  function ico(name) { return '<span class="ico" aria-hidden="true"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + (P[name] || '') + '</svg></span>'; }
  function fillIcons(root) { $$('[data-ico]', root).forEach(function (el) { el.outerHTML = ico(el.getAttribute('data-ico')); }); }

  /* ---------------- helpers ---------------- */
  function img(src) {   // product images are saved relative to the shop's root
    src = String(src || '');
    if (!src) return '../images/favicon.svg';
    if (/^(https?:|data:|blob:|\/)/.test(src)) return src;
    return '../' + src;
  }
  function fmtDate(iso, withTime) {
    if (!iso) return '\u2014';
    var d = new Date(iso); if (!isFinite(d)) return '\u2014';
    var o = { timeZone: 'Asia/Kolkata', day: 'numeric', month: 'short', year: 'numeric' };
    if (withTime) { o.hour = 'numeric'; o.minute = '2-digit'; o.hour12 = true; }
    return d.toLocaleString('en-IN', o);
  }
  function ago(iso) {
    var s = (Date.now() - new Date(iso).getTime()) / 1000;
    if (!isFinite(s)) return '';
    if (s < 60) return 'just now';
    if (s < 3600) return Math.floor(s / 60) + ' min ago';
    if (s < 86400) return Math.floor(s / 3600) + ' h ago';
    return fmtDate(iso);
  }
  function istDay(d) { return new Date(new Date(d).getTime() + 5.5 * 3600e3).toISOString().slice(0, 10); }  // YYYY-MM-DD in IST
  function fmtPhone(m) { m = U.normPhone(m); return m.length === 10 ? '+91 ' + m.slice(0, 5) + ' ' + m.slice(5) : (m || '\u2014'); }
  function waLink(phone, text) { var p = U.normPhone(phone); if (p.length === 10) p = '91' + p; return 'https://wa.me/' + p + (text ? '?text=' + encodeURIComponent(text) : ''); }
  function telLink(phone) { var p = U.normPhone(phone); return 'tel:' + (p.length === 10 ? '+91' + p : p); }
  function pill(kind, code) { return '<span class="pill ' + kind + '-' + esc(code) + '">' + esc(U.label(code)) + '</span>'; }
  function oPill(s) { return pill('s', s || 'NEW'); }
  function pPill(s) { return pill('p', s || 'PENDING'); }
  function isSale(o) { return o.orderStatus !== 'CANCELLED' && o.paymentStatus !== 'REFUNDED' && o.paymentStatus !== 'FAILED'; }
  function qs() { var q = (location.hash.split('?')[1] || ''); var o = {}; q.split('&').forEach(function (kv) { if (!kv) return; var p = kv.split('='); o[decodeURIComponent(p[0])] = decodeURIComponent(p[1] || ''); }); return o; }
  function debounce(fn, ms) { var t; return function () { var a = arguments, me = this; clearTimeout(t); t = setTimeout(function () { fn.apply(me, a); }, ms); }; }
  function addrText(a) {
    if (!a) return '';
    if (typeof a === 'string') return a;
    return a.full || [a.house, a.street, a.landmark ? 'Near ' + a.landmark : '', a.city, a.state].filter(Boolean).join(', ') + (a.pin ? ' - ' + a.pin : '');
  }
  function normOrder(o) {
    o.products = o.products || o.items || [];
    if (!o.customerName && o.customer) { o.customerName = o.customer.name; o.phone = o.customer.mobile; o.email = o.customer.email; }
    o.discount = num(o.discount); o.shipping = num(o.shipping); o.subtotal = num(o.subtotal); o.total = num(o.total);
    if (!o.orderStatus || o.orderStatus === 'placed') o.orderStatus = 'NEW';
    if (!o.paymentStatus || o.paymentStatus === 'pending') o.paymentStatus = o.paymentMethod === 'COD' ? 'COD' : 'PENDING';
    return o;
  }

  /* ---------------- state ---------------- */
  var S = { user: null, orders: [], products: [], coupons: [], settings: U.normSettings({}), loaded: { orders: false, products: false, coupons: false }, subs: [], seen: {} };
  function productById(id) { return S.products.filter(function (p) { return p.id === id; })[0] || null; }
  function orderById(id) { return S.orders.filter(function (o) { return o.orderId === id; })[0] || null; }

  /* ---------------- toasts ---------------- */
  function toast(msg, opts) {
    opts = opts || {};
    var t = document.createElement('div');
    t.className = 'toast' + (opts.bad ? ' is-bad' : '') + (opts.order ? ' is-order' : '');
    t.setAttribute('role', opts.bad ? 'alert' : 'status');
    t.innerHTML = ico(opts.icon || (opts.bad ? 'alert' : 'check')) + '<div class="grow">' + msg + '</div>' + (opts.action ? '<a href="' + esc(opts.action.href) + '">' + esc(opts.action.label) + '</a>' : '');
    $('#toasts').appendChild(t);
    var tm = setTimeout(function () { t.remove(); }, opts.ms || 3800);
    t.addEventListener('click', function (e) { if (e.target.closest('a')) { clearTimeout(tm); t.remove(); } });
    while ($('#toasts').children.length > 4) $('#toasts').firstChild.remove();
  }
  function errMsg(e) { return esc((e && e.message) || 'Something went wrong. Please try again.'); }

  /* ---------------- modal ---------------- */
  var modalCloseCb = null;
  function modal(title, body, foot, onClose) {
    $('#modal-root').innerHTML = '<div class="modal-wrap" data-modal-bg><div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">' +
      '<div class="modal-head"><h3 id="modal-title">' + title + '</h3><button type="button" class="iconbtn" data-modal-close aria-label="Close">' + ico('x') + '</button></div>' +
      '<div class="modal-body">' + body + '</div>' + (foot ? '<div class="modal-foot">' + foot + '</div>' : '') + '</div></div>';
    modalCloseCb = onClose || null;
    setTimeout(function () { var f = $('#modal-root input:not([type=hidden]),#modal-root select,#modal-root textarea,#modal-root .modal-foot .btn'); if (f) f.focus(); }, 50);
    return $('#modal-root .modal');
  }
  function closeModal() { $('#modal-root').innerHTML = ''; if (modalCloseCb) { var c = modalCloseCb; modalCloseCb = null; c(); } }
  $('#modal-root').addEventListener('click', function (e) { if (e.target.closest('[data-modal-close]') || e.target.hasAttribute('data-modal-bg')) closeModal(); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && $('#modal-root').innerHTML) closeModal(); });
  function confirmBox(title, text, okLabel, danger) {
    return new Promise(function (resolve) {
      var done = false;
      modal(esc(title), '<p>' + text + '</p>', '<button type="button" class="btn" data-modal-close>Cancel</button><button type="button" class="btn ' + (danger ? 'btn-danger' : 'btn-dark') + '" data-ok>' + esc(okLabel || 'OK') + '</button>', function () { if (!done) resolve(false); });
      $('#modal-root [data-ok]').addEventListener('click', function () { done = true; closeModal(); resolve(true); });
    });
  }

  /* ---------------- sound for new orders ---------------- */
  var audioCtx = null;
  function unlockAudio() { try { if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)(); if (audioCtx.state === 'suspended') audioCtx.resume(); } catch (e) {} }
  function chime() {
    try {
      unlockAudio(); if (!audioCtx) return;
      var t0 = audioCtx.currentTime;
      [880, 1318.5].forEach(function (f, i) {
        var o = audioCtx.createOscillator(), g = audioCtx.createGain();
        o.type = 'sine'; o.frequency.value = f;
        g.gain.setValueAtTime(0.0001, t0 + i * 0.18);
        g.gain.exponentialRampToValueAtTime(0.25, t0 + i * 0.18 + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, t0 + i * 0.18 + 0.5);
        o.connect(g); g.connect(audioCtx.destination); o.start(t0 + i * 0.18); o.stop(t0 + i * 0.18 + 0.55);
      });
    } catch (e) {}
  }
  document.addEventListener('pointerdown', unlockAudio, { once: true });

  /* =========================================================
     AUTH SCREENS
     ========================================================= */
  var A = null;   // adapter
  function show(which) {
    document.body.classList.remove('is-booting');
    $('#auth').hidden = which !== 'auth';
    $('#app').hidden = which !== 'app';
  }
  function pwField(id, label, auto) {
    return '<div class="f"><label for="' + id + '">' + label + '</label><div class="pw-wrap">' +
      '<input class="in" id="' + id + '" type="password" autocomplete="' + auto + '" required minlength="' + (auto === 'new-password' ? 8 : 1) + '">' +
      '<button type="button" class="pw-toggle" data-pw="' + id + '" aria-label="Show password" aria-pressed="false">Show</button></div></div>';
  }
  $('#auth').addEventListener('click', function (e) {
    var b = e.target.closest('[data-pw]'); if (!b) return;
    var i = document.getElementById(b.getAttribute('data-pw'));
    var showIt = i.type === 'password';
    i.type = showIt ? 'text' : 'password';
    b.textContent = showIt ? 'Hide' : 'Show';
    b.setAttribute('aria-pressed', showIt ? 'true' : 'false');
    b.setAttribute('aria-label', showIt ? 'Hide password' : 'Show password');
  });

  function showSetup() {
    show('auth');
    $('#auth-box').innerHTML =
      '<img class="auth-logo" src="../images/logo.svg" alt="VEXACOLLECTION">' +
      '<h1>Create admin login</h1><p class="lead">First time here. Choose the username and password you will use to open this admin panel.</p>' +
      '<form id="setup-form" novalidate>' +
        '<div class="auth-err" id="auth-err" hidden></div>' +
        '<div class="f"><label for="su-user">Username</label><input class="in" id="su-user" value="admin" autocomplete="username" required></div>' +
        pwField('su-pw', 'Password (at least 8 characters)', 'new-password') +
        pwField('su-pw2', 'Confirm password', 'new-password') +
        '<button class="btn btn-dark btn-block btn-lg" type="submit">Create &amp; continue</button>' +
      '</form>' +
      '<p class="auth-note"><strong>Demo mode:</strong> this login is saved only in this browser (as a secure hash, never the password itself). When Firebase is connected, the panel uses real Firebase email/password login instead.</p>';
    $('#setup-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var u = $('#su-user').value.trim(), p1 = $('#su-pw').value, p2 = $('#su-pw2').value, er = $('#auth-err');
      er.hidden = true;
      var msg = !u ? 'Please enter a username.' : p1.length < 8 ? 'Password must be at least 8 characters.' : p1 !== p2 ? 'The two passwords do not match.' : '';
      if (msg) { er.textContent = msg; er.hidden = false; return; }
      var btn = e.submitter || $('#setup-form button[type=submit]'); btn.disabled = true; btn.textContent = 'Saving\u2026';
      unlockAudio();
      A.auth.setup(u, p1).then(function () { return A.auth.login(u, p1, false); }).then(function () {
        localStorage.setItem(REMEMBER, '0'); touch(true);
      }).catch(function (x) { er.textContent = x.message; er.hidden = false; btn.disabled = false; btn.textContent = 'Create & continue'; });
    });
    setTimeout(function () { $('#su-pw').focus(); }, 50);
  }

  function showLogin(note) {
    show('auth');
    var fb = A.auth.kind === 'firebase';
    $('#auth-box').innerHTML =
      '<img class="auth-logo" src="../images/logo.svg" alt="VEXACOLLECTION">' +
      '<h1>Admin login</h1><p class="lead">Sign in to manage orders, products and payments.</p>' +
      '<form id="login-form" novalidate>' +
        (note ? '<div class="auth-err" style="color:var(--warn);background:var(--warn-bg)">' + esc(note) + '</div>' : '') +
        '<div class="auth-err" id="auth-err" hidden></div>' +
        '<div class="f"><label for="li-user">' + (fb ? 'Email' : 'Username / Email') + '</label><input class="in" id="li-user" type="' + (fb ? 'email' : 'text') + '" autocomplete="username" autocapitalize="none" spellcheck="false" required></div>' +
        pwField('li-pw', 'Password', 'current-password') +
        '<label class="check"><input type="checkbox" id="li-remember"' + (localStorage.getItem(REMEMBER) === '1' ? ' checked' : '') + '> Remember me on this device</label>' +
        '<button class="btn btn-dark btn-block btn-lg" type="submit">Login</button>' +
      '</form>' +
      (fb ? '<p class="auth-note is-info">Secure login by Firebase Authentication. Only accounts listed as admins can open this panel. You are logged out after 30 minutes without activity (7 days if &ldquo;Remember me&rdquo; is ticked).</p>'
          : '<p class="auth-note"><strong>Demo mode:</strong> login is checked in this browser only. Forgot the demo password? <button type="button" class="link" id="reset-demo">Reset demo login</button></p>');
    var rd = $('#reset-demo');
    if (rd) rd.addEventListener('click', function () {
      confirmBox('Reset demo login?', 'This removes the demo admin password saved in this browser so you can create a new one. Store data (products, orders) is kept.', 'Reset login', true).then(function (ok) { if (ok) { A.auth.resetDemoPassword(); showSetup(); } });
    });
    $('#login-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var u = $('#li-user').value.trim(), p = $('#li-pw').value, rem = $('#li-remember').checked, er = $('#auth-err');
      er.hidden = true;
      if (!u || !p) { er.textContent = 'Please enter your ' + (fb ? 'email' : 'username') + ' and password.'; er.hidden = false; return; }
      var btn = $('#login-form button[type=submit]'); btn.disabled = true; btn.textContent = 'Signing in\u2026';
      unlockAudio();
      localStorage.setItem(REMEMBER, rem ? '1' : '0');
      touch(true);
      A.auth.login(u, p, rem).catch(function (x) { er.textContent = x.message; er.hidden = false; btn.disabled = false; btn.textContent = 'Login'; $('#li-pw').select(); });
    });
    setTimeout(function () { $('#li-user').focus(); }, 50);
  }

  /* ---------------- session timeout ---------------- */
  var lastTouch = 0;
  function idleLimit() { return localStorage.getItem(REMEMBER) === '1' ? IDLE_MS_REMEMBER : IDLE_MS; }
  function touch(force) {
    var n = Date.now();
    if (!force && n - lastTouch < 15000) return;
    lastTouch = n;
    try { localStorage.setItem(LAST_ACTIVE, String(n)); } catch (e) {}
  }
  function idleExpired() { var l = Number(localStorage.getItem(LAST_ACTIVE) || 0); return l && Date.now() - l > idleLimit(); }
  ['pointerdown', 'keydown', 'scroll', 'touchstart'].forEach(function (ev) { window.addEventListener(ev, function () { if (S.user) touch(); }, { passive: true }); });
  setInterval(function () { if (S.user && idleExpired()) logout('You were logged out after 30 minutes without activity.'); }, 20000);

  function logout(note) {
    stopData();
    S.user = null;
    pendingNote = note || '';
    A.auth.logout();
  }
  var pendingNote = '';

  /* =========================================================
     APP SHELL + ROUTER
     ========================================================= */
  var NAV = [
    ['dashboard', 'Dashboard'], ['orders', 'Orders'], ['products', 'Products'], ['inventory', 'Inventory'],
    ['customers', 'Customers'], ['payments', 'Payments'], ['coupons', 'Coupons'], ['analytics', 'Analytics'], ['settings', 'Settings']
  ];
  function buildNav() {
    $('#sb-nav').innerHTML = NAV.map(function (n) {
      return '<a class="sb-item" href="#/' + n[0] + '" data-nav="' + n[0] + '">' + ico(n[0]) + '<span>' + n[1] + '</span><span class="sb-count" data-count="' + n[0] + '" hidden></span></a>';
    }).join('');
    fillIcons(document.body);
  }
  function setMenu(open) {
    document.body.classList.toggle('menu-open', open);
    $('.tb-menu').setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-action]');
    if (!a) { if (e.target.closest('.sb-item')) setMenu(false); return; }
    var act = a.getAttribute('data-action');
    if (act === 'open-menu') setMenu(true);
    else if (act === 'close-menu') setMenu(false);
    else if (act === 'logout') { setMenu(false); confirmBox('Log out?', 'You will need your password to open the admin panel again.', 'Logout').then(function (ok) { if (ok) logout(''); }); }
  });

  function startApp() {
    show('app');
    buildNav();
    var demo = Store.mode === 'demo';
    $('#demo-banner').hidden = !demo;
    var mp = $('#mode-pill'); mp.className = 'mode-pill ' + (demo ? 'is-demo' : 'is-live'); mp.textContent = demo ? 'Demo mode' : 'Live \u00B7 Firebase';
    $('#tb-user').textContent = S.user.email || S.user.name || 'admin';
    $('#tb-avatar').textContent = String(S.user.email || S.user.name || 'A').charAt(0);
    startData();
    if (!location.hash || location.hash === '#' || location.hash === '#/') location.hash = '#/dashboard'; else route();
  }

  function startData() {
    stopData();
    S.subs.push(A.watchOrders(function (list, ch) {
      S.orders = list.map(normOrder);
      var first = !S.loaded.orders;
      S.loaded.orders = true;
      if (!first && ch && ch.added && ch.added.length) onNewOrders(ch.added.map(normOrder));
      if (first && A.syncCustomers && S.orders.length) A.syncCustomers(S.orders.slice(0, 50)).catch(function () {});
      if (ch && ch.error) toast('Could not load orders: ' + errMsg(ch.error), { bad: true, ms: 8000 });
      refresh();
    }));
    S.subs.push(A.watchProducts(function (list) { S.products = list; S.loaded.products = true; refresh(); }, { all: true }));
    S.subs.push(A.watchCoupons(function (list) { S.coupons = list; S.loaded.coupons = true; refresh(); }));
    S.subs.push(A.watchSettings(function (s) { S.settings = s; refresh('settings'); }));
  }
  function stopData() { S.subs.forEach(function (u) { try { u(); } catch (e) {} }); S.subs = []; S.loaded = { orders: false, products: false, coupons: false }; }

  function onNewOrders(list) {
    list.forEach(function (o) {
      if (S.seen[o.orderId]) return;
      S.seen[o.orderId] = true;
      toast('<strong>New order ' + esc(o.orderId) + '</strong><br>' + esc(o.customerName || '') + ' \u00B7 ' + money(o.total) + ' \u00B7 ' + esc(o.paymentMethod), { order: true, icon: 'bell', ms: 9000, action: { href: '#/orders/' + encodeURIComponent(o.orderId), label: 'Open' } });
    });
    chime();
    var bell = $('#tb-bell'); bell.classList.remove('ring'); void bell.offsetWidth; bell.classList.add('ring');
    try { if (window.Notification && Notification.permission === 'granted' && document.hidden) new Notification('New order \u2014 VEXACOLLECTION', { body: list[0].orderId + ' \u00B7 ' + money(list[0].total), icon: '../images/favicon.svg' }); } catch (e) {}
    if (A.syncCustomers) A.syncCustomers(list).catch(function () {});
  }

  function updateBadges() {
    var newCount = S.orders.filter(function (o) { return o.orderStatus === 'NEW'; }).length;
    var payCount = S.orders.filter(function (o) { return o.paymentMethod === 'UPI' && o.paymentStatus === 'PENDING' && o.orderStatus !== 'CANCELLED'; }).length;
    var outCount = S.products.filter(function (p) { return p.status !== 'HIDDEN' && U.availability(p) === 'out'; }).length;
    function setC(k, n) { var el = $('[data-count="' + k + '"]'); if (el) { el.textContent = n; el.hidden = !n; } }
    setC('orders', newCount); setC('payments', payCount); setC('inventory', outCount);
    var b = $('#tb-badge'); b.textContent = newCount; b.hidden = !newCount;
    document.title = (newCount ? '(' + newCount + ') ' : '') + 'VEXACOLLECTION ADMIN';
  }

  var current = { name: '', param: '' };
  function parseHash() {
    var h = (location.hash || '').replace(/^#\/?/, '');
    var path = h.split('?')[0].split('/');
    return { name: path[0] || 'dashboard', param: decodeURIComponent(path.slice(1).join('/') || '') };
  }
  var TITLES = { dashboard: 'Dashboard', orders: 'Orders', products: 'Products', inventory: 'Inventory', customers: 'Customers', payments: 'Payments', coupons: 'Coupons', analytics: 'Analytics', settings: 'Settings' };
  function route() {
    if (!S.user) return;
    var r = parseHash();
    if (!VIEWS[r.name]) { location.hash = '#/dashboard'; return; }
    var changed = r.name !== current.name || r.param !== current.param;
    current = r;
    $$('.sb-item[data-nav]').forEach(function (a) { var on = a.getAttribute('data-nav') === r.name; a.classList.toggle('is-active', on); if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
    $('#page-title').textContent = TITLES[r.name];
    setMenu(false);
    renderView();
    if (changed) { window.scrollTo(0, 0); }
  }
  window.addEventListener('hashchange', route);

  function renderView() {
    var v = VIEWS[current.name];
    var view = $('#view');
    view.innerHTML = v.render(current.param);
    if (v.mount) v.mount(view, current.param);
    updateBadges();
  }
  // Re-draw the current page when live data changes — but never while
  // the admin is typing in a form or has unsaved choices.
  var refreshTimer = null;
  function refresh(which) {
    updateBadges();
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(function () {
      if (!S.user || $('#app').hidden) return;
      var v = VIEWS[current.name]; if (!v) return;
      var view = $('#view');
      if (view.querySelector('[data-dirty="1"]')) return;
      var ae = document.activeElement;
      if (ae && view.contains(ae) && /^(INPUT|SELECT|TEXTAREA)$/.test(ae.tagName)) { ae.addEventListener('blur', function once() { ae.removeEventListener('blur', once); refresh(); }); return; }
      var y = window.scrollY;
      renderView();
      window.scrollTo(0, y);
    }, 60);
  }

  function statCard(label, value, sub, icon, href, dark) {
    return '<' + (href ? 'a href="' + href + '"' : 'div') + ' class="stat' + (dark ? ' is-dark' : '') + '">' +
      '<div class="stat-top"><span class="stat-label">' + label + '</span><span class="stat-ico">' + ico(icon) + '</span></div>' +
      '<div class="stat-val">' + value + '</div>' + (sub ? '<div class="stat-sub">' + sub + '</div>' : '') +
    '</' + (href ? 'a' : 'div') + '>';
  }
  function loadingCard() { return '<div class="card"><div class="empty">Loading\u2026</div></div>'; }
  function customersFromOrders() {
    var map = {};
    S.orders.forEach(function (o) {
      var k = U.normPhone(o.phone) || ('x' + o.orderId);
      var c = map[k] || (map[k] = { phone: U.normPhone(o.phone), name: o.customerName, email: o.email || '', orders: [], spent: 0, last: null });
      c.orders.push(o);
      if (isSale(o)) c.spent += o.total;
      if (!c.last || o.createdAt > c.last) { c.last = o.createdAt; c.name = o.customerName || c.name; if (o.email) c.email = o.email; }
    });
    return Object.keys(map).map(function (k) { return map[k]; }).sort(function (a, b) { return String(b.last).localeCompare(String(a.last)); });
  }

  /* =========================================================
     ORDERS TABLE (used by Dashboard, Orders, Customer)
     ========================================================= */
  function ordersTable(list, opts) {
    opts = opts || {};
    if (!list.length) return '<div class="empty">' + ico('orders') + '<strong>' + (opts.emptyTitle || 'No orders yet') + '</strong>' + (opts.emptyText || 'New orders from the website will appear here instantly.') + '</div>';
    return '<div class="tbl-wrap"><table class="tbl tbl-cards"><thead><tr><th>Order ID</th><th>Customer</th><th class="num">Amount</th><th>Payment</th><th>Status</th><th>Date</th><th><span class="sr-only">Action</span></th></tr></thead><tbody>' +
      list.map(function (o) {
        return '<tr class="is-click' + (o.orderStatus === 'NEW' ? ' is-new' : '') + '" data-open-order="' + esc(o.orderId) + '">' +
          '<td class="td-head" data-label="Order ID"><span class="oid">' + esc(o.orderId) + '</span></td>' +
          '<td data-label="Customer"><span class="cell-stack"><span>' + esc(o.customerName || '\u2014') + '</span><span class="small muted mono">' + esc(fmtPhone(o.phone)) + '</span></span></td>' +
          '<td class="num" data-label="Amount"><strong>' + money(o.total) + '</strong></td>' +
          '<td data-label="Payment"><div class="pay-cell"><span class="method">' + esc(o.paymentMethod) + '</span>' + pPill(o.paymentStatus) + '</div></td>' +
          '<td data-label="Status">' + oPill(o.orderStatus) + '</td>' +
          '<td data-label="Date"><span class="small">' + fmtDate(o.createdAt, true) + '</span></td>' +
          '<td class="td-actions"><a class="btn btn-sm" href="#/orders/' + encodeURIComponent(o.orderId) + '">View</a></td>' +
        '</tr>';
      }).join('') + '</tbody></table></div>';
  }
  document.addEventListener('click', function (e) {
    var r = e.target.closest('[data-open-order]');
    if (r && !e.target.closest('a,button')) location.hash = '#/orders/' + encodeURIComponent(r.getAttribute('data-open-order'));
    var c = e.target.closest('[data-open-customer]');
    if (c && !e.target.closest('a,button')) location.hash = '#/customers/' + encodeURIComponent(c.getAttribute('data-open-customer'));
  });

  /* =========================================================
     DASHBOARD
     ========================================================= */
  var VIEWS = {};
  VIEWS.dashboard = {
    render: function () {
      var O = S.orders;
      function cnt(f) { return O.filter(f).length; }
      var sales = O.filter(isSale).reduce(function (a, o) { return a + o.total; }, 0);
      var received = O.filter(function (o) { return o.paymentStatus === 'PAID'; }).reduce(function (a, o) { return a + o.total; }, 0);
      var verify = O.filter(function (o) { return o.paymentMethod === 'UPI' && o.paymentStatus === 'PENDING' && o.orderStatus !== 'CANCELLED'; });
      var custs = customersFromOrders().length;
      var today = istDay(new Date());
      var todayOrders = O.filter(function (o) { return istDay(o.createdAt) === today; });
      var out = S.products.filter(function (p) { return p.status !== 'HIDDEN' && U.availability(p) === 'out'; });
      var low = S.products.filter(function (p) { return U.availability(p) === 'in' && num(p.stock) <= 3; });
      var h = new Date().toLocaleString('en-IN', { timeZone: 'Asia/Kolkata', hour: 'numeric', hour12: false });
      var greet = h < 12 ? 'Good morning' : h < 17 ? 'Good afternoon' : 'Good evening';
      return '<div class="page-head"><div><h2>' + greet + ' <span class="serif">&mdash; here&rsquo;s your store</span></h2><p class="sub">' + todayOrders.length + ' order' + (todayOrders.length === 1 ? '' : 's') + ' today \u00B7 ' + money(todayOrders.filter(isSale).reduce(function (a, o) { return a + o.total; }, 0)) + ' in sales today</p></div>' +
        '<div class="actions"><a class="btn" href="../index.html" target="_blank" rel="noopener">' + ico('store') + 'View store</a><a class="btn btn-dark" href="#/products/new">' + ico('plus') + 'Add product</a></div></div>' +
        (verify.length ? '<div class="callout callout-warn" style="margin-bottom:18px">' + ico('alert') + '<div class="grow"><strong>' + verify.length + ' UPI payment' + (verify.length > 1 ? 's' : '') + ' to verify (' + money(verify.reduce(function (a, o) { return a + o.total; }, 0)) + ').</strong> Check your UPI app for each amount, then mark the order as paid. Payments are never marked paid automatically.<br><a class="btn btn-sm" href="#/payments?status=PENDING">Review payments</a></div></div>' : '') +
        '<div class="stats stats-9">' +
          statCard('Total orders', cnt(function () { return true; }), todayOrders.length + ' today', 'orders', '#/orders') +
          statCard('Pending orders', cnt(function (o) { return o.orderStatus === 'NEW'; }), cnt(function (o) { return o.orderStatus === 'CONFIRMED'; }) + ' confirmed, not yet packed', 'clock', '#/orders?status=NEW') +
          statCard('Processing', cnt(function (o) { return o.orderStatus === 'PROCESSING'; }), 'Being packed', 'box', '#/orders?status=PROCESSING') +
          statCard('Shipped', cnt(function (o) { return o.orderStatus === 'SHIPPED' || o.orderStatus === 'OUT_FOR_DELIVERY'; }), cnt(function (o) { return o.orderStatus === 'OUT_FOR_DELIVERY'; }) + ' out for delivery', 'truck', '#/orders?status=SHIPPED') +
          statCard('Delivered', cnt(function (o) { return o.orderStatus === 'DELIVERED'; }), '', 'check', '#/orders?status=DELIVERED') +
          statCard('Cancelled', cnt(function (o) { return o.orderStatus === 'CANCELLED'; }), 'Stock returned', 'ban', '#/orders?status=CANCELLED') +
          statCard('Total products', S.products.length, out.length + ' out of stock \u00B7 ' + S.products.filter(function (p) { return p.status === 'HIDDEN'; }).length + ' hidden', 'products', '#/products') +
          statCard('Total customers', custs, 'Guest checkout', 'customers', '#/customers') +
          statCard('Total sales', money(sales), money(received) + ' marked paid', 'rupee', '#/analytics', true) +
        '</div>' +
        '<div class="dash-grid">' +
          '<section class="card"><div class="card-head"><h3>Recent orders</h3><a class="link" href="#/orders">View all</a></div>' + (S.loaded.orders ? ordersTable(O.slice(0, 8)) : '<div class="empty">Loading\u2026</div>') + '</section>' +
          '<section class="card"><div class="card-head"><h3>Stock alerts</h3><a class="link" href="#/inventory">Inventory</a></div>' +
            ((out.length + low.length) ? '<div class="mini-list">' + out.concat(low).slice(0, 8).map(function (p) {
              return '<a class="mini-row" href="#/inventory"><img class="thumb thumb-sm" src="' + esc(img(p.image)) + '" alt=""><div class="grow"><div class="t">' + esc(p.name) + '</div><div class="s">' + esc(p.sku || p.id) + '</div></div>' + (U.availability(p) === 'out' ? pill('i', 'out').replace('Out', 'Out of stock') : '<span class="pill i-low">' + p.stock + ' left</span>') + '</a>';
            }).join('') + '</div>' : '<div class="empty">' + ico('check') + '<strong>All products in stock</strong>Low stock (3 or fewer) shows here.</div>') +
          '</section>' +
        '</div>';
    }
  };

  /* =========================================================
     ORDERS
     ========================================================= */
  var OF = { q: '', date: 'all', from: '', to: '', status: '', pay: '', method: '' };
  function dateOk(o) {
    if (OF.date === 'all') return true;
    var d = istDay(o.createdAt), today = istDay(new Date());
    var dayMs = 86400e3, now = Date.now();
    if (OF.date === 'today') return d === today;
    if (OF.date === 'yesterday') return d === istDay(now - dayMs);
    if (OF.date === '7') return d >= istDay(now - 6 * dayMs);
    if (OF.date === '30') return d >= istDay(now - 29 * dayMs);
    if (OF.date === 'month') return d.slice(0, 7) === today.slice(0, 7);
    if (OF.date === 'custom') return (!OF.from || d >= OF.from) && (!OF.to || d <= OF.to);
    return true;
  }
  function filteredOrders() {
    var q = OF.q.trim().toLowerCase(), qd = q.replace(/\D/g, '');
    return S.orders.filter(function (o) {
      if (q && !(String(o.orderId).toLowerCase().indexOf(q) >= 0 || String(o.customerName || '').toLowerCase().indexOf(q) >= 0 || (qd.length >= 3 && String(o.phone || '').indexOf(qd) >= 0))) return false;
      if (OF.status && !(o.orderStatus === OF.status || (OF.status === 'SHIPPED' && o.orderStatus === 'OUT_FOR_DELIVERY' && OF.statusGroup))) return false;
      if (OF.pay && o.paymentStatus !== OF.pay) return false;
      if (OF.method && o.paymentMethod !== OF.method) return false;
      return dateOk(o);
    });
  }
  function opts(list, cur, all) { return '<option value="">' + all + '</option>' + list.map(function (v) { return '<option value="' + v + '"' + (v === cur ? ' selected' : '') + '>' + esc(U.label(v)) + '</option>'; }).join(''); }
  function csv(list) {
    var rows = [['Order ID', 'Date', 'Customer', 'Mobile', 'Email', 'Address', 'Items', 'Subtotal', 'Shipping', 'Discount', 'Total', 'Method', 'Payment status', 'Order status']];
    list.forEach(function (o) { rows.push([o.orderId, fmtDate(o.createdAt, true), o.customerName, o.phone, o.email || '', addrText(o.address), o.products.map(function (i) { return i.name + ' x' + i.qty; }).join('; '), o.subtotal, o.shipping, o.discount, o.total, o.paymentMethod, o.paymentStatus, o.orderStatus]); });
    return rows.map(function (r) { return r.map(function (c) { c = String(c == null ? '' : c); return /[",\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c; }).join(','); }).join('\n');
  }
  VIEWS.orders = {
    render: function (param) {
      if (param) return VIEWS.order.render(param);
      var q = qs();
      if (q.status != null && q.status !== OF._lastQ) { OF.status = q.status; OF.statusGroup = q.status === 'SHIPPED'; OF._lastQ = q.status; }
      var list = filteredOrders();
      return '<div class="page-head"><div><h2>Orders</h2><p class="sub">Every order placed on the website, newest first.</p></div><div class="actions"><button type="button" class="btn" id="csv-btn">' + ico('download') + 'Export CSV</button></div></div>' +
        '<section class="card">' +
          '<div class="toolbar">' +
            '<label class="search"><span class="sr-only">Search orders</span>' + ico('search') + '<input class="in" id="of-q" type="search" placeholder="Search order ID, name or mobile" value="' + esc(OF.q) + '"></label>' +
            '<div class="filters">' +
              '<select class="sel" id="of-date" aria-label="Date"><option value="all">Any date</option><option value="today">Today</option><option value="yesterday">Yesterday</option><option value="7">Last 7 days</option><option value="30">Last 30 days</option><option value="month">This month</option><option value="custom">Custom dates\u2026</option></select>' +
              '<select class="sel" id="of-status" aria-label="Order status">' + opts(U.ORDER_STATUSES, OF.status, 'All order status') + '</select>' +
              '<select class="sel" id="of-pay" aria-label="Payment status">' + opts(U.PAYMENT_STATUSES, OF.pay, 'All payment status') + '</select>' +
              '<select class="sel" id="of-method" aria-label="Payment method"><option value="">UPI &amp; COD</option><option value="UPI"' + (OF.method === 'UPI' ? ' selected' : '') + '>UPI</option><option value="COD"' + (OF.method === 'COD' ? ' selected' : '') + '>COD</option></select>' +
              '<div class="date-range" id="of-range"' + (OF.date === 'custom' ? '' : ' hidden') + '><input class="in" type="date" id="of-from" aria-label="From date" value="' + esc(OF.from) + '"><input class="in" type="date" id="of-to" aria-label="To date" value="' + esc(OF.to) + '"></div>' +
            '</div>' +
          '</div>' +
          '<div class="result-count"><span>' + list.length + ' of ' + S.orders.length + ' orders \u00B7 ' + money(list.filter(isSale).reduce(function (a, o) { return a + o.total; }, 0)) + '</span>' + ((OF.q || OF.status || OF.pay || OF.method || OF.date !== 'all') ? '<button type="button" class="link" id="of-clear">Clear filters</button>' : '') + '</div>' +
          (S.loaded.orders ? ordersTable(list, S.orders.length ? { emptyTitle: 'No matching orders', emptyText: 'Try a different search or filter.' } : null) : '<div class="empty">Loading\u2026</div>') +
        '</section>';
    },
    mount: function (view, param) {
      if (param) return VIEWS.order.mount(view, param);
      $('#of-date').value = OF.date;
      var rerender = function () { var y = window.scrollY; var f = document.activeElement && document.activeElement.id; renderView(); window.scrollTo(0, y); if (f && document.getElementById(f)) { var el = document.getElementById(f); el.focus(); if (el.setSelectionRange && el.type === 'search') el.setSelectionRange(el.value.length, el.value.length); } };
      $('#of-q').addEventListener('input', debounce(function () { OF.q = this.value; rerender(); }, 200));
      $('#of-date').addEventListener('change', function () { OF.date = this.value; rerender(); });
      $('#of-status').addEventListener('change', function () { OF.status = this.value; OF.statusGroup = false; rerender(); });
      $('#of-pay').addEventListener('change', function () { OF.pay = this.value; rerender(); });
      $('#of-method').addEventListener('change', function () { OF.method = this.value; rerender(); });
      $('#of-from').addEventListener('change', function () { OF.from = this.value; rerender(); });
      $('#of-to').addEventListener('change', function () { OF.to = this.value; rerender(); });
      var c = $('#of-clear'); if (c) c.addEventListener('click', function () { OF.q = ''; OF.date = 'all'; OF.status = ''; OF.pay = ''; OF.method = ''; OF.from = OF.to = ''; if (location.hash.indexOf('?') > 0) location.hash = '#/orders'; else rerender(); });
      $('#csv-btn').addEventListener('click', function () {
        var blob = new Blob(['\ufeff' + csv(filteredOrders())], { type: 'text/csv;charset=utf-8' });
        var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'vexacollection-orders-' + istDay(new Date()) + '.csv'; document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
      });
    }
  };

  /* =========================================================
     ORDER DETAILS
     ========================================================= */
  var FLOW = ['NEW', 'CONFIRMED', 'PROCESSING', 'SHIPPED', 'OUT_FOR_DELIVERY', 'DELIVERED'];
  function statusMsg(o) {
    var name = (o.customerName || '').split(' ')[0] || 'there';
    var brand = S.settings.brandName || 'VEXACOLLECTION';
    var m = {
      NEW: 'we have received your order ' + o.orderId + ' (' + money(o.total) + ').',
      CONFIRMED: 'your order ' + o.orderId + ' is confirmed. We are getting it ready.',
      PROCESSING: 'your order ' + o.orderId + ' is being packed.',
      SHIPPED: 'your order ' + o.orderId + ' has been shipped.',
      OUT_FOR_DELIVERY: 'your order ' + o.orderId + ' is out for delivery today.',
      DELIVERED: 'your order ' + o.orderId + ' has been delivered. Thank you for shopping with us!',
      CANCELLED: 'your order ' + o.orderId + ' has been cancelled. Please reply if you have any questions.'
    }[o.orderStatus] || ('an update on your order ' + o.orderId + '.');
    var pay = o.paymentMethod === 'UPI' && o.paymentStatus === 'PENDING' ? ' We are checking your UPI payment of ' + money(o.total) + '.' : o.paymentStatus === 'PAID' && o.paymentMethod === 'UPI' ? ' Your payment of ' + money(o.total) + ' is received.' : '';
    return 'Hi ' + name + ', ' + m + pay + ' \u2014 ' + brand;
  }
  VIEWS.order = {
    render: function (id) {
      if (!S.loaded.orders) return loadingCard();
      var o = orderById(id);
      if (!o) return '<a class="back" href="#/orders">' + ico('arrowl') + 'All orders</a><div class="card"><div class="empty">' + ico('orders') + '<strong>Order not found</strong>' + esc(id) + '</div></div>';
      var cancelled = o.orderStatus === 'CANCELLED';
      var idx = FLOW.indexOf(o.orderStatus);
      var steps = '<div class="steps' + (cancelled ? ' is-cancelled' : '') + '">' + FLOW.map(function (s, i) {
        return '<div class="step' + (i <= idx ? ' done' : '') + (i === idx ? ' current' : '') + '"><span class="dot">' + (i <= idx ? '\u2713' : i + 1) + '</span>' + esc(U.label(s)) + '</div>';
      }).join('') + '</div>';
      var items = o.products.map(function (it) {
        var p = productById(it.id);
        var src = it.image || (p && p.image) || '';
        return '<div class="item"><img class="thumb" src="' + esc(img(src)) + '" alt=""><div><div class="nm">' + esc(it.name) + '</div><div class="q">' + money(it.price) + ' \u00D7 ' + it.qty + (p ? ' \u00B7 SKU ' + esc(p.sku || p.id) : '') + '</div></div><div class="amt">' + money(it.price * it.qty) + '</div></div>';
      }).join('');
      var a = o.address || {};
      var upiPending = o.paymentMethod === 'UPI' && o.paymentStatus === 'PENDING' && !cancelled;
      var hist = (o.statusHistory || []).map(function (h) { return { t: h.at, s: 'Order ' + U.label(h.status).toLowerCase() }; })
        .concat((o.paymentHistory || []).map(function (h) { return { t: h.at, s: 'Payment marked ' + U.label(h.status).toLowerCase() + (h.by ? ' by ' + h.by : '') }; }))
        .sort(function (x, y) { return String(y.t).localeCompare(String(x.t)); });
      return '<a class="back" href="#/orders">' + ico('arrowl') + 'All orders</a>' +
        '<div class="od-head"><h2>' + esc(o.orderId) + '</h2>' + oPill(o.orderStatus) + pPill(o.paymentStatus) + '</div>' +
        '<p class="od-meta">Placed ' + fmtDate(o.createdAt, true) + ' IST \u00B7 ' + esc(o.paymentMethod === 'COD' ? 'Cash on Delivery' : 'UPI') + (o.source ? ' \u00B7 via ' + esc(o.source) : '') + '</p>' +
        '<div class="od-grid"><div class="stack">' +
          '<section class="card">' + steps + (cancelled ? '<div class="callout callout-bad" style="margin:0 16px 16px">' + ico('ban') + '<div class="grow">This order is cancelled.' + (o.stockRestored ? ' Its stock has been added back to inventory.' : '') + '</div></div>' : '') + '</section>' +
          '<section class="card"><div class="card-head"><h3>Products (' + o.products.reduce(function (n, i) { return n + i.qty; }, 0) + ')</h3></div><div class="items">' + items + '</div>' +
            '<div class="card-pad" style="border-top:1px solid var(--line)"><dl class="kv">' +
              '<div><dt>Subtotal</dt><dd>' + money(o.subtotal) + '</dd></div>' +
              '<div><dt>Shipping</dt><dd>' + (o.shipping ? money(o.shipping) : 'Free') + '</dd></div>' +
              '<div class="disc"><dt>Discount' + (o.couponCode ? ' (' + esc(o.couponCode) + ')' : '') + '</dt><dd>' + (o.discount ? '&minus;' + money(o.discount) : money(0)) + '</dd></div>' +
              '<div class="grand"><dt>Grand total</dt><dd>' + money(o.total) + '</dd></div>' +
            '</dl></div></section>' +
          '<div class="grid2" style="gap:20px">' +
            '<section class="card card-pad"><p class="sec-title">Customer</p><dl class="kv">' +
              '<div><dt>Name</dt><dd>' + esc(o.customerName) + '</dd></div>' +
              '<div><dt>Mobile</dt><dd class="mono">' + esc(fmtPhone(o.phone)) + '</dd></div>' +
              '<div><dt>Email</dt><dd>' + (o.email ? esc(o.email) : '\u2014') + '</dd></div>' +
              '<div><dt>Account</dt><dd>Guest</dd></div></dl>' +
              '<div class="contact-row"><a class="btn btn-wa btn-sm" target="_blank" rel="noopener" href="' + esc(waLink(o.phone, statusMsg(o))) + '">' + ico('wa') + 'WhatsApp</a><a class="btn btn-sm" href="' + esc(telLink(o.phone)) + '">' + ico('phone') + 'Call</a>' + (U.normPhone(o.phone) ? '<a class="btn btn-sm" href="#/customers/' + encodeURIComponent(U.normPhone(o.phone)) + '">History</a>' : '') + '</div>' +
            '</section>' +
            '<section class="card card-pad"><p class="sec-title">Delivery address' + (a.type ? ' \u00B7 ' + esc(a.type) : '') + '</p><address class="addr">' + esc(a.name || o.customerName) + '<br>' + esc(a.house || '') + (a.street ? '<br>' + esc(a.street) : '') + (a.landmark ? '<br>Near ' + esc(String(a.landmark).replace(/^near\s+/i, '')) : '') + '<br>' + esc([a.city, a.state].filter(Boolean).join(', ')) + (a.pin ? ' &ndash; <strong>' + esc(a.pin) + '</strong>' : '') + (typeof o.address === 'string' ? esc(o.address) : '') + '</address>' +
              '<div class="contact-row"><button type="button" class="btn btn-sm" data-copy="' + esc((a.name || o.customerName) + ', ' + addrText(a) + ', ' + fmtPhone(o.phone)) + '">Copy address</button></div></section>' +
          '</div>' +
          (hist.length ? '<section class="card card-pad"><p class="sec-title">History</p><div class="timeline"><ul>' + hist.map(function (h) { return '<li><span class="tdot"></span><div><div>' + esc(h.s) + '</div><div class="small muted">' + fmtDate(h.t, true) + '</div></div></li>'; }).join('') + '</ul></div></section>' : '') +
        '</div>' +
        '<div class="sticky-side">' +
          (upiPending ? '<div class="verify-box"><h4>Verify UPI payment</h4>This customer chose UPI. The website cannot see your bank, so the payment is <strong>not verified yet</strong>.<ol><li>Open your UPI app (paid to <strong>' + esc(o.upiId || S.settings.upiId) + '</strong>).</li><li>Find <strong>' + money(o.total) + '</strong>' + ' with note &ldquo;Order ' + esc(o.orderId) + '&rdquo;' + (o.upiTransactionRef ? ' or UTR <strong class="mono">' + esc(o.upiTransactionRef) + '</strong>' : '') + '.</li><li>Only if the money is there, mark it paid.</li></ol><button type="button" class="btn btn-ok btn-block" id="mark-paid">' + ico('check') + 'Mark as Paid (manually verified)</button></div>' : '') +
          '<section class="card card-pad" id="update-card"><p class="sec-title">Update order</p>' +
            '<div class="f"><label for="u-status">Order status</label><select class="sel" id="u-status">' + U.ORDER_STATUSES.map(function (s) { return '<option value="' + s + '"' + (s === o.orderStatus ? ' selected' : '') + '>' + esc(U.label(s)) + '</option>'; }).join('') + '</select></div>' +
            '<div class="f"><label for="u-pay">Payment status</label><select class="sel" id="u-pay">' + U.PAYMENT_STATUSES.map(function (s) { return '<option value="' + s + '"' + (s === o.paymentStatus ? ' selected' : '') + '>' + esc(U.label(s)) + '</option>'; }).join('') + '</select><span class="hint">Payment: ' + esc(o.paymentMethod) + (o.upiTransactionRef ? ' \u00B7 UTR ' + esc(o.upiTransactionRef) : '') + (o.paymentVerifiedBy ? ' \u00B7 verified by ' + esc(o.paymentVerifiedBy) : '') + '</span></div>' +
            '<div class="f"><label for="u-note">Private note <span class="muted">(only admins see this)</span></label><textarea class="ta" id="u-note" rows="2" placeholder="e.g. courier name, tracking number">' + esc(o.adminNote || '') + '</textarea></div>' +
            '<button type="button" class="btn btn-dark btn-block btn-lg" id="u-save">Update order</button>' +
          '</section>' +
          '<section class="card card-pad"><p class="sec-title">Invoice &amp; contact</p><div class="btn-row">' +
            '<button type="button" class="btn" data-invoice="print">' + ico('print') + 'Print invoice</button>' +
            '<button type="button" class="btn" data-invoice="pdf">' + ico('download') + 'Download invoice</button>' +
            '<a class="btn btn-wa" target="_blank" rel="noopener" href="' + esc(waLink(o.phone, statusMsg(o))) + '">' + ico('wa') + 'Contact customer</a>' +
          '</div><p class="hint small muted mt">Download opens the print window &mdash; choose &ldquo;Save as PDF&rdquo;. The WhatsApp message is pre-written with the current status.</p></section>' +
        '</div></div>';
    },
    mount: function (view, id) {
      var o = orderById(id); if (!o) return;
      var card = $('#update-card');
      ['#u-status', '#u-pay', '#u-note'].forEach(function (s) { $(s).addEventListener('input', function () { card.setAttribute('data-dirty', '1'); }); $(s).addEventListener('change', function () { card.setAttribute('data-dirty', '1'); }); });
      function save(patch, okMsg) {
        var btn = $('#u-save'); btn.disabled = true; btn.textContent = 'Saving\u2026';
        return A.updateOrder(o.orderId, patch).then(function () {
          card.removeAttribute('data-dirty');
          toast(okMsg || 'Order ' + esc(o.orderId) + ' updated');
          renderView();
        }).catch(function (e) { btn.disabled = false; btn.textContent = 'Update order'; toast(errMsg(e), { bad: true }); });
      }
      $('#u-save').addEventListener('click', function () {
        var st = $('#u-status').value, ps = $('#u-pay').value, note = $('#u-note').value;
        var checks = Promise.resolve(true);
        if (st === 'CANCELLED' && o.orderStatus !== 'CANCELLED') checks = checks.then(function (ok) { return ok && confirmBox('Cancel this order?', 'Order ' + esc(o.orderId) + ' will be cancelled and its ' + o.products.reduce(function (n, i) { return n + i.qty; }, 0) + ' item(s) will be added back to stock.', 'Cancel order', true); });
        if (o.orderStatus === 'CANCELLED' && st !== 'CANCELLED') checks = checks.then(function (ok) { return ok && confirmBox('Re-open this order?', 'The items will be taken out of stock again.', 'Re-open order'); });
        if (ps === 'PAID' && o.paymentStatus !== 'PAID' && o.paymentMethod === 'UPI') checks = checks.then(function (ok) { return ok && confirmBox('Mark as paid?', 'Only do this after you have checked that <strong>' + money(o.total) + '</strong> reached your UPI account. This is a manual check \u2014 the website cannot verify payments.', 'Yes, I checked \u2014 mark paid'); });
        checks.then(function (ok) { if (ok) save({ orderStatus: st, paymentStatus: ps, adminNote: note }); });
      });
      var mp = $('#mark-paid');
      if (mp) mp.addEventListener('click', function () {
        confirmBox('Mark as Paid (manually verified)?', 'Confirm you saw <strong>' + money(o.total) + '</strong> for order <strong>' + esc(o.orderId) + '</strong> in your UPI app. The order will also move to Confirmed if it is still New.', 'Yes, payment received').then(function (ok) {
          if (ok) save({ paymentStatus: 'PAID', orderStatus: o.orderStatus === 'NEW' ? 'CONFIRMED' : o.orderStatus }, 'Payment marked as paid (manually verified)');
        });
      });
      $$('[data-invoice]', view).forEach(function (b) { b.addEventListener('click', function () { printInvoice(o, b.getAttribute('data-invoice') === 'pdf'); }); });
    }
  };
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]'); if (!b) return;
    var t = b.getAttribute('data-copy');
    (navigator.clipboard ? navigator.clipboard.writeText(t) : Promise.reject()).then(function () { toast('Copied'); }, function () { toast('Could not copy', { bad: true }); });
  });

  /* =========================================================
     INVOICE (print / save as PDF)
     ========================================================= */
  function invoiceHtml(o) {
    var s = S.settings, a = o.address || {};
    var rows = o.products.map(function (it, i) { return '<tr><td>' + (i + 1) + '</td><td>' + esc(it.name) + '</td><td class="num">' + it.qty + '</td><td class="num">' + money(it.price) + '</td><td class="num">' + money(it.price * it.qty) + '</td></tr>'; }).join('');
    return '<div class="inv">' +
      '<div class="inv-top"><div><img src="../images/logo.svg" alt="' + esc(s.brandName) + '"><div>' + esc(s.address) + '<br>Phone: ' + esc(fmtPhone(s.phone)) + (s.email ? '<br>' + esc(s.email) : '') + '</div></div>' +
      '<div class="r"><h1>Invoice</h1><div style="margin-top:10px">Order ID: <strong>' + esc(o.orderId) + '</strong><br>Order date: ' + fmtDate(o.createdAt, true) + '<br>Invoice date: ' + fmtDate(new Date().toISOString()) + '</div></div></div>' +
      '<div class="inv-sec"><div><h4>Customer details</h4><strong>' + esc(o.customerName) + '</strong><br>' + esc(fmtPhone(o.phone)) + (o.email ? '<br>' + esc(o.email) : '') + '</div>' +
      '<div><h4>Delivery address</h4>' + esc(a.name || o.customerName) + '<br>' + esc(addrText(a)) + '</div></div>' +
      '<table><thead><tr><th>#</th><th>Product</th><th class="num">Qty</th><th class="num">Price</th><th class="num">Subtotal</th></tr></thead><tbody>' + rows + '</tbody></table>' +
      '<div class="inv-tot"><div><span>Subtotal</span><span>' + money(o.subtotal) + '</span></div><div><span>Shipping</span><span>' + (o.shipping ? money(o.shipping) : 'Free') + '</span></div><div><span>Discount' + (o.couponCode ? ' (' + esc(o.couponCode) + ')' : '') + '</span><span>' + (o.discount ? '&minus;' : '') + money(o.discount) + '</span></div><div class="g"><span>Grand total</span><span>' + money(o.total) + '</span></div></div>' +
      '<div class="inv-sec" style="border-bottom:0"><div><h4>Payment method</h4>' + (o.paymentMethod === 'COD' ? 'Cash on Delivery' : 'UPI' + (o.upiId ? ' (' + esc(o.upiId) + ')' : '')) + (o.upiTransactionRef ? '<br>UTR: ' + esc(o.upiTransactionRef) : '') + '</div>' +
      '<div><h4>Payment status</h4>' + (o.paymentStatus === 'PENDING' ? 'PAYMENT VERIFICATION PENDING' : o.paymentStatus === 'COD' ? 'COD \u2014 PAY ON DELIVERY' : esc(U.label(o.paymentStatus).toUpperCase())) + '<br><span style="color:#666">Order status: ' + esc(U.label(o.orderStatus)) + '</span></div></div>' +
      '<div class="inv-foot">Thank you for shopping with ' + esc(s.brandName) + '. ' + (o.paymentStatus === 'PAID' ? 'Payment received.' : o.paymentMethod === 'COD' ? 'Amount payable in cash on delivery.' : 'This invoice is not a payment receipt until the UPI payment is verified by the store.') + '</div>' +
    '</div>';
  }
  function printInvoice(o, asPdf) {
    $('#print-root').innerHTML = invoiceHtml(o);
    var oldTitle = document.title;
    document.title = 'Invoice-' + o.orderId;   // becomes the PDF file name
    document.body.classList.add('printing');
    if (asPdf) toast('In the print window choose <strong>Save as PDF</strong>', { icon: 'info', ms: 6000 });
    var im = $('#print-root img');
    var go = function () {
      setTimeout(function () {
        window.print();
        setTimeout(function () { document.body.classList.remove('printing'); document.title = oldTitle; }, 500);
      }, 150);
    };
    if (im && !im.complete) { im.onload = go; im.onerror = go; } else go();
  }

  /* =========================================================
     PRODUCTS
     ========================================================= */
  var PF = { q: '', cat: '', status: '' };
  function catLabel(id) { var c = U.CATEGORIES.filter(function (x) { return x.id === id; })[0]; return c ? c.label : (id || 'Other'); }
  function invState(p) { if (p.status === 'HIDDEN') return 'hidden'; var a = U.availability(p); if (a === 'out') return 'out'; return num(p.stock) <= 3 ? 'low' : 'in'; }
  function invPill(p) { var s = invState(p); return '<span class="pill i-' + s + '">' + ({ hidden: 'Hidden', out: 'Out of stock', low: 'Low stock', 'in': 'In stock' })[s] + '</span>'; }
  VIEWS.products = {
    render: function (param) {
      if (param === 'new' || /^edit\//.test(param || '')) return VIEWS.productForm.render(param);
      var q = PF.q.trim().toLowerCase();
      var list = S.products.filter(function (p) {
        if (q && (p.name + ' ' + (p.sku || '') + ' ' + p.id).toLowerCase().indexOf(q) < 0) return false;
        if (PF.cat && p.category !== PF.cat) return false;
        if (PF.status && !(PF.status === p.status || (PF.status === 'OUT' && invState(p) === 'out'))) return false;
        return true;
      });
      var body;
      if (!S.loaded.products) body = loadingCard();
      else if (!S.products.length) body = '<div class="card"><div class="empty">' + ico('products') + '<strong>No products yet</strong>Add your first product, or import the 8 products that are on the website now.<div class="btn-row" style="max-width:420px;margin:16px auto 0"><button type="button" class="btn btn-gold" data-import>' + ico('upload') + 'Import sample products</button><a class="btn btn-dark" href="#/products/new">' + ico('plus') + 'Add product</a></div></div></div>';
      else if (!list.length) body = '<div class="card"><div class="empty"><strong>No matching products</strong>Try another search.</div></div>';
      else body = '<div class="prod-grid">' + list.map(function (p) {
        var hidden = p.status === 'HIDDEN';
        var flags = (p.featured ? '<span class="flag">Featured</span>' : '') + (p.bestSeller ? '<span class="flag">Best seller</span>' : '') + (p.newArrival ? '<span class="flag">New</span>' : '');
        return '<article class="pcard' + (hidden ? ' is-hidden' : '') + '">' +
          '<a class="pcard-media" href="#/products/edit/' + encodeURIComponent(p.id) + '" aria-label="Edit ' + esc(p.name) + '"><img src="' + esc(img(p.image)) + '" alt="" loading="lazy">' + invPill(p) + '<span class="pcard-flags">' + flags + '</span></a>' +
          '<div class="pcard-body"><div class="nm">' + esc(p.name) + '</div><div class="meta">' + esc(catLabel(p.category)) + ' \u00B7 ' + esc(p.sku || p.id) + ' \u00B7 Stock ' + num(p.stock) + '</div>' +
          '<div class="pr">' + money(p.price) + (p.oldPrice > p.price ? '<s>' + money(p.oldPrice) + '</s>' : '') + '</div>' +
          '<label class="toggle"><input type="checkbox" data-toggle-product="' + esc(p.id) + '"' + (hidden ? '' : ' checked') + '><span class="tr"></span><span>' + (hidden ? 'Disabled (hidden)' : 'Enabled on website') + '</span></label></div>' +
          '<div class="pcard-actions"><a class="btn" href="#/products/edit/' + encodeURIComponent(p.id) + '">' + ico('edit') + 'Edit</a><a class="btn" href="#/inventory">Stock</a><button type="button" class="iconbtn btn-danger" data-del-product="' + esc(p.id) + '" aria-label="Delete ' + esc(p.name) + '" style="border:1px solid #f0c4bf">' + ico('trash') + '</button></div>' +
        '</article>';
      }).join('') + '</div>';
      return '<div class="page-head"><div><h2>Products</h2><p class="sub">' + S.products.length + ' products \u00B7 changes show on the website right away.</p></div><div class="actions">' + (S.products.length ? '<button type="button" class="btn" data-import>' + ico('upload') + 'Import sample products</button>' : '') + '<a class="btn btn-dark" href="#/products/new">' + ico('plus') + 'Add product</a></div></div>' +
        (S.products.length ? '<section class="card" style="margin-bottom:18px"><div class="toolbar"><label class="search"><span class="sr-only">Search products</span>' + ico('search') + '<input class="in" id="pf-q" type="search" placeholder="Search name or SKU" value="' + esc(PF.q) + '"></label>' +
          '<div class="filters"><select class="sel" id="pf-cat" aria-label="Category"><option value="">All categories</option>' + U.CATEGORIES.map(function (c) { return '<option value="' + c.id + '"' + (PF.cat === c.id ? ' selected' : '') + '>' + esc(c.label) + '</option>'; }).join('') + '</select>' +
          '<select class="sel" id="pf-status" aria-label="Status"><option value="">All status</option><option value="ACTIVE"' + (PF.status === 'ACTIVE' ? ' selected' : '') + '>Active</option><option value="OUT"' + (PF.status === 'OUT' ? ' selected' : '') + '>Out of stock</option><option value="HIDDEN"' + (PF.status === 'HIDDEN' ? ' selected' : '') + '>Hidden</option></select></div></div></section>' : '') +
        body;
    },
    mount: function (view, param) {
      if (param === 'new' || /^edit\//.test(param || '')) return VIEWS.productForm.mount(view, param);
      var rr = function () { var f = document.activeElement && document.activeElement.id; renderView(); if (f && document.getElementById(f)) { var el = document.getElementById(f); el.focus(); if (el.type === 'search') el.setSelectionRange(el.value.length, el.value.length); } };
      var q = $('#pf-q'); if (q) q.addEventListener('input', debounce(function () { PF.q = this.value; rr(); }, 200));
      var c = $('#pf-cat'); if (c) c.addEventListener('change', function () { PF.cat = this.value; rr(); });
      var s = $('#pf-status'); if (s) s.addEventListener('change', function () { PF.status = this.value; rr(); });
    }
  };
  document.addEventListener('change', function (e) {
    var t = e.target.closest('[data-toggle-product]'); if (!t) return;
    var p = productById(t.getAttribute('data-toggle-product')); if (!p) return;
    var next = t.checked ? (num(p.stock) > 0 ? 'ACTIVE' : 'OUT_OF_STOCK') : 'HIDDEN';
    A.updateProduct(p.id, { status: next }).then(function () { toast(esc(p.name) + (next === 'HIDDEN' ? ' hidden from the website' : ' is live on the website')); }, function (er) { t.checked = !t.checked; toast(errMsg(er), { bad: true }); });
  });
  document.addEventListener('click', function (e) {
    var d = e.target.closest('[data-del-product]');
    if (d) {
      var p = productById(d.getAttribute('data-del-product')); if (!p) return;
      confirmBox('Delete product?', '<strong>' + esc(p.name) + '</strong> will be removed from the website. Past orders keep their details. Tip: use the Enabled switch to hide it instead.', 'Delete', true).then(function (ok) {
        if (ok) A.deleteProduct(p.id).then(function () { toast('Product deleted'); if (/^#\/products\/edit/.test(location.hash)) location.hash = '#/products'; }, function (er) { toast(errMsg(er), { bad: true }); });
      });
    }
    var im = e.target.closest('[data-import]');
    if (im) {
      confirmBox('Import sample products?', 'Adds the 8 products from the original website (photos, names, prices, stock 20 each). Products that already exist are not changed.', 'Import').then(function (ok) {
        if (!ok) return;
        A.importSampleProducts(false).then(function (n) { toast(n ? n + ' products imported' : 'All sample products already exist'); }, function (er) { toast(errMsg(er), { bad: true }); });
      });
    }
  });

  /* ---------------- image helpers ---------------- */
  function compressImage(file, maxSide, quality) {
    return new Promise(function (resolve, reject) {
      if (!/^image\//.test(file.type)) return reject(new Error('Please choose a photo (JPG, PNG or WebP).'));
      var url = URL.createObjectURL(file), im = new Image();
      im.onload = function () {
        var w = im.naturalWidth, h = im.naturalHeight, k = Math.min(1, maxSide / Math.max(w, h));
        var c = document.createElement('canvas'); c.width = Math.round(w * k); c.height = Math.round(h * k);
        var g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height); g.drawImage(im, 0, 0, c.width, c.height);
        URL.revokeObjectURL(url);
        var q = quality, data = c.toDataURL('image/jpeg', q);
        while (data.length > 260000 && q > 0.45) { q -= 0.1; data = c.toDataURL('image/jpeg', q); }
        c.toBlob(function (blob) { resolve({ dataUrl: data, blob: blob }); }, 'image/jpeg', q);
      };
      im.onerror = function () { URL.revokeObjectURL(url); reject(new Error('Could not read this photo.')); };
      im.src = url;
    });
  }
  // Firebase Storage when switched on, otherwise a compressed photo saved inside the product
  function storeImage(file, maxSide) {
    return compressImage(file, maxSide, 0.82).then(function (r) {
      if (A.uploadImage) return A.uploadImage(r.blob, file.name).catch(function () { return r.dataUrl; });
      return r.dataUrl;
    });
  }

  /* =========================================================
     ADD / EDIT PRODUCT
     ========================================================= */
  var draft = null;
  VIEWS.productForm = {
    render: function (param) {
      var editing = /^edit\//.test(param);
      var id = editing ? param.slice(5) : '';
      if (editing && !S.loaded.products) return loadingCard();
      var p = editing ? productById(id) : null;
      if (editing && !p) return '<a class="back" href="#/products">' + ico('arrowl') + 'Products</a><div class="card"><div class="empty"><strong>Product not found</strong></div></div>';
      if (!draft || draft._key !== param) draft = Object.assign({ _key: param, images: [] }, p ? JSON.parse(JSON.stringify(p)) : { name: '', category: '', description: '', price: '', oldPrice: '', discount: '', stock: '', image: '', images: [], featured: false, bestSeller: false, newArrival: true, status: 'ACTIVE', sku: '' });
      var d = draft;
      function v(x) { return x == null || x === 0 && d._blankZero ? '' : esc(x); }
      return '<a class="back" href="#/products">' + ico('arrowl') + 'Products</a>' +
        '<div class="page-head"><div><h2>' + (editing ? 'Edit product' : 'Add product') + '</h2><p class="sub">Fields marked <span style="color:var(--bad)">*</span> are required. Saved products appear on the website automatically.</p></div></div>' +
        '<form id="pform" novalidate><div class="form-grid"><div class="stack">' +
          '<section class="card card-pad"><p class="sec-title">Details</p>' +
            '<div class="f"><label for="p-name">Product name <span class="req">*</span></label><input class="in" id="p-name" maxlength="80" value="' + esc(d.name) + '" required><span class="err" id="e-name"></span></div>' +
            '<div class="grid2"><div class="f"><label for="p-cat">Category <span class="req">*</span></label><select class="sel" id="p-cat" required><option value="">Choose\u2026</option>' + U.CATEGORIES.map(function (c) { return '<option value="' + c.id + '"' + (d.category === c.id ? ' selected' : '') + '>' + esc(c.label) + '</option>'; }).join('') + '</select><span class="err" id="e-cat"></span></div>' +
            '<div class="f"><label for="p-sku">Product ID / SKU</label><input class="in" id="p-sku" maxlength="30" value="' + esc(d.sku || '') + '" placeholder="' + (editing ? '' : 'Auto') + '"' + (editing ? '' : '') + '><span class="hint">' + (editing ? 'ID: ' + esc(d.id) : 'Left empty = created automatically') + '</span></div></div>' +
            '<div class="f"><label for="p-desc">Description</label><textarea class="ta" id="p-desc" maxlength="1000" placeholder="Fabric, fit, sizes, care\u2026">' + esc(d.description || '') + '</textarea></div>' +
          '</section>' +
          '<section class="card card-pad"><p class="sec-title">Price &amp; stock</p>' +
            '<div class="grid2">' +
              '<div class="f"><label for="p-price">Price <span class="req">*</span></label><div class="prefix"><span>\u20B9</span><input class="in" id="p-price" type="number" inputmode="decimal" min="1" step="1" value="' + esc(d.price) + '" required></div><span class="err" id="e-price"></span></div>' +
              '<div class="f"><label for="p-old">Old price (MRP)</label><div class="prefix"><span>\u20B9</span><input class="in" id="p-old" type="number" inputmode="decimal" min="0" step="1" value="' + esc(d.oldPrice || '') + '"></div><span class="hint">Shown crossed out if higher than price</span></div>' +
              '<div class="f"><label for="p-disc">Discount %</label><input class="in" id="p-disc" type="number" inputmode="numeric" min="0" max="95" step="1" value="' + esc(d.discount || '') + '"><span class="hint" id="h-disc">Worked out from old price, or type your own</span></div>' +
              '<div class="f"><label for="p-stock">Stock quantity <span class="req">*</span></label><input class="in" id="p-stock" type="number" inputmode="numeric" min="0" step="1" value="' + esc(d.stock) + '" required><span class="err" id="e-stock"></span></div>' +
            '</div>' +
          '</section>' +
          '<section class="card card-pad"><p class="sec-title">Show on website</p>' +
            '<div class="opt-row">' +
              '<label class="check"><input type="checkbox" id="p-feat"' + (d.featured ? ' checked' : '') + '> Featured product</label>' +
              '<label class="check"><input type="checkbox" id="p-best"' + (d.bestSeller ? ' checked' : '') + '> Best seller</label>' +
              '<label class="check"><input type="checkbox" id="p-new"' + (d.newArrival ? ' checked' : '') + '> New arrival</label>' +
            '</div>' +
            '<div class="f mt"><label for="p-status">Product status</label><select class="sel" id="p-status"><option value="ACTIVE"' + (d.status === 'ACTIVE' ? ' selected' : '') + '>Active (on sale)</option><option value="OUT_OF_STOCK"' + (d.status === 'OUT_OF_STOCK' ? ' selected' : '') + '>Out of stock (shown, can&rsquo;t be bought)</option><option value="HIDDEN"' + (d.status === 'HIDDEN' ? ' selected' : '') + '>Hidden (not shown)</option></select><span class="hint">Stock 0 shows &ldquo;Out of stock&rdquo; automatically.</span></div>' +
          '</section>' +
        '</div>' +
        '<div class="stack">' +
          '<section class="card card-pad"><p class="sec-title">Product image <span class="req">*</span></p>' +
            '<label class="img-drop" id="main-drop">' + (d.image ? '<img src="' + esc(img(d.image)) + '" alt="">' : '<span class="ph">' + ico('image') + '<span>Tap to add photo<br><small>Portrait photo works best (4:5)</small></span></span>') + '<input type="file" id="p-img" accept="image/*" aria-label="Choose product photo"></label>' +
            '<span class="err" id="e-img"></span>' +
            '<div class="f mt"><label for="p-imgurl">or paste image link</label><input class="in" id="p-imgurl" type="url" placeholder="https://\u2026" value="' + (/^data:/.test(d.image || '') ? '' : esc(d.image || '')) + '"></div>' +
            '<p class="sec-title" style="margin-top:8px">Additional images <span class="muted" style="letter-spacing:0;text-transform:none;font-weight:400">(up to 4)</span></p>' +
            '<div class="extra-imgs" id="extra-imgs">' + (d.images || []).map(function (s, i) { return '<div class="xi"><img src="' + esc(img(s)) + '" alt=""><button type="button" data-rm-img="' + i + '" aria-label="Remove image">\u00D7</button></div>'; }).join('') +
              ((d.images || []).length < 4 ? '<label class="xi-add" aria-label="Add image">+<input type="file" id="p-imgs" accept="image/*" multiple></label>' : '') + '</div>' +
            (Store.mode === 'firebase' && !A.uploadImage ? '<p class="hint small muted mt">Photos are compressed and saved with the product (free plan). Use clear photos under 5 MB.</p>' : '') +
          '</section>' +
        '</div></div>' +
        '<div class="save-bar">' + (editing ? '<button type="button" class="btn btn-danger" data-del-product="' + esc(d.id) + '">Delete</button>' : '<a class="btn" href="#/products">Cancel</a>') + '<button type="submit" class="btn btn-dark btn-lg" id="p-save">Save product</button></div>' +
        '</form>';
    },
    mount: function (view, param) {
      var form = $('#pform'); if (!form) return;
      var d = draft;
      function dirty() { form.setAttribute('data-dirty', '1'); }
      form.addEventListener('input', dirty);
      function syncDraft() {
        d.name = $('#p-name').value; d.category = $('#p-cat').value; d.sku = $('#p-sku').value; d.description = $('#p-desc').value;
        d.price = $('#p-price').value; d.oldPrice = $('#p-old').value; d.discount = $('#p-disc').value; d.stock = $('#p-stock').value;
        d.featured = $('#p-feat').checked; d.bestSeller = $('#p-best').checked; d.newArrival = $('#p-new').checked; d.status = $('#p-status').value;
      }
      function autoDisc() {
        var pr = num($('#p-price').value), old = num($('#p-old').value);
        if (old > pr && pr > 0) { $('#p-disc').value = Math.round((old - pr) / old * 100); $('#h-disc').textContent = 'Customer saves ' + money(old - pr); }
      }
      $('#p-price').addEventListener('input', autoDisc); $('#p-old').addEventListener('input', autoDisc);
      $('#p-imgurl').addEventListener('change', function () { var u = this.value.trim(); if (u) { syncDraft(); d.image = u; dirty(); rerenderForm(); } });
      function rerenderForm() { var y = window.scrollY; var key = d._key; view.innerHTML = VIEWS.productForm.render(key); VIEWS.productForm.mount(view, key); $('#pform').setAttribute('data-dirty', '1'); window.scrollTo(0, y); }
      $('#p-img').addEventListener('change', function () {
        var f = this.files[0]; if (!f) return;
        syncDraft(); $('#main-drop').style.opacity = '.5';
        storeImage(f, 1000).then(function (src) { d.image = src; rerenderForm(); }, function (e) { $('#main-drop').style.opacity = ''; toast(errMsg(e), { bad: true }); });
      });
      var many = $('#p-imgs');
      if (many) many.addEventListener('change', function () {
        var files = Array.prototype.slice.call(this.files, 0, 4 - (d.images || []).length); if (!files.length) return;
        syncDraft();
        Promise.all(files.map(function (f) { return storeImage(f, 800); })).then(function (srcs) { d.images = (d.images || []).concat(srcs).slice(0, 4); rerenderForm(); }, function (e) { toast(errMsg(e), { bad: true }); });
      });
      $$('[data-rm-img]', view).forEach(function (b) { b.addEventListener('click', function () { syncDraft(); d.images.splice(Number(b.getAttribute('data-rm-img')), 1); rerenderForm(); }); });

      form.addEventListener('submit', function (e) {
        e.preventDefault();
        syncDraft();
        var errs = {};
        if (!d.name.trim()) errs.name = 'Please enter the product name.';
        if (!d.category) errs.cat = 'Please choose a category.';
        if (!(num(d.price) > 0)) errs.price = 'Please enter a price above \u20B90.';
        if (d.stock === '' || num(d.stock, -1) < 0 || Math.floor(num(d.stock)) !== num(d.stock)) errs.stock = 'Please enter stock as a whole number (0 or more).';
        if (!d.image) errs.img = 'Please add a product photo.';
        ['name', 'cat', 'price', 'stock', 'img'].forEach(function (k) { var el = $('#e-' + k); if (el) el.textContent = errs[k] || ''; });
        [['name', '#p-name'], ['cat', '#p-cat'], ['price', '#p-price'], ['stock', '#p-stock']].forEach(function (x) { $(x[1]).setAttribute('aria-invalid', errs[x[0]] ? 'true' : 'false'); });
        var first = Object.keys(errs)[0];
        if (first) { var target = { name: '#p-name', cat: '#p-cat', price: '#p-price', stock: '#p-stock', img: '#main-drop' }[first]; $(target).scrollIntoView({ block: 'center', behavior: 'smooth' }); if ($(target).focus) $(target).focus({ preventScroll: true }); toast('Please fill the required fields', { bad: true }); return; }
        var data = { id: d.id, sku: d.sku, name: d.name, category: d.category, description: d.description, price: d.price, oldPrice: d.oldPrice, discount: d.discount, stock: d.stock, image: d.image, imageAlt: d.name, images: d.images, featured: d.featured, bestSeller: d.bestSeller, newArrival: d.newArrival, status: d.status };
        if (d.sort != null) data.sort = d.sort;
        var btn = $('#p-save'); btn.disabled = true; btn.textContent = 'Saving\u2026';
        A.saveProduct(data).then(function (saved) {
          form.removeAttribute('data-dirty'); draft = null;
          toast('<strong>' + esc(saved.name) + '</strong> saved \u2014 live on the website', { action: { href: '../index.html#shop', label: 'View' } });
          location.hash = '#/products';
        }).catch(function (er) { btn.disabled = false; btn.textContent = 'Save product'; toast(errMsg(er), { bad: true, ms: 7000 }); });
      });
    }
  };

  /* =========================================================
     INVENTORY
     ========================================================= */
  var IF = 'all';
  VIEWS.inventory = {
    render: function () {
      if (!S.loaded.products) return loadingCard();
      var P2 = S.products;
      var units = P2.reduce(function (a, p) { return a + num(p.stock); }, 0);
      var outN = P2.filter(function (p) { return invState(p) === 'out'; }).length, lowN = P2.filter(function (p) { return invState(p) === 'low'; }).length;
      var list = P2.filter(function (p) { var s = invState(p); return IF === 'all' || IF === s; });
      return '<div class="page-head"><div><h2>Inventory</h2><p class="sub">Stock goes down when an order is placed and comes back when an order is cancelled. 0 stock = customers can&rsquo;t order it.</p></div></div>' +
        '<div class="stats stats-3">' + statCard('Units in stock', units, P2.length + ' products', 'inventory') + statCard('Low stock', lowN, '3 or fewer left', 'alert') + statCard('Out of stock', outN, 'Can&rsquo;t be ordered', 'ban') + '</div>' +
        '<section class="card"><div class="result-count"><div class="seg" role="group" aria-label="Show">' + [['all', 'All'], ['low', 'Low'], ['out', 'Out of stock'], ['hidden', 'Hidden']].map(function (x) { return '<button type="button" data-if="' + x[0] + '" class="' + (IF === x[0] ? 'is-on' : '') + '" aria-pressed="' + (IF === x[0]) + '">' + x[1] + '</button>'; }).join('') + '</div><span>' + list.length + ' products</span></div>' +
        (list.length ? '<div class="tbl-wrap"><table class="tbl tbl-cards"><thead><tr><th>Product</th><th>SKU / ID</th><th>Stock</th><th>Status</th><th class="num">Price</th></tr></thead><tbody>' + list.map(function (p) {
          return '<tr><td class="td-head" data-label="Product"><div class="cell-prod"><img class="thumb thumb-sm" src="' + esc(img(p.image)) + '" alt=""><div><div class="nm">' + esc(p.name) + '</div><div class="sk">' + esc(catLabel(p.category)) + '</div></div></div></td>' +
            '<td data-label="SKU / ID" class="mono small">' + esc(p.sku || p.id) + '</td>' +
            '<td data-label="Stock"><span class="stock-edit"><button type="button" data-stk="-1" data-id="' + esc(p.id) + '" aria-label="Decrease stock">\u2212</button><input type="number" min="0" step="1" inputmode="numeric" value="' + num(p.stock) + '" data-stock-input="' + esc(p.id) + '" aria-label="Stock for ' + esc(p.name) + '"><button type="button" data-stk="1" data-id="' + esc(p.id) + '" aria-label="Increase stock">+</button></span><span class="saved-tick" data-tick="' + esc(p.id) + '">Saved</span></td>' +
            '<td data-label="Status">' + invPill(p) + '</td>' +
            '<td data-label="Price" class="num">' + money(p.price) + '</td></tr>';
        }).join('') + '</tbody></table></div>' : '<div class="empty"><strong>Nothing here</strong>' + (IF === 'out' ? 'No product is out of stock.' : IF === 'low' ? 'No product is low on stock.' : 'No products.') + '</div>') +
        '</section>';
    },
    mount: function (view) {
      $$('[data-if]', view).forEach(function (b) { b.addEventListener('click', function () { IF = b.getAttribute('data-if'); renderView(); }); });
      function saveStock(id, val) {
        val = Math.max(0, Math.floor(num(val)));
        var p = productById(id); if (!p || val === num(p.stock)) return;
        var patch = { stock: val };
        if (val > 0 && p.status === 'OUT_OF_STOCK') patch.status = 'ACTIVE';
        A.updateProduct(id, patch).then(function () { var t = $('[data-tick="' + id + '"]'); if (t) { t.classList.add('on'); setTimeout(function () { t.classList.remove('on'); }, 1500); } }, function (e) { toast(errMsg(e), { bad: true }); });
      }
      var pendingT = {};
      $$('[data-stk]', view).forEach(function (b) {
        b.addEventListener('click', function () {
          var id = b.getAttribute('data-id'), inp = $('[data-stock-input="' + id + '"]');
          inp.value = Math.max(0, num(inp.value) + Number(b.getAttribute('data-stk')));
          clearTimeout(pendingT[id]); pendingT[id] = setTimeout(function () { saveStock(id, inp.value); }, 500);
        });
      });
      $$('[data-stock-input]', view).forEach(function (inp) {
        inp.addEventListener('change', function () { saveStock(inp.getAttribute('data-stock-input'), inp.value); });
        inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); inp.blur(); } });
      });
    }
  };

  /* =========================================================
     CUSTOMERS (worked out from orders — checkout is guest checkout)
     ========================================================= */
  var CQ = '';
  VIEWS.customers = {
    render: function (param) {
      if (!S.loaded.orders) return loadingCard();
      var all = customersFromOrders();
      if (param) {
        var c = all.filter(function (x) { return x.phone === param; })[0];
        if (!c) return '<a class="back" href="#/customers">' + ico('arrowl') + 'Customers</a><div class="card"><div class="empty"><strong>Customer not found</strong></div></div>';
        var last = c.orders[0], a = last.address || {};
        return '<a class="back" href="#/customers">' + ico('arrowl') + 'Customers</a>' +
          '<div class="page-head"><div><h2>' + esc(c.name) + '</h2><p class="sub">Guest customer \u00B7 first order ' + fmtDate(c.orders[c.orders.length - 1].createdAt) + '</p></div><div class="actions"><a class="btn btn-wa" target="_blank" rel="noopener" href="' + esc(waLink(c.phone, 'Hi ' + c.name.split(' ')[0] + ', ')) + '">' + ico('wa') + 'WhatsApp</a><a class="btn" href="' + esc(telLink(c.phone)) + '">' + ico('phone') + 'Call</a></div></div>' +
          '<div class="stats stats-3">' + statCard('Total orders', c.orders.length, '', 'orders') + statCard('Total spent', money(c.spent), 'Excludes cancelled', 'rupee') + statCard('Last order', fmtDate(c.last), ago(c.last), 'clock') + '</div>' +
          '<div class="od-grid"><section class="card"><div class="card-head"><h3>Order history</h3></div>' + ordersTable(c.orders) + '</section>' +
          '<section class="card card-pad"><p class="sec-title">Contact</p><dl class="kv"><div><dt>Mobile</dt><dd class="mono">' + esc(fmtPhone(c.phone)) + '</dd></div><div><dt>Email</dt><dd>' + (c.email ? esc(c.email) : '\u2014') + '</dd></div><div><dt>Account</dt><dd>Guest</dd></div></dl>' +
          '<p class="sec-title" style="margin-top:20px">Last delivery address</p><address class="addr">' + esc(addrText(a)) + '</address></section></div>';
      }
      var q = CQ.trim().toLowerCase(), qd = q.replace(/\D/g, '');
      var list = all.filter(function (c) { return !q || String(c.name).toLowerCase().indexOf(q) >= 0 || (qd.length >= 3 && c.phone.indexOf(qd) >= 0) || String(c.email).toLowerCase().indexOf(q) >= 0; });
      return '<div class="page-head"><div><h2>Customers</h2><p class="sub">Everyone who has ordered, grouped by mobile number. Customers check out as guests (no account needed).</p></div></div>' +
        '<section class="card"><div class="toolbar" style="grid-template-columns:1fr"><label class="search"><span class="sr-only">Search customers</span>' + ico('search') + '<input class="in" id="cq" type="search" placeholder="Search name, mobile or email" value="' + esc(CQ) + '"></label></div>' +
        '<div class="result-count"><span>' + list.length + ' customers</span></div>' +
        (list.length ? '<div class="tbl-wrap"><table class="tbl tbl-cards"><thead><tr><th>Customer</th><th>Mobile</th><th>Email</th><th class="num">Orders</th><th class="num">Total spent</th><th>Last order</th><th>Status</th></tr></thead><tbody>' + list.map(function (c) {
          return '<tr class="is-click" data-open-customer="' + esc(c.phone) + '"><td class="td-head" data-label="Customer"><strong>' + esc(c.name) + '</strong></td><td data-label="Mobile" class="mono">' + esc(fmtPhone(c.phone)) + '</td><td data-label="Email">' + (c.email ? esc(c.email) : '<span class="muted">\u2014</span>') + '</td><td data-label="Orders" class="num">' + c.orders.length + '</td><td data-label="Total spent" class="num"><strong>' + money(c.spent) + '</strong></td><td data-label="Last order"><span class="small">' + fmtDate(c.last) + '</span></td><td data-label="Status"><span class="pill">Guest</span></td></tr>';
        }).join('') + '</tbody></table></div>' : '<div class="empty">' + ico('customers') + '<strong>' + (S.orders.length ? 'No match' : 'No customers yet') + '</strong>' + (S.orders.length ? '' : 'Customers appear here after their first order.') + '</div>') +
        '</section>';
    },
    mount: function () {
      var q = $('#cq'); if (q) q.addEventListener('input', debounce(function () { CQ = this.value; renderView(); var el = $('#cq'); el.focus(); el.setSelectionRange(el.value.length, el.value.length); }, 200));
    }
  };

  /* =========================================================
     PAYMENTS
     ========================================================= */
  var PY = { status: '', method: '' };
  VIEWS.payments = {
    render: function () {
      if (!S.loaded.orders) return loadingCard();
      var q = qs(); if (q.status && q.status !== PY._q) { PY.status = q.status; PY._q = q.status; }
      var O = S.orders;
      function sum(f) { var l = O.filter(f); return { n: l.length, amt: l.reduce(function (a, o) { return a + o.total; }, 0) }; }
      var pend = sum(function (o) { return o.paymentMethod === 'UPI' && o.paymentStatus === 'PENDING' && o.orderStatus !== 'CANCELLED'; });
      var paid = sum(function (o) { return o.paymentStatus === 'PAID'; });
      var cod = sum(function (o) { return o.paymentStatus === 'COD' && o.orderStatus !== 'CANCELLED'; });
      var bad = sum(function (o) { return o.paymentStatus === 'FAILED' || o.paymentStatus === 'REFUNDED'; });
      var list = O.filter(function (o) { return (!PY.status || o.paymentStatus === PY.status) && (!PY.method || o.paymentMethod === PY.method); });
      return '<div class="page-head"><div><h2>Payments</h2><p class="sub">UPI payments are checked by you, by hand, in your UPI app. Nothing is marked paid automatically.</p></div></div>' +
        '<div class="callout callout-info" style="margin-bottom:18px">' + ico('info') + '<div class="grow">UPI orders stay <strong>PAYMENT VERIFICATION PENDING</strong> until you open the order and press <strong>Mark as Paid (manually verified)</strong> &mdash; do that only after you see the money in your UPI app (' + esc(S.settings.upiId) + '). A real payment gateway can be connected later to verify automatically.</div></div>' +
        '<div class="stats" style="grid-template-columns:repeat(2,minmax(0,1fr))">' +
          statCard('To verify (UPI)', money(pend.amt), pend.n + ' order' + (pend.n === 1 ? '' : 's'), 'clock', '#/payments?status=PENDING') +
          statCard('Paid', money(paid.amt), paid.n + ' order' + (paid.n === 1 ? '' : 's'), 'check', '#/payments?status=PAID', true) +
          statCard('Cash on delivery', money(cod.amt), cod.n + ' to collect', 'truck', '#/payments?status=COD') +
          statCard('Failed / refunded', money(bad.amt), bad.n + ' order' + (bad.n === 1 ? '' : 's'), 'ban') +
        '</div>' +
        '<section class="card"><div class="toolbar" style="grid-template-columns:1fr"><div class="filters"><select class="sel" id="py-status" aria-label="Payment status">' + opts(U.PAYMENT_STATUSES, PY.status, 'All payment status') + '</select><select class="sel" id="py-method" aria-label="Method"><option value="">UPI &amp; COD</option><option value="UPI"' + (PY.method === 'UPI' ? ' selected' : '') + '>UPI</option><option value="COD"' + (PY.method === 'COD' ? ' selected' : '') + '>COD</option></select></div></div>' +
        '<div class="result-count"><span>' + list.length + ' payments \u00B7 ' + money(list.reduce(function (a, o) { return a + o.total; }, 0)) + '</span></div>' +
        (list.length ? '<div class="tbl-wrap"><table class="tbl tbl-cards"><thead><tr><th>Order ID</th><th>Customer</th><th class="num">Amount</th><th>Method</th><th>Status</th><th>Date</th><th><span class="sr-only">Action</span></th></tr></thead><tbody>' + list.map(function (o) {
          var canPay = o.paymentMethod === 'UPI' && o.paymentStatus === 'PENDING' && o.orderStatus !== 'CANCELLED';
          return '<tr class="is-click" data-open-order="' + esc(o.orderId) + '"><td class="td-head" data-label="Order ID"><span class="oid">' + esc(o.orderId) + '</span></td><td data-label="Customer">' + esc(o.customerName) + '</td><td data-label="Amount" class="num"><strong>' + money(o.total) + '</strong></td><td data-label="Method"><span class="cell-stack"><span class="method">' + esc(o.paymentMethod) + '</span>' + (o.upiTransactionRef ? '<span class="small muted mono">UTR ' + esc(o.upiTransactionRef) + '</span>' : '') + '</span></td><td data-label="Status">' + (o.paymentStatus === 'PENDING' && o.paymentMethod === 'UPI' ? '<span class="pill p-PENDING">Verification pending</span>' : pPill(o.paymentStatus)) + '</td><td data-label="Date"><span class="small">' + fmtDate(o.createdAt, true) + '</span></td>' +
            '<td class="td-actions">' + (canPay ? '<a class="btn btn-sm btn-ok" href="#/orders/' + encodeURIComponent(o.orderId) + '">Verify</a>' : '<a class="btn btn-sm" href="#/orders/' + encodeURIComponent(o.orderId) + '">View</a>') + '</td></tr>';
        }).join('') + '</tbody></table></div>' : '<div class="empty">' + ico('payments') + '<strong>No payments here</strong></div>') +
        '</section>';
    },
    mount: function () {
      $('#py-status').addEventListener('change', function () { PY.status = this.value; if (location.hash.indexOf('?') > 0) { PY._q = ''; history.replaceState(null, '', '#/payments'); } renderView(); });
      $('#py-method').addEventListener('change', function () { PY.method = this.value; renderView(); });
    }
  };

  /* =========================================================
     COUPONS
     ========================================================= */
  function couponState(c) { if (c.enabled === false) return 'Disabled'; if (U.couponExpired(c)) return 'Expired'; if (num(c.usageLimit) > 0 && num(c.usedCount) >= num(c.usageLimit)) return 'Used up'; return 'Active'; }
  VIEWS.coupons = {
    render: function () {
      if (!S.loaded.coupons) return loadingCard();
      var list = S.coupons.slice().sort(function (a, b) { return String(b.createdAt || '').localeCompare(String(a.createdAt || '')); });
      return '<div class="page-head"><div><h2>Coupons</h2><p class="sub">Customers type the code at checkout. Discount, minimum order, expiry and usage limit are checked automatically.</p></div><div class="actions"><button type="button" class="btn btn-dark" data-coupon-new>' + ico('plus') + 'Create coupon</button></div></div>' +
        '<section class="card">' + (list.length ? '<div class="tbl-wrap"><table class="tbl tbl-cards"><thead><tr><th>Code</th><th>Discount</th><th class="num">Min order</th><th class="num">Max discount</th><th>Expiry</th><th class="num">Used</th><th>Status</th><th><span class="sr-only">Actions</span></th></tr></thead><tbody>' + list.map(function (c) {
          var st = couponState(c);
          return '<tr><td class="td-head" data-label="Code"><span class="oid" style="font-size:15px">' + esc(c.code) + '</span></td>' +
            '<td data-label="Discount">' + (c.type === 'percent' ? num(c.value) + '% off' : money(c.value) + ' off') + '</td>' +
            '<td data-label="Min order" class="num">' + (num(c.minOrder) ? money(c.minOrder) : '\u2014') + '</td>' +
            '<td data-label="Max discount" class="num">' + (c.type === 'percent' && num(c.maxDiscount) ? money(c.maxDiscount) : '\u2014') + '</td>' +
            '<td data-label="Expiry">' + (c.expiry ? fmtDate(c.expiry + 'T12:00:00+05:30') : 'No expiry') + '</td>' +
            '<td data-label="Used" class="num">' + num(c.usedCount) + (num(c.usageLimit) ? ' / ' + num(c.usageLimit) : '') + '</td>' +
            '<td data-label="Status"><label class="toggle"><input type="checkbox" data-coupon-toggle="' + esc(c.code) + '"' + (c.enabled !== false ? ' checked' : '') + '><span class="tr"></span><span class="pill ' + (st === 'Active' ? 'p-PAID' : st === 'Disabled' ? 'p-REFUNDED' : 'p-FAILED') + '">' + st + '</span></label></td>' +
            '<td class="td-actions"><button type="button" class="btn btn-sm" data-coupon-edit="' + esc(c.code) + '">' + ico('edit') + 'Edit</button> <button type="button" class="btn btn-sm btn-danger" data-coupon-del="' + esc(c.code) + '" aria-label="Delete ' + esc(c.code) + '">' + ico('trash') + '</button></td></tr>';
        }).join('') + '</tbody></table></div>' : '<div class="empty">' + ico('coupons') + '<strong>No coupons yet</strong>Create a code like WELCOME10 for 10% off.<div style="margin-top:14px"><button type="button" class="btn btn-dark" data-coupon-new>Create coupon</button></div></div>') + '</section>';
    }
  };
  function couponForm(c) {
    var editing = !!c;
    c = c || { code: '', type: 'percent', value: '', minOrder: '', maxDiscount: '', expiry: '', usageLimit: '', enabled: true };
    var body = '<form id="cform" novalidate><div class="auth-err" id="c-err" hidden></div>' +
      '<div class="f"><label for="c-code">Coupon code <span class="req">*</span></label><input class="in" id="c-code" maxlength="30" style="text-transform:uppercase;letter-spacing:.08em" value="' + esc(c.code) + '" placeholder="e.g. WELCOME10" autocapitalize="characters"><span class="hint">Letters, numbers, - or _ (no spaces)</span></div>' +
      '<div class="grid2"><div class="f"><label for="c-type">Discount type</label><select class="sel" id="c-type"><option value="percent"' + (c.type === 'percent' ? ' selected' : '') + '>Percentage (%)</option><option value="fixed"' + (c.type === 'fixed' ? ' selected' : '') + '>Fixed amount (\u20B9)</option></select></div>' +
      '<div class="f"><label for="c-val">Discount value <span class="req">*</span></label><input class="in" id="c-val" type="number" min="1" step="1" inputmode="numeric" value="' + esc(c.value) + '"></div>' +
      '<div class="f"><label for="c-min">Minimum order (\u20B9)</label><input class="in" id="c-min" type="number" min="0" step="1" inputmode="numeric" value="' + esc(num(c.minOrder) || '') + '" placeholder="No minimum"></div>' +
      '<div class="f" id="c-max-wrap"><label for="c-max">Maximum discount (\u20B9)</label><input class="in" id="c-max" type="number" min="0" step="1" inputmode="numeric" value="' + esc(num(c.maxDiscount) || '') + '" placeholder="No limit"></div>' +
      '<div class="f"><label for="c-exp">Expiry date</label><input class="in" id="c-exp" type="date" value="' + esc(c.expiry || '') + '"><span class="hint">Works until the end of this day</span></div>' +
      '<div class="f"><label for="c-lim">Usage limit</label><input class="in" id="c-lim" type="number" min="0" step="1" inputmode="numeric" value="' + esc(num(c.usageLimit) || '') + '" placeholder="Unlimited"><span class="hint">Total times it can be used' + (editing ? ' \u00B7 used ' + num(c.usedCount) + ' so far' : '') + '</span></div></div>' +
      '<label class="toggle"><input type="checkbox" id="c-on"' + (c.enabled !== false ? ' checked' : '') + '><span class="tr"></span><span>Enabled</span></label></form>';
    modal(editing ? 'Edit coupon' : 'Create coupon', body, '<button type="button" class="btn" data-modal-close>Cancel</button><button type="button" class="btn btn-dark" id="c-save">Save coupon</button>');
    function syncMax() { $('#c-max-wrap').style.opacity = $('#c-type').value === 'percent' ? '1' : '.45'; $('#c-max').disabled = $('#c-type').value !== 'percent'; }
    $('#c-type').addEventListener('change', syncMax); syncMax();
    $('#c-code').addEventListener('input', function () { this.value = this.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ''); });
    $('#c-save').addEventListener('click', function () {
      var code = $('#c-code').value.trim().toUpperCase(), type = $('#c-type').value, val = num($('#c-val').value);
      var er = $('#c-err'); er.hidden = true;
      var msg = !/^[A-Z0-9_-]{2,30}$/.test(code) ? 'Coupon code must be 2\u201330 letters/numbers.' :
        !(val > 0) ? 'Enter a discount value above 0.' : (type === 'percent' && val > 90) ? 'Percentage can be at most 90%.' :
        (!editing || code !== c.code) && S.coupons.some(function (x) { return x.code === code; }) ? 'A coupon with this code already exists.' : '';
      if (msg) { er.textContent = msg; er.hidden = false; return; }
      var data = { code: code, type: type, value: val, minOrder: Math.max(0, num($('#c-min').value)), maxDiscount: type === 'percent' ? Math.max(0, num($('#c-max').value)) : 0, expiry: $('#c-exp').value || '', usageLimit: Math.max(0, Math.floor(num($('#c-lim').value))), enabled: $('#c-on').checked };
      this.disabled = true;
      A.saveCoupon(data, editing ? c.code : null).then(function () { closeModal(); toast('Coupon ' + esc(code) + ' saved'); }, function (e) { er.textContent = e.message; er.hidden = false; $('#c-save').disabled = false; });
    });
  }
  document.addEventListener('click', function (e) {
    if (e.target.closest('[data-coupon-new]')) couponForm(null);
    var ed = e.target.closest('[data-coupon-edit]'); if (ed) couponForm(S.coupons.filter(function (c) { return c.code === ed.getAttribute('data-coupon-edit'); })[0]);
    var dl = e.target.closest('[data-coupon-del]');
    if (dl) { var code = dl.getAttribute('data-coupon-del'); confirmBox('Delete coupon?', 'Coupon <strong>' + esc(code) + '</strong> will stop working at checkout.', 'Delete', true).then(function (ok) { if (ok) A.deleteCoupon(code).then(function () { toast('Coupon deleted'); }, function (er) { toast(errMsg(er), { bad: true }); }); }); }
  });
  document.addEventListener('change', function (e) {
    var t = e.target.closest('[data-coupon-toggle]'); if (!t) return;
    var c = S.coupons.filter(function (x) { return x.code === t.getAttribute('data-coupon-toggle'); })[0]; if (!c) return;
    var d = Object.assign({}, c, { enabled: t.checked }); delete d.usedCount; delete d.createdAt; delete d.lastOrderId;
    A.saveCoupon(d, null).then(function () { toast('Coupon ' + esc(c.code) + (t.checked ? ' enabled' : ' disabled')); }, function (er) { t.checked = !t.checked; toast(errMsg(er), { bad: true }); });
  });

  /* =========================================================
     ANALYTICS
     ========================================================= */
  function barChart(days) {
    var W = 640, H = 220, pad = { l: 46, r: 8, t: 14, b: 28 }, iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
    var max = Math.max.apply(null, days.map(function (d) { return d.v; }).concat([1]));
    var step = Math.pow(10, Math.floor(Math.log10(max))); var top = Math.ceil(max / step) * step; if (top / step < 3) { step /= 2; top = Math.ceil(max / step) * step; }
    var bw = iw / days.length, g = '';
    for (var y = 0; y <= top + 0.001; y += step) { var yy = pad.t + ih - (y / top) * ih; g += '<line class="grid" x1="' + pad.l + '" x2="' + (W - pad.r) + '" y1="' + yy + '" y2="' + yy + '"/><text x="' + (pad.l - 6) + '" y="' + (yy + 3) + '" text-anchor="end">' + (y >= 1000 ? (y / 1000) + 'k' : y) + '</text>'; }
    days.forEach(function (d, i) {
      var h = (d.v / top) * ih, x = pad.l + i * bw + bw * 0.18, w = bw * 0.64;
      g += '<rect class="bar' + (i === days.length - 1 ? ' today' : '') + '" x="' + x.toFixed(1) + '" y="' + (pad.t + ih - h).toFixed(1) + '" width="' + w.toFixed(1) + '" height="' + Math.max(h, d.v ? 2 : 0).toFixed(1) + '" rx="3"><title>' + d.label + ': ' + money(d.v) + ' (' + d.n + ' orders)</title></rect>';
      if (days.length <= 14 || i % 2 === 0) g += '<text x="' + (x + w / 2).toFixed(1) + '" y="' + (H - 9) + '" text-anchor="middle">' + d.short + '</text>';
    });
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Daily sales chart">' + g + '</svg>';
  }
  var AN = { range: 14 };
  VIEWS.analytics = {
    render: function () {
      if (!S.loaded.orders) return loadingCard();
      var sales = S.orders.filter(isSale);
      var now = Date.now(), dayMs = 86400e3, today = istDay(now);
      function sumWhere(f) { var l = sales.filter(f); return { v: l.reduce(function (a, o) { return a + o.total; }, 0), n: l.length }; }
      var tS = sumWhere(function (o) { return istDay(o.createdAt) === today; });
      var wS = sumWhere(function (o) { return istDay(o.createdAt) >= istDay(now - 6 * dayMs); });
      var mS = sumWhere(function (o) { return istDay(o.createdAt).slice(0, 7) === today.slice(0, 7); });
      var all = sumWhere(function () { return true; });
      var aov = all.n ? all.v / all.n : 0;
      var days = [];
      for (var i = AN.range - 1; i >= 0; i--) {
        var d = istDay(now - i * dayMs), l = sales.filter(function (o) { return istDay(o.createdAt) === d; });
        var dt = new Date(d + 'T12:00:00+05:30');
        days.push({ label: dt.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' }), short: dt.toLocaleDateString('en-IN', { day: 'numeric' }), v: l.reduce(function (a, o) { return a + o.total; }, 0), n: l.length });
      }
      var best = {};
      sales.forEach(function (o) { o.products.forEach(function (it) { var b = best[it.id] || (best[it.id] = { id: it.id, name: it.name, qty: 0, rev: 0 }); b.qty += it.qty; b.rev += it.qty * it.price; }); });
      var bl = Object.keys(best).map(function (k) { return best[k]; }).sort(function (a, b) { return b.qty - a.qty || b.rev - a.rev; }).slice(0, 6);
      var maxQ = bl.length ? bl[0].qty : 1;
      var upi = sales.filter(function (o) { return o.paymentMethod === 'UPI'; }).length, codN = sales.length - upi;
      var byStatus = U.ORDER_STATUSES.map(function (s) { return [s, S.orders.filter(function (o) { return o.orderStatus === s; }).length]; });
      return '<div class="page-head"><div><h2>Analytics</h2><p class="sub">Sales exclude cancelled, failed and refunded orders. Dates in IST.</p></div></div>' +
        '<div class="stats stats-6">' +
          statCard('Today&rsquo;s sales', money(tS.v), tS.n + ' orders', 'rupee') + statCard('Weekly sales', money(wS.v), 'Last 7 days \u00B7 ' + wS.n + ' orders', 'analytics') +
          statCard('Monthly sales', money(mS.v), 'This month \u00B7 ' + mS.n + ' orders', 'analytics') + statCard('Total sales', money(all.v), 'All time', 'rupee', null, true) +
          statCard('Total orders', S.orders.length, all.n + ' counted as sales', 'orders') + statCard('Average order', money(aov), 'Per order', 'payments') +
        '</div>' +
        '<div class="an-grid"><section class="card"><div class="card-head"><h3>Daily sales</h3><div class="seg">' + [7, 14, 30].map(function (r) { return '<button type="button" data-range="' + r + '" class="' + (AN.range === r ? 'is-on' : '') + '">' + r + ' days</button>'; }).join('') + '</div></div><div class="card-pad">' + barChart(days) + '<div class="legend mt"><span><i style="background:var(--ink)"></i>Sales per day</span><span><i style="background:var(--accent)"></i>Today</span></div></div></section>' +
        '<section class="card"><div class="card-head"><h3>Best selling products</h3></div><div class="card-pad">' + (bl.length ? '<div class="hbars">' + bl.map(function (b) { return '<div class="hbar"><div class="top"><span class="nm">' + esc(b.name) + '</span><span class="v">' + b.qty + ' sold \u00B7 ' + money(b.rev) + '</span></div><div class="track"><div class="fill" style="width:' + Math.max(4, b.qty / maxQ * 100).toFixed(1) + '%"></div></div></div>'; }).join('') + '</div>' : '<div class="empty" style="padding:20px 0">No sales yet.</div>') + '</div></section></div>' +
        '<div class="an-grid mt"><section class="card card-pad"><p class="sec-title">Orders by status</p><div class="hbars">' + byStatus.map(function (x) { var mx = Math.max.apply(null, byStatus.map(function (y) { return y[1]; }).concat([1])); return '<div class="hbar"><div class="top"><span class="nm">' + oPill(x[0]) + '</span><span class="v">' + x[1] + '</span></div><div class="track"><div class="fill" style="width:' + (x[1] / mx * 100).toFixed(1) + '%"></div></div></div>'; }).join('') + '</div></section>' +
        '<section class="card card-pad"><p class="sec-title">Payment method</p>' + (sales.length ? '<div class="split"><span style="width:' + (upi / sales.length * 100) + '%;background:var(--ink)"></span><span style="width:' + (codN / sales.length * 100) + '%;background:var(--accent)"></span></div><div class="legend"><span><i style="background:var(--ink)"></i>UPI ' + upi + ' (' + Math.round(upi / sales.length * 100) + '%)</span><span><i style="background:var(--accent)"></i>COD ' + codN + ' (' + Math.round(codN / sales.length * 100) + '%)</span></div>' : '<p class="muted">No sales yet.</p>') + '</section></div>';
    },
    mount: function (view) { $$('[data-range]', view).forEach(function (b) { b.addEventListener('click', function () { AN.range = Number(b.getAttribute('data-range')); renderView(); }); }); }
  };

  /* =========================================================
     SETTINGS
     ========================================================= */
  function upiValid(id) { return /^[\w.\-]{2,256}@[a-zA-Z][\w.\-]{1,64}$/.test(String(id || '').trim()) && !/YOUR_UPI/i.test(id); }
  VIEWS.settings = {
    render: function () {
      var s = S.settings, fb = Store.mode === 'firebase';
      var cfg = window.VX_FIREBASE_CONFIG || {};
      function f(id, label, val, extra) { return '<div class="f"><label for="' + id + '">' + label + '</label><input class="in" id="' + id + '" value="' + esc(val) + '" ' + (extra || '') + '></div>'; }
      return '<div class="page-head"><div><h2>Settings</h2><p class="sub">Changes apply to the website checkout immediately after you save.</p></div></div>' +
        '<form id="sform" novalidate><div class="set-grid"><div class="stack">' +
          '<section class="card card-pad"><p class="sec-title">Website settings</p>' +
            f('s-brand', 'Brand name', s.brandName, 'maxlength="40"') +
            '<div class="grid2">' + f('s-phone', 'Contact number', s.phone, 'type="tel" inputmode="tel"') + f('s-wa', 'WhatsApp number', s.whatsapp, 'type="tel" inputmode="tel"') + '</div>' +
            f('s-email', 'Email', s.email, 'type="email" placeholder="store@example.com"') +
            '<div class="f"><label for="s-addr">Address</label><textarea class="ta" id="s-addr" rows="2">' + esc(s.address) + '</textarea></div>' +
            '<div class="f"><label for="s-cur">Currency</label><select class="sel" id="s-cur"><option value="INR" selected>INR \u2014 Indian Rupee (\u20B9)</option></select><span class="hint">UPI works in rupees only.</span></div>' +
          '</section>' +
          '<section class="card card-pad"><p class="sec-title">Payment settings (UPI)</p>' +
            '<div class="grid2">' + f('s-upi', 'UPI ID', s.upiId, 'autocapitalize="none" spellcheck="false" placeholder="name@bank"') + f('s-merchant', 'Merchant name (shown in UPI app)', s.merchantName, 'maxlength="40"') + '</div>' +
            '<span class="err" id="e-upi"></span>' +
            '<div class="f"><label for="s-instr">Payment instructions (shown at checkout)</label><textarea class="ta" id="s-instr" rows="3" maxlength="300">' + esc(s.paymentInstructions) + '</textarea></div>' +
            '<div class="qr-prev"><div class="qr" id="s-qr"></div><div><strong>Test QR \u2014 \u20B91</strong><p class="small muted" style="margin-top:4px">This is how your checkout QR is built: your UPI ID + merchant name + the exact order amount. Scan it and pay \u20B91 to check the money reaches you.</p></div></div>' +
          '</section>' +
          '<section class="card card-pad"><p class="sec-title">Shipping settings</p>' +
            '<div class="grid2"><div class="f"><label for="s-ship">Shipping charge (\u20B9)</label><input class="in" id="s-ship" type="number" min="0" step="1" inputmode="numeric" value="' + esc(s.shippingCharge) + '"><span class="hint">0 = free delivery</span></div>' +
            '<div class="f"><label for="s-free">Free shipping above (\u20B9)</label><input class="in" id="s-free" type="number" min="0" step="1" inputmode="numeric" value="' + esc(s.freeShippingAbove || '') + '" placeholder="Off"><span class="hint">Orders at or above this amount ship free</span></div></div>' +
            f('s-eta', 'Estimated delivery time', s.estimatedDelivery, 'maxlength="60" placeholder="3\u20137 working days"') +
          '</section>' +
        '</div>' +
        '<div class="stack">' +
          '<section class="card card-pad" id="golive"><p class="sec-title">Database &amp; login</p>' +
            (fb ? '<div class="callout callout-ok">' + ico('check') + '<div class="grow"><strong>Live \u2014 connected to Firebase</strong><br>Project: <span class="code">' + esc(cfg.projectId) + '</span><br>Signed in as ' + esc(S.user.email || '') + '. Orders from every customer arrive here in real time.</div></div>'
                : '<div class="callout callout-warn">' + ico('alert') + '<div class="grow"><strong>Demo mode</strong> \u2014 everything is saved only in this browser. Orders placed on customers&rsquo; phones will <strong>not</strong> reach you until Firebase is connected.</div></div>' +
                  '<p class="sec-title" style="margin-top:18px">Go live in 5 steps (free)</p><ol class="steps-list"><li>Create a free Firebase project (Spark plan) at console.firebase.google.com.</li><li>Turn on <strong>Authentication \u2192 Email/Password</strong> and add your admin email + password.</li><li>Create a <strong>Firestore database</strong>, add collection <span class="code">admins</span> with a document named with your user UID.</li><li>Paste the rules from <span class="code">firestore.rules</span> and your web config into <span class="code">js/firebase-config.js</span>.</li><li>Publish the site again, log in here, press <strong>Import sample products</strong>.</li></ol><p class="small muted mt">Full simple guide: SETUP-FIREBASE.md in the website ZIP.</p>' +
                  '<div class="btn-row mt"><button type="button" class="btn" id="demo-reset">Reset demo data</button><button type="button" class="btn" id="demo-pw">Change demo password</button></div>') +
          '</section>' +
          '<section class="card card-pad"><p class="sec-title">Products</p><p class="small muted">Bring back the 8 products from the original website (existing products are not changed).</p><div class="btn-row mt"><button type="button" class="btn" data-import>' + ico('upload') + 'Import sample products</button></div></section>' +
          '<section class="card card-pad"><p class="sec-title">New order alerts</p><p class="small muted">A sound plays and a message pops up when a new order arrives while this panel is open.' + (window.Notification ? ' You can also get a phone/computer notification when the panel is in the background.' : '') + '</p><div class="btn-row mt"><button type="button" class="btn" id="test-alert">' + ico('bell') + 'Test sound</button>' + (window.Notification && Notification.permission !== 'granted' ? '<button type="button" class="btn" id="notif-on">Allow notifications</button>' : '') + '</div></section>' +
        '</div></div>' +
        '<div class="save-bar"><button type="submit" class="btn btn-dark btn-lg" id="s-save">Save settings</button></div></form>';
    },
    mount: function (view) {
      var form = $('#sform');
      form.addEventListener('input', function () { form.setAttribute('data-dirty', '1'); drawQr(); });
      function drawQr() {
        var id = $('#s-upi').value.trim(), nm = $('#s-merchant').value.trim() || 'VEXACOLLECTION', box = $('#s-qr');
        if (!upiValid(id) || typeof qrcode !== 'function') { box.textContent = 'Enter a valid UPI ID'; return; }
        var uri = 'upi://pay?pa=' + encodeURIComponent(id).replace(/%40/g, '@') + '&pn=' + encodeURIComponent(nm) + '&am=1.00&cu=INR&tn=' + encodeURIComponent('Test payment');
        var q = qrcode(0, 'M'); q.addData(uri); q.make(); box.innerHTML = q.createSvgTag({ cellSize: 3, margin: 1, scalable: true });
      }
      drawQr();
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var upi = $('#s-upi').value.trim();
        if (!upiValid(upi)) { $('#e-upi').textContent = 'Enter your real UPI ID, like name@ybl or 98xxxxxx@okaxis.'; $('#s-upi').setAttribute('aria-invalid', 'true'); $('#s-upi').focus(); return; }
        $('#e-upi').textContent = ''; $('#s-upi').setAttribute('aria-invalid', 'false');
        var data = {
          brandName: $('#s-brand').value.trim(), phone: $('#s-phone').value.trim(), whatsapp: $('#s-wa').value.replace(/[^\d]/g, ''), email: $('#s-email').value.trim(),
          address: $('#s-addr').value.trim(), currency: 'INR', upiId: upi, merchantName: $('#s-merchant').value.trim(), paymentInstructions: $('#s-instr').value.trim(),
          shippingCharge: Math.max(0, num($('#s-ship').value)), freeShippingAbove: Math.max(0, num($('#s-free').value)), estimatedDelivery: $('#s-eta').value.trim()
        };
        var btn = $('#s-save'); btn.disabled = true; btn.textContent = 'Saving\u2026';
        A.saveSettings(data).then(function () { form.removeAttribute('data-dirty'); btn.disabled = false; btn.textContent = 'Save settings'; toast('Settings saved \u2014 checkout updated'); }, function (er) { btn.disabled = false; btn.textContent = 'Save settings'; toast(errMsg(er), { bad: true }); });
      });
      var ta = $('#test-alert'); if (ta) ta.addEventListener('click', function () { chime(); toast('This is how a new order alert sounds', { icon: 'bell', order: true }); });
      var no = $('#notif-on'); if (no) no.addEventListener('click', function () { Notification.requestPermission().then(function (p) { toast(p === 'granted' ? 'Notifications allowed' : 'Notifications not allowed', { bad: p !== 'granted' }); renderView(); }); });
      var dr = $('#demo-reset'); if (dr) dr.addEventListener('click', function () {
        confirmBox('Reset demo data?', 'Deletes all demo products, orders, coupons and settings in this browser and starts again with the 8 sample products. Your demo login stays.', 'Reset data', true).then(function (ok) { if (ok) { A.clearDemoData(); location.reload(); } });
      });
      var dp = $('#demo-pw'); if (dp) dp.addEventListener('click', function () {
        confirmBox('Change demo password?', 'You will be logged out and asked to create a new demo username and password.', 'Continue').then(function (ok) { if (ok) { stopData(); S.user = null; A.auth.resetDemoPassword(); } });
      });
      if (/golive/.test(sessionStorage.getItem('vx_scroll') || '')) { sessionStorage.removeItem('vx_scroll'); setTimeout(function () { $('#golive').scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 60); }
    }
  };
  document.addEventListener('click', function (e) { var a = e.target.closest('[data-scroll]'); if (a) { sessionStorage.setItem('vx_scroll', a.getAttribute('data-scroll')); if (current.name === 'settings') renderView(); } });

  /* =========================================================
     BOOT
     ========================================================= */
  Store.ready.then(function () {
    A = Store.adapter;
    var firstAuth = true;
    A.auth.onChange(function (user) {
      if (user && idleExpired() && firstAuth) { firstAuth = false; logout('Your session expired. Please log in again.'); return; }
      firstAuth = false;
      if (user) {
        var was = S.user;
        S.user = user;
        touch(true);
        if (!was) startApp();
      } else {
        var wasIn = !!S.user;
        stopData();
        S.user = null;
        // keep an error message on the login form visible (e.g. "not an admin")
        if (!wasIn && !$('#auth').hidden && $('#login-form')) return;
        if (A.auth.needsSetup()) showSetup(); else showLogin(pendingNote);
        pendingNote = '';
      }
    });
  }).catch(function (e) {
    show('auth');
    $('#auth-box').innerHTML = '<img class="auth-logo" src="../images/logo.svg" alt="VEXACOLLECTION"><h1>Can&rsquo;t connect</h1><p class="lead">The admin panel could not connect to Firebase.</p><div class="auth-err">' + esc((e && e.message) || e) + '</div><p class="auth-note">Check the values in <strong>js/firebase-config.js</strong> and your internet connection, then reload. To use demo mode instead, put the &ldquo;PASTE_&hellip;&rdquo; placeholders back.</p><button class="btn btn-dark btn-block btn-lg" onclick="location.reload()">Try again</button>';
  });
})();
